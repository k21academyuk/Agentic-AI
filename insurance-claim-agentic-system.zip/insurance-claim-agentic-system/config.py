"""
Configuration management for the Insurance Claim Agentic System
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from the .env file in the project root
load_dotenv(Path(__file__).parent / ".env")


class Config:
    """Application configuration"""

    # API key (from .env locally, from Secrets Manager on AWS)
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")

    # Claude model settings. Change the model in .env without touching code.
    CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6")
    MAX_TOKENS = 1024

    # Project paths
    PROJECT_ROOT = Path(__file__).parent
    MEMORY_FILE = PROJECT_ROOT / "claim_memory.json"

    @classmethod
    def validate(cls):
        """Validate required configuration"""
        if not cls.ANTHROPIC_API_KEY or cls.ANTHROPIC_API_KEY.startswith("your_"):
            raise ValueError(
                "ANTHROPIC_API_KEY not found. "
                "Please set it in the .env file (see .env.example)."
            )
        return True


# Warn (but do not crash) on import, so offline tests still run without a key
try:
    Config.validate()
    print("✓ Configuration loaded successfully")
except ValueError as e:
    print(f"⚠ Configuration warning: {e}")
