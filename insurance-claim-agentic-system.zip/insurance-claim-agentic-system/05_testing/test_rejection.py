"""
Test: claims that break policy rules are never auto-approved.

Run as a script:  python 05_testing/test_rejection.py
Or with pytest:   pytest 05_testing/test_rejection.py -v
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "02_patterns"))

from utils import SAMPLE_CLAIMS
from guardrail_agent import check_guardrails

AUTO = SAMPLE_CLAIMS[0]          # Auto policy: $100,000 coverage limit

SCENARIOS = [
    # (description, claim changes, proposed decision, expected final decision)
    ("Exceeds the $100,000 Auto limit", {"claim_amount": 150_000}, "APPROVED", "MANUAL_REVIEW"),
    ("Within the Auto limit", {"claim_amount": 5_000}, "APPROVED", "APPROVED"),
    ("Negative amount is invalid", {"claim_amount": -100}, "APPROVED", "MANUAL_REVIEW"),
    ("AI rejection inside the rules stands", {"claim_amount": 5_000}, "REJECTED", "REJECTED"),
    ("Unknown decision word is blocked", {"claim_amount": 5_000}, "MAYBE", "MANUAL_REVIEW"),
]


def test_rejection_scenarios():
    for label, changes, proposed, expected in SCENARIOS:
        final = check_guardrails(dict(AUTO, **changes), proposed)["final_decision"]
        assert final == expected, f"{label}: expected {expected}, got {final}"


if __name__ == "__main__":
    for label, changes, proposed, expected in SCENARIOS:
        final = check_guardrails(dict(AUTO, **changes), proposed)["final_decision"]
        assert final == expected, f"{label}: expected {expected}, got {final}"
        print(f"✓ {label}: {proposed} → {final}")
    print("\n✓ All rejection tests passed!")
