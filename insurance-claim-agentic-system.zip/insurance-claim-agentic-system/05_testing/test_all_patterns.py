"""
Test all 8 patterns and the full pipeline - offline, no API key needed.

Claude is replaced by FakeClaude (scripted replies), so these tests check
our own code: JSON parsing, fallbacks, the tool loop, guardrails,
escalation rules, memory and how the pipeline wires the patterns together.

Run as a script:   python 05_testing/test_all_patterns.py
Or with pytest:    pytest 05_testing -v
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
for p in (ROOT, ROOT / "02_patterns", ROOT / "01_local_demo", ROOT / "05_testing"):
    sys.path.insert(0, str(p))

from fake_claude import FakeClaude
from utils import SAMPLE_CLAIMS, parse_json
from planner_agent import create_processing_plan
from router_agent import ClaimRouter
from rag_agent import analyze_with_knowledge
from guardrail_agent import check_guardrails
from human_escalation import should_escalate
from reflection_agent import reflect_on_decision
from tool_agent import run_tool_agent, fraud_check
from stateful_agent import StatefulClaimAgent
from full_system import InsuranceClaimSystem

AUTO, PROPERTY, HEALTH, LIABILITY, AUTO_2 = SAMPLE_CLAIMS


def test_parse_json_handles_fences_and_noise():
    assert parse_json('Here you go:\n```json\n{"a": 1}\n```') == {"a": 1}
    assert parse_json("not json") is None


def test_pattern1_planner_returns_steps():
    plan = create_processing_plan(AUTO, FakeClaude())
    assert len(plan["plan"]) == 2


def test_pattern1_planner_falls_back_on_bad_json():
    plan = create_processing_plan(AUTO, FakeClaude(plan_reply="sorry, no JSON"))
    assert "Fallback" in plan["note"] and len(plan["plan"]) == 4


def test_pattern2_router_accepts_valid_route():
    assert ClaimRouter(FakeClaude(route="FAST")).route(AUTO)["route"] == "FAST"


def test_pattern2_router_falls_back_on_invalid_route():
    result = ClaimRouter(FakeClaude(route="WARP_SPEED")).route(LIABILITY)
    assert result == {"route": "EXECUTIVE", "source": "rule", "reasoning": result["reasoning"]}


def test_pattern3_rag_sends_policy_to_claude():
    fake = FakeClaude()
    analyze_with_knowledge(PROPERTY, fake)
    prompt = fake.calls[0]["messages"][0]["content"]
    assert "$500,000.00" in prompt and "60 days" in prompt


def test_pattern4_guardrail_passes_normal_claim():
    assert check_guardrails(AUTO, "APPROVED")["overall_passed"]


def test_pattern4_guardrail_blocks_high_value_approval():
    result = check_guardrails(LIABILITY, "APPROVED")
    assert result["final_decision"] == "MANUAL_REVIEW"
    assert "high_value_signoff" in result["failed_checks"]


def test_pattern5_escalation_rules():
    assert not should_escalate(AUTO, 0.95)["escalate"]
    assert should_escalate(AUTO, 0.60)["escalate"]               # low confidence
    assert should_escalate(PROPERTY, 0.95)["escalate"]           # over $50,000
    assert should_escalate(AUTO, 0.95, repeat_claimant=True)["escalate"]


def test_pattern6_reflection_returns_revised_decision():
    r = reflect_on_decision(AUTO, {"decision": "APPROVED", "confidence": 0.6, "reasoning": "ok"},
                            FakeClaude(reflection_rating=4, revised_decision="manual_review"))
    assert r["rating"] == 4 and r["revised_decision"] == "MANUAL_REVIEW"


def test_pattern7_tool_loop_runs_every_requested_tool():
    _, log = run_tool_agent(AUTO, FakeClaude())
    assert [c["tool"] for c in log] == ["policy_lookup", "fraud_check", "claims_history"]
    assert log[0]["output"]["coverage"] == 100_000


def test_pattern7_fraud_levels_are_reachable():
    assert fraud_check(5_000, "minor dent", "Alice Williams")["risk_level"] == "LOW"
    assert fraud_check(5_000, "minor dent", "Bob Johnson")["risk_level"] == "MODERATE"
    high = fraud_check(90_000, "urgent cash needed", "Bob Johnson")
    assert high["risk_level"] == "HIGH" and high["recommendation"] == "INVESTIGATE"


def test_pattern8_memory_flags_repeat_claimant():
    agent = StatefulClaimAgent()
    agent.process_claim(AUTO, "APPROVED", 0.9, quiet=True)
    assert not agent.is_repeat_claimant("John Doe")
    agent.process_claim(AUTO_2, "APPROVED", 0.9, quiet=True)
    assert agent.is_repeat_claimant("John Doe")


def test_pipeline_approves_clean_claim():
    r = InsuranceClaimSystem(FakeClaude(), verbose=False).process_claim(AUTO)
    assert r["final_decision"] == "APPROVED"
    assert len(r["tool_calls"]) == 3 and not r["escalation"]["escalate"]


def test_pipeline_low_reflection_rating_revises_decision():
    fake = FakeClaude(reflection_rating=3, revised_decision="REJECTED")
    r = InsuranceClaimSystem(fake, verbose=False).process_claim(AUTO)
    assert r["decision_revised"] and r["final_decision"] == "REJECTED"


def test_pipeline_guardrail_overrides_high_value_approval():
    r = InsuranceClaimSystem(FakeClaude(), verbose=False).process_claim(LIABILITY)
    assert r["final_decision"] == "MANUAL_REVIEW"
    assert not r["guardrails"]["overall_passed"]


def test_pipeline_memory_escalates_third_claim_from_same_person():
    system = InsuranceClaimSystem(FakeClaude(), verbose=False)
    system.process_claim(AUTO)
    system.process_claim(AUTO_2)
    third = system.process_claim(dict(AUTO, claim_id="CLM-006"))
    assert third["repeat_claimant"] and third["final_decision"] == "MANUAL_REVIEW"


if __name__ == "__main__":
    tests = [(name, fn) for name, fn in list(globals().items())
             if name.startswith("test_") and callable(fn)]
    print(f"Running {len(tests)} offline tests (FakeClaude, no API calls)\n")
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"✓ PASS  {name}")
        except Exception as e:  # noqa: BLE001 - report every failure
            failed += 1
            print(f"✗ FAIL  {name}: {type(e).__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} tests passed")
    sys.exit(1 if failed else 0)
