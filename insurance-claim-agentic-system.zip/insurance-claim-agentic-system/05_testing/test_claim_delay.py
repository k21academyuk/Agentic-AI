"""
Test: late claims are sent to manual review by the filing-window guardrail.

Run as a script:  python 05_testing/test_claim_delay.py
Or with pytest:   pytest 05_testing/test_claim_delay.py -v
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "02_patterns"))

from utils import SAMPLE_CLAIMS
from guardrail_agent import check_guardrails

AUTO = SAMPLE_CLAIMS[0]          # Auto policy: 30-day filing window


def test_on_time_claim_passes():
    result = check_guardrails(dict(AUTO, days_since_incident=10), "APPROVED")
    assert result["checks"]["filed_on_time"]["passed"]
    assert result["final_decision"] == "APPROVED"


def test_late_claim_goes_to_manual_review():
    result = check_guardrails(dict(AUTO, days_since_incident=45), "APPROVED")
    assert not result["checks"]["filed_on_time"]["passed"]
    assert result["final_decision"] == "MANUAL_REVIEW"


def test_missing_incident_date_goes_to_manual_review():
    claim = {k: v for k, v in AUTO.items() if k != "days_since_incident"}
    assert check_guardrails(claim, "APPROVED")["final_decision"] == "MANUAL_REVIEW"


if __name__ == "__main__":
    for test in (test_on_time_claim_passes, test_late_claim_goes_to_manual_review,
                 test_missing_incident_date_goes_to_manual_review):
        test()
        print(f"✓ {test.__name__}")
    print("\n✓ All claim delay tests passed!")
