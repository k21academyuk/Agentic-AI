"""
A fake Claude client for offline tests.

It answers like the real Anthropic client (same .messages.create() call,
same response shape) but returns scripted replies, so the tests:
  • cost nothing and need no API key
  • give the same result every run
  • check OUR code (parsing, tool loop, guardrails, escalation, wiring)
  • reject any argument the installed Anthropic SDK does not accept
"""
import json
from types import SimpleNamespace


def _real_sdk_arguments():
    """The argument names the installed Anthropic SDK accepts in messages.create()."""
    try:
        import inspect
        import anthropic
        params = inspect.signature(anthropic.resources.Messages.create).parameters
        return {name for name in params if name != "self"}
    except Exception:  # SDK not installed: skip the check
        return None


REAL_SDK_ARGUMENTS = _real_sdk_arguments()


def text_block(text):
    return SimpleNamespace(type="text", text=text)


def tool_block(i, name, args):
    return SimpleNamespace(type="tool_use", id=f"toolu_{i}", name=name, input=args)


class FakeClaude:
    def __init__(self, decision="APPROVED", confidence=0.9, risk="LOW",
                 route="STANDARD", reflection_rating=8, revised_decision=None,
                 plan_reply=None):
        self.decision = decision
        self.confidence = confidence
        self.risk = risk
        self.route = route
        self.reflection_rating = reflection_rating
        self.revised_decision = revised_decision or decision
        self.plan_reply = plan_reply
        self.calls = []
        self.messages = SimpleNamespace(create=self._create)

    def _reply(self, text):
        return SimpleNamespace(content=[text_block(text)], stop_reason="end_turn")

    def _create(self, **kwargs):
        # Fail like the real SDK if our code passes an argument it does not accept
        if REAL_SDK_ARGUMENTS is not None:
            unknown = sorted(set(kwargs) - REAL_SDK_ARGUMENTS)
            if unknown:
                raise TypeError(f"Messages.create() got an unexpected keyword argument {unknown}")
        self.calls.append(kwargs)
        messages = kwargs["messages"]
        first = messages[0]["content"]
        prompt = first if isinstance(first, str) else json.dumps(first)

        if "claims processing manager" in prompt:
            return self._reply(self.plan_reply or json.dumps({
                "complexity": "low", "estimated_days": 3,
                "plan": [{"step": 1, "action": "Verify policy", "outcome": "Coverage confirmed", "time": "1 hour"},
                         {"step": 2, "action": "Decide", "outcome": "Decision issued", "time": "1 hour"}]}))

        if "claim routing specialist" in prompt:
            return self._reply(json.dumps({"route": self.route, "reasoning": "test route"}))

        if "insurance policy analyst" in prompt:
            return self._reply("1. Within limit. 2. Photos. 3. Approve.")

        if "senior claims auditor" in prompt:
            return self._reply(json.dumps({
                "rating": self.reflection_rating, "strengths": "clear", "improvements": "none",
                "revised_decision": self.revised_decision, "revised_confidence": self.confidence,
                "revised_reasoning": "revised by reflection"}))

        if kwargs.get("tools"):
            # First turn: ask for all three tools. Second turn: give the answer.
            if len(messages) == 1:
                return SimpleNamespace(stop_reason="tool_use", content=[
                    text_block("Checking the tools."),
                    tool_block(1, "policy_lookup", {"policy_number": "POL-12345"}),
                    tool_block(2, "fraud_check", {"claim_amount": 5000, "description": "Minor fender bender",
                                                  "claimant_name": "John Doe"}),
                    tool_block(3, "claims_history", {"claimant_name": "John Doe"}),
                ])
            return self._reply("```json\n" + json.dumps({
                "decision": self.decision, "confidence": self.confidence,
                "risk_level": self.risk, "reasoning": "tool results look fine"}) + "\n```")

        return self._reply("DECISION: APPROVED\nCONFIDENCE: 90%\nREASONING: ok\nRED_FLAGS: None")
