"""
Policy rules - ONE place for every limit and threshold in the project.

Every pattern (router, RAG, guardrail, escalation, tools) and the full
system read their numbers from here, so the same claim always gets the
same rules no matter which script you run.
"""

# Policy knowledge base, per claim type.
# In production this would live in a database or a document store.
POLICIES = {
    "Auto": {
        "max_coverage": 100_000,
        "deductible": 500,
        "filing_window_days": 30,
        "required_docs": ["police report (over $5,000)", "photos", "repair estimate"],
        "rules": "Police report required for claims over $5,000. Photos mandatory. "
                 "File within 30 days of the incident.",
        "turnaround": "5-7 business days",
    },
    "Property": {
        "max_coverage": 500_000,
        "deductible": 1_000,
        "filing_window_days": 60,
        "required_docs": ["photos", "contractor estimate", "proof of ownership"],
        "rules": "File within 60 days of the incident. Contractor estimate required. "
                 "Gradual damage and neglect are not covered.",
        "turnaround": "10-14 business days",
    },
    "Health": {
        "max_coverage": 150_000,
        "deductible": 250,
        "filing_window_days": 90,
        "required_docs": ["medical records", "itemised bills", "pre-authorisation (over $10,000)"],
        "rules": "Pre-authorisation required for procedures over $10,000. "
                 "In-network preferred (80/20 split).",
        "turnaround": "3-5 business days",
    },
    "Liability": {
        "max_coverage": 1_000_000,
        "deductible": 2_500,
        "filing_window_days": 3,
        "required_docs": ["incident report", "legal claim", "evidence"],
        "rules": "Must report within 72 hours. Legal counsel required for claims over $50,000.",
        "turnaround": "21-30 business days",
    },
}

# Processing lanes used by the Router (amount ranges in dollars)
ROUTES = {
    "FAST":      "Under $5,000, simple, no injury -> quick review",
    "STANDARD":  "$5,000 to $50,000 -> regular review",
    "COMPLEX":   "$50,000 to $100,000, or any injury/legal element -> detailed investigation",
    "EXECUTIVE": "Over $100,000 -> executive sign-off",
}

# Guardrail and escalation thresholds
HIGH_VALUE_APPROVAL_LIMIT = 100_000   # AI may not approve above this on its own
ESCALATION_CONFIDENCE = 0.75          # below this confidence -> human review
ESCALATION_AMOUNT = 50_000            # above this amount -> human review
EXECUTIVE_AMOUNT = 500_000            # above this amount -> executive approval
REPEAT_CLAIM_THRESHOLD = 2            # this many claims by one person -> flag

VALID_DECISIONS = ("APPROVED", "REJECTED", "MANUAL_REVIEW")


def get_policy(claim_type: str) -> dict:
    """Return the policy for a claim type (Auto is used if the type is unknown)."""
    return POLICIES.get(claim_type, POLICIES["Auto"])


def route_by_amount(claim: dict) -> str:
    """Rule-based route, used as a safe fallback when the AI answer is unusable."""
    amount = claim.get("claim_amount", 0)
    if amount > 100_000:
        return "EXECUTIVE"
    if amount > 50_000:
        return "COMPLEX"
    if amount >= 5_000:
        return "STANDARD"
    return "FAST"
