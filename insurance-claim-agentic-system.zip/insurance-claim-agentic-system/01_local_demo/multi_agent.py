"""
Multi-Agent System - Multiple Agents Working Together

This example shows how different specialized agents can collaborate
to process insurance claims more effectively.

Learning Goals:
- Understand agent specialization
- See how agents can work together
- Learn about agent orchestration

Estimated time: 30 minutes
"""

import anthropic
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Config
from utils import print_section, print_result, SAMPLE_CLAIMS

class AgentOrchestrator:
    """Coordinates multiple specialized agents"""
    
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)
        self.results = {}
    
    def run_agent(self, agent_name: str, system_prompt: str, user_prompt: str) -> str:
        """
        Run a single agent with given prompts
        
        Args:
            agent_name: Name of the agent for tracking
            system_prompt: Agent's role and instructions
            user_prompt: The specific task/question
            
        Returns:
            Agent's response as string
        """
        print(f"\n  🤖 Running {agent_name}...")
        
        response = self.client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=1024,
            system=system_prompt,
            messages=[
                {"role": "user", "content": user_prompt}
            ]
        )
        
        result = response.content[0].text
        self.results[agent_name] = result
        return result

class ClaimAnalysisSystem:
    """Multi-agent system for comprehensive claim analysis"""
    
    def __init__(self):
        self.orchestrator = AgentOrchestrator()
    
    def analyze_claim(self, claim: dict) -> dict:
        """
        Analyze claim using multiple specialized agents
        
        The system uses 4 agents:
        1. Triage Agent - Initial assessment and priority
        2. Risk Agent - Risk analysis
        3. Compliance Agent - Regulatory compliance check
        4. Decision Agent - Final decision based on all inputs
        """
        
        print_section("🔄 MULTI-AGENT ANALYSIS STARTING")
        
        # Prepare claim summary for agents
        claim_summary = f"""
Claim ID: {claim['claim_id']}
Type: {claim['claim_type']}
Amount: ${claim['claim_amount']:,.2f}
Date: {claim['claim_date']}
Description: {claim['description']}
Policy: {claim['policy_number']}
Claimant: {claim['claimant_name']}
"""
        
        # Agent 1: Triage Agent
        triage_result = self.orchestrator.run_agent(
            agent_name="Triage Agent",
            system_prompt="""You are a triage specialist for insurance claims. 
            Your job is to do initial assessment and determine priority level.
            Categorize as: URGENT, HIGH, MEDIUM, or LOW priority.
            Keep response brief and focused.""",
            user_prompt=f"Assess this claim and assign priority:\n{claim_summary}"
        )
        
        # Agent 2: Risk Agent
        risk_result = self.orchestrator.run_agent(
            agent_name="Risk Agent",
            system_prompt="""You are a risk assessment specialist.
            Analyze potential risks, fraud indicators, and claim validity.
            Rate risk as: LOW, MODERATE, HIGH, or CRITICAL.
            Keep response brief and focused.""",
            user_prompt=f"Analyze risks for this claim:\n{claim_summary}"
        )
        
        # Agent 3: Compliance Agent
        compliance_result = self.orchestrator.run_agent(
            agent_name="Compliance Agent",
            system_prompt="""You are a compliance officer.
            Check if claim meets policy requirements and regulations.
            State: COMPLIANT, NON-COMPLIANT, or NEEDS_REVIEW.
            Keep response brief and focused.""",
            user_prompt=f"Check compliance for this claim:\n{claim_summary}"
        )
        
        # Agent 4: Decision Agent (synthesizes all inputs)
        decision_result = self.orchestrator.run_agent(
            agent_name="Decision Agent",
            system_prompt="""You are the final decision maker.
            Consider all agent inputs and make a final decision.
            Decide: APPROVE, REJECT, or MANUAL_REVIEW.
            Provide clear reasoning based on all agent inputs.""",
            user_prompt=f"""Make final decision on this claim:

CLAIM:
{claim_summary}

TRIAGE ASSESSMENT:
{triage_result}

RISK ASSESSMENT:
{risk_result}

COMPLIANCE CHECK:
{compliance_result}

Provide final decision with reasoning."""
        )
        
        return {
            "claim_id": claim['claim_id'],
            "triage": triage_result,
            "risk": risk_result,
            "compliance": compliance_result,
            "final_decision": decision_result,
            "all_results": self.orchestrator.results
        }

def main():
    """Main function demonstrating multi-agent system"""
    
    print_section("🤖 MULTI-AGENT SYSTEM DEMO", 
                  "Watch multiple specialized agents collaborate!")
    
    try:
        # Create multi-agent system
        print("Initializing multi-agent system...")
        system = ClaimAnalysisSystem()
        print("✓ System ready with 4 specialized agents:")
        print("  1. Triage Agent - Priority assessment")
        print("  2. Risk Agent - Risk analysis")
        print("  3. Compliance Agent - Regulatory check")
        print("  4. Decision Agent - Final decision")
        
        # Analyze a claim
        print("\n\nSelecting claim for analysis...")
        claim = SAMPLE_CLAIMS[1]  # High-value property claim
        print(f"✓ Selected: {claim['claim_id']} - ${claim['claim_amount']:,.2f}")
        print(f"  Description: {claim['description'][:60]}...")
        
        # Run multi-agent analysis
        print("\n\nStarting multi-agent analysis...")
        print("(This will take about 30-60 seconds)")
        result = system.analyze_claim(claim)
        
        # Display results
        print_section("📊 MULTI-AGENT ANALYSIS RESULTS")
        
        print("\n1️⃣  TRIAGE AGENT ASSESSMENT:")
        print("-" * 60)
        print(result['triage'])
        
        print("\n\n2️⃣  RISK AGENT ANALYSIS:")
        print("-" * 60)
        print(result['risk'])
        
        print("\n\n3️⃣  COMPLIANCE AGENT CHECK:")
        print("-" * 60)
        print(result['compliance'])
        
        print("\n\n4️⃣  FINAL DECISION:")
        print("-" * 60)
        print(result['final_decision'])
        
        print("\n\n" + "="*60)
        print("  KEY INSIGHTS")
        print("="*60)
        print("\n✓ Four specialized agents provided different perspectives")
        print("✓ Decision agent synthesized all inputs for final judgment")
        print("✓ This approach reduces bias and improves accuracy")
        
        print("\n\n" + "="*60)
        print("  NEXT STEPS")
        print("="*60)
        print("\n1. Try different claims from SAMPLE_CLAIMS")
        print("2. Add more specialized agents (e.g., Fraud Detection Agent)")
        print("3. Modify agent prompts to change their behavior")
        print("4. Move to full_system.py for complete orchestration")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("\nCheck your API key and internet connection.")

if __name__ == "__main__":
    main()
