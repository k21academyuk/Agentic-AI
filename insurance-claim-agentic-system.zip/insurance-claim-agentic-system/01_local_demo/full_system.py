"""
Full System - Complete Insurance Claim Processing Pipeline

This connects all 8 patterns into ONE pipeline. Each step's output feeds
the next one:

  1 Planner     -> a processing plan              (Claude)
  2 Router      -> a processing lane              (Claude + rule fallback)
  3 RAG         -> the policy rules for the type  (retrieval)
  7 Tools       -> Claude calls policy, fraud and history tools and decides (Claude tool use)
  6 Reflection  -> Claude audits the decision and may revise it            (Claude)
  4 Guardrails  -> fixed compliance rules can override the decision        (rules)
  5 Escalation  -> decides if a human must review                          (rules)
  8 Memory      -> stores the result; repeat claimants are flagged next time

The Streamlit and Gradio apps import InsuranceClaimSystem from this file,
so the web UI runs exactly this pipeline.
"""

import json
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "02_patterns"))

from utils import print_section, print_result, SAMPLE_CLAIMS, parse_json, get_client, format_claim_data
from planner_agent import create_processing_plan
from router_agent import ClaimRouter
from rag_agent import retrieve_policy
from tool_agent import run_tool_loop
from reflection_agent import reflect_on_decision, REVISE_BELOW_RATING
from guardrail_agent import check_guardrails
from human_escalation import should_escalate
from stateful_agent import StatefulClaimAgent


class InsuranceClaimSystem:
    """Runs every claim through all 8 patterns."""

    def __init__(self, client=None, memory: StatefulClaimAgent = None, verbose: bool = True):
        self.client = client or get_client()
        self.router = ClaimRouter(self.client)
        self.memory = memory or StatefulClaimAgent()
        self.verbose = verbose

    def log(self, log: list, step: str, details: str):
        log.append({"time": datetime.now().isoformat(timespec="seconds"),
                    "step": step, "details": details})
        if self.verbose:
            print(f"  📝 {step:<11} {details}")

    def decide(self, claim: dict, plan: dict, route: dict, policy: dict):
        """Pattern 7 + decision: Claude uses the tools, then returns a JSON decision."""
        prompt = f"""You are the final decision agent for an insurance claim.

CLAIM:
{format_claim_data(claim)}

PROCESSING PLAN (from the planner agent):
{json.dumps(plan.get('plan', []), indent=2)}

ROUTE (from the router agent): {route['route']} - {route['reasoning']}

POLICY RULES (retrieved):
{json.dumps(policy, indent=2)}

First use the tools to check the policy, fraud risk and claims history.
Then return ONLY JSON:
{{"decision": "APPROVED | REJECTED | MANUAL_REVIEW",
  "confidence": 0.0-1.0,
  "risk_level": "LOW | MEDIUM | HIGH",
  "reasoning": "2-3 sentences citing the policy rules and tool results"}}"""

        text, tool_log = run_tool_loop(self.client, prompt)
        decision = parse_json(text) or {}
        decision["decision"] = str(decision.get("decision", "MANUAL_REVIEW")).upper()
        try:
            decision["confidence"] = float(decision.get("confidence", 0.5))
        except (TypeError, ValueError):
            decision["confidence"] = 0.5
        if decision["confidence"] > 1:          # Claude wrote 85 instead of 0.85
            decision["confidence"] /= 100
        decision.setdefault("risk_level", "MEDIUM")
        decision.setdefault("reasoning", "Decision reply was not valid JSON; sent to manual review.")
        return decision, tool_log

    def process_claim(self, claim: dict) -> dict:
        """Run one claim through the whole pipeline and return everything it produced."""
        log = []
        if self.verbose:
            print_section(f"🔄 PROCESSING CLAIM {claim['claim_id']}")

        # Pattern 8 (read): has this person claimed before?
        repeat = self.memory.is_repeat_claimant(claim.get('claimant_name', ''))
        self.log(log, "MEMORY", f"Repeat claimant: {'YES' if repeat else 'no'}")

        # Pattern 1: plan
        plan = create_processing_plan(claim, self.client)
        self.log(log, "PLANNER", f"{len(plan.get('plan', []))}-step plan, complexity {plan.get('complexity')}")

        # Pattern 2: route
        route = self.router.route(claim)
        self.log(log, "ROUTER", f"{route['route']} ({route['source']})")

        # Pattern 3: retrieve policy
        policy = retrieve_policy(claim['claim_type'])
        self.log(log, "RAG", f"{claim['claim_type']} policy, limit ${policy['max_coverage']:,}")

        # Pattern 7: tools + decision
        decision, tool_log = self.decide(claim, plan, route, policy)
        self.log(log, "TOOLS", f"{len(tool_log)} tool calls: {', '.join(t['tool'] for t in tool_log) or 'none'}")
        self.log(log, "DECISION", f"{decision['decision']} ({decision['confidence']:.0%}, risk {decision['risk_level']})")
        original = dict(decision)

        # Pattern 6: reflect and maybe revise
        reflection = reflect_on_decision(claim, decision, self.client)
        rating = reflection.get('rating')
        revised = False
        if isinstance(rating, (int, float)) and rating < REVISE_BELOW_RATING:
            decision["decision"] = reflection.get("revised_decision") or decision["decision"]
            try:
                decision["confidence"] = float(reflection.get("revised_confidence", decision["confidence"]))
            except (TypeError, ValueError):
                pass
            decision["reasoning"] = reflection.get("revised_reasoning", decision["reasoning"])
            revised = True
        self.log(log, "REFLECTION", f"rating {rating}/10, {'decision revised' if revised else 'kept'}")

        # Pattern 4: guardrails on the (possibly revised) decision
        guard = check_guardrails(claim, decision["decision"])
        if not guard["overall_passed"]:
            decision["decision"] = "MANUAL_REVIEW"
            decision["reasoning"] += f" Guardrail override: {', '.join(guard['failed_checks'])}."
        self.log(log, "GUARDRAILS", "passed" if guard["overall_passed"] else f"FAILED: {', '.join(guard['failed_checks'])}")

        # Pattern 5: human escalation
        esc = should_escalate(claim, decision["confidence"], decision["risk_level"], repeat)
        if esc["escalate"]:
            decision["decision"] = "MANUAL_REVIEW"
        self.log(log, "ESCALATION", "human review: " + ("; ".join(esc["reasons"]) if esc["escalate"] else "not needed"))

        # Pattern 8 (write): remember this claim
        self.memory.process_claim(claim, decision["decision"], decision["confidence"],
                                  quiet=not self.verbose)

        return {
            "claim_id": claim['claim_id'],
            "final_decision": decision["decision"],
            "confidence": decision["confidence"],
            "risk_level": decision["risk_level"],
            "reasoning": decision["reasoning"],
            "route": route,
            "plan": plan,
            "policy": policy,
            "tool_calls": tool_log,
            "original_decision": original,
            "reflection": reflection,
            "decision_revised": revised,
            "guardrails": guard,
            "escalation": esc,
            "repeat_claimant": repeat,
            "processing_log": log,
        }


def main():
    print_section("🏢 COMPLETE INSURANCE CLAIM SYSTEM", "All 8 patterns in one pipeline")

    try:
        system = InsuranceClaimSystem()
        claims = SAMPLE_CLAIMS[:2]
        results = []

        for i, claim in enumerate(claims, 1):
            print(f"\n\n  CLAIM {i} of {len(claims)}")
            result = system.process_claim(claim)
            results.append(result)

            print_section("📊 RESULT SUMMARY")
            print_result("Claim ID", result['claim_id'])
            print_result("Route", result['route']['route'])
            print_result("Decision", result['final_decision'])
            print_result("Confidence", f"{result['confidence']:.0%}")
            print_result("Risk level", result['risk_level'])
            print_result("Reflection", f"{result['reflection'].get('rating')}/10"
                         + (" (decision revised)" if result['decision_revised'] else ""))
            print_result("Guardrails", "✓ PASSED" if result['guardrails']['overall_passed'] else "✗ FAILED")
            print_result("Escalated", "YES" if result['escalation']['escalate'] else "NO")
            print_result("Reasoning", result['reasoning'])

        print_section("FINAL SUMMARY")
        print(f"  Total claims processed: {len(results)}")
        for label in ("APPROVED", "REJECTED", "MANUAL_REVIEW"):
            print(f"  {label.title().replace('_', ' ')}: {sum(r['final_decision'] == label for r in results)}")
        print(f"  Escalated to a human: {sum(r['escalation']['escalate'] for r in results)}")
        print("\n✓ You've seen all 8 patterns working together!")

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
