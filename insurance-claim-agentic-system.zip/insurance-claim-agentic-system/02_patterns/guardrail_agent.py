"""
Pattern 4: Guardrail Agent - Compliance & safety checks
Uses Claude: NO (rule-based on purpose)

What this does:
  Guardrails are fixed business rules that run AFTER the AI proposes a
  decision and BEFORE it is final. Even if the AI says "APPROVED",
  a guardrail changes it to MANUAL_REVIEW if the claim breaks a rule.

  Guardrails are deliberately plain code, not AI: a compliance rule must
  give the same answer every time and must not be talked out of by a prompt.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS, validate_claim_data
from policy_rules import POLICIES, get_policy, HIGH_VALUE_APPROVAL_LIMIT, VALID_DECISIONS


def check_guardrails(claim: dict, proposed_decision: str) -> dict:
    """
    Run all compliance checks on a claim.
    Returns overall pass/fail, the final decision and each check's detail.
    """
    checks = {}
    policy = get_policy(claim.get('claim_type', 'Auto'))

    # Check 1: Data completeness and positive amount
    is_valid, msg = validate_claim_data(claim)
    checks['data_valid'] = {"passed": is_valid, "detail": msg}
    amount = claim.get('claim_amount', 0) or 0

    # Check 2: Amount within the policy's coverage limit
    limit = policy['max_coverage']
    checks['within_coverage_limit'] = {
        "passed": 0 < amount <= limit,
        "detail": f"${amount:,.2f} vs limit ${limit:,.2f}",
    }

    # Check 3: Filed within the policy's filing window
    days = claim.get('days_since_incident')
    window = policy['filing_window_days']
    if days is None:
        checks['filed_on_time'] = {"passed": False, "detail": "Incident date unknown"}
    else:
        checks['filed_on_time'] = {"passed": days <= window,
                                   "detail": f"{days} days vs {window}-day window"}

    # Check 4: The AI may not approve high-value claims on its own
    decision = str(proposed_decision).upper()
    needs_signoff = decision == "APPROVED" and amount > HIGH_VALUE_APPROVAL_LIMIT
    checks['high_value_signoff'] = {
        "passed": not needs_signoff,
        "detail": (f"Approvals over ${HIGH_VALUE_APPROVAL_LIMIT:,} need manual sign-off"
                   if needs_signoff else "No high-value override needed"),
    }

    # Check 5: Decision is one of the allowed values
    checks['valid_decision'] = {"passed": decision in VALID_DECISIONS,
                                "detail": f"'{decision}'"}

    overall_passed = all(c['passed'] for c in checks.values())
    return {
        "overall_passed": overall_passed,
        "final_decision": decision if overall_passed else "MANUAL_REVIEW",
        "failed_checks": [name for name, c in checks.items() if not c['passed']],
        "checks": checks,
    }


if __name__ == "__main__":
    print_section("🛡️ Pattern 4: Guardrail Agent",
                  "Rule-based safety checks that protect against bad decisions")

    print("Coverage limits and filing windows by type:")
    for ctype, p in POLICIES.items():
        print(f"  {ctype:<10} ${p['max_coverage']:>12,.0f}   {p['filing_window_days']:>3} days")

    late_claim = dict(SAMPLE_CLAIMS[0], claim_id="CLM-001-LATE", days_since_incident=45)
    test_cases = [
        (SAMPLE_CLAIMS[0], "APPROVED"),   # $5k Auto, on time         -> pass
        (SAMPLE_CLAIMS[1], "APPROVED"),   # $75k Property              -> pass
        (SAMPLE_CLAIMS[3], "APPROVED"),   # $150k Liability approval   -> fail (high value)
        (late_claim, "APPROVED"),         # Auto filed after 45 days   -> fail (late)
    ]

    for claim, decision in test_cases:
        print(f"\n{'─' * 60}")
        print(f"Claim {claim['claim_id']} | {claim['claim_type']} | "
              f"${claim['claim_amount']:,.2f} | Proposed: {decision}")

        result = check_guardrails(claim, decision)
        status = "✅ ALL PASSED" if result['overall_passed'] else "❌ GUARDRAIL FAILED"
        print(f"  Result: {status}  →  Final decision: {result['final_decision']}")
        for name, check in result['checks'].items():
            icon = "  ✓" if check['passed'] else "  ✗"
            print(f"{icon} {name}: {check['detail']}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
