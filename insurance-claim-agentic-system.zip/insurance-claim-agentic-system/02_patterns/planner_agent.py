"""
Pattern 1: Planner Agent - Goal-oriented task decomposition
Uses Claude: YES

What this does:
  Before processing a claim, the AI first creates a step-by-step PLAN.
  This is like a project manager breaking a big task into smaller ones.
  The full system passes this plan into the decision step.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS, ask_claude, parse_json, get_client, format_claim_data

FALLBACK_PLAN = {
    "complexity": "medium",
    "estimated_days": 5,
    "plan": [
        {"step": 1, "action": "Verify policy coverage", "outcome": "Coverage confirmed", "time": "1 hour"},
        {"step": 2, "action": "Collect documents", "outcome": "Documents received", "time": "2 days"},
        {"step": 3, "action": "Assess claim", "outcome": "Assessment complete", "time": "1 day"},
        {"step": 4, "action": "Make decision", "outcome": "Decision issued", "time": "1 hour"},
    ],
}


def create_processing_plan(claim: dict, client=None) -> dict:
    """Ask Claude to create a step-by-step plan for processing this claim."""
    client = client or get_client()

    prompt = f"""You are a claims processing manager. Create a step-by-step plan to process this claim.

{format_claim_data(claim)}

Create a plan with 4-5 steps. Return ONLY valid JSON in this exact format:
{{
  "complexity": "low | medium | high",
  "estimated_days": 3,
  "plan": [
    {{"step": 1, "action": "Verify policy", "outcome": "Confirm coverage", "time": "1 hour"}}
  ]
}}"""

    plan = parse_json(ask_claude(client, prompt, max_tokens=800))
    if not plan or "plan" not in plan:
        return dict(FALLBACK_PLAN, note="Fallback plan used: Claude's reply was not valid JSON")
    return plan


if __name__ == "__main__":
    print_section("📋 Pattern 1: Planner Agent",
                  "Breaking claims into step-by-step processing plans")

    client = get_client()
    for claim in SAMPLE_CLAIMS[:2]:
        print(f"\n{'─' * 60}")
        print(f"Planning for: {claim['claim_id']} | {claim['claim_type']} | ${claim['claim_amount']:,.2f}")

        plan = create_processing_plan(claim, client)

        print(f"  Complexity:      {str(plan.get('complexity', 'N/A')).upper()}")
        print(f"  Estimated days:  {plan.get('estimated_days', 'N/A')}")
        print("\n  Processing steps:")
        for step in plan.get('plan', []):
            print(f"    Step {step.get('step')}: {step.get('action')}")
            print(f"             → {step.get('outcome')}  ({step.get('time', '')})")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
