"""
Pattern 2: Router Agent - Intelligent routing
Uses Claude: YES (with a rule-based safety net)

What this does:
  Looks at each claim and decides which processing "lane" it belongs in,
  using the claim type, amount and description.
  Small simple claims go to the FAST lane, very large ones to EXECUTIVE.
  If Claude's answer is not one of the valid lanes, a simple amount rule
  is used instead, so the system never gets stuck.
"""

import sys
import json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS, ask_claude, parse_json, get_client
from policy_rules import ROUTES, route_by_amount


class ClaimRouter:
    def __init__(self, client=None):
        self.client = client or get_client()
        self.routes = ROUTES

    def route(self, claim: dict) -> dict:
        """Ask Claude which route this claim should take. Returns {route, reasoning, source}."""
        prompt = f"""You are a claim routing specialist.

Claim details:
  - Type:        {claim['claim_type']}
  - Amount:      ${claim['claim_amount']:,.2f}
  - Description: {claim['description']}

Available routes:
{json.dumps(self.routes, indent=2)}

Consider the amount, the claim type and anything in the description
(injury, legal action, emergency) that adds complexity.
Return ONLY JSON: {{"route": "<one route name>", "reasoning": "<one sentence>"}}"""

        answer = parse_json(ask_claude(self.client, prompt, max_tokens=300)) or {}
        route = str(answer.get("route", "")).upper().strip()

        if route in self.routes:
            return {"route": route, "reasoning": answer.get("reasoning", ""), "source": "claude"}

        # Safety net: fall back to the amount rule
        return {"route": route_by_amount(claim),
                "reasoning": "Fallback: Claude's answer was not a valid route, amount rule used",
                "source": "rule"}


if __name__ == "__main__":
    print_section("🔀 Pattern 2: Router Agent",
                  "Routing claims to the correct processing lane")

    router = ClaimRouter()

    print("Available routes:")
    for name, desc in router.routes.items():
        print(f"  {name:<10} {desc}")

    print("\n" + "-" * 60)
    print("Routing sample claims...\n")

    for claim in SAMPLE_CLAIMS[:4]:
        result = router.route(claim)
        print(f"Claim {claim['claim_id']}  |  {claim['claim_type']}  |  ${claim['claim_amount']:,.2f}")
        print(f"  ➜  ROUTE: {result['route']}  (decided by {result['source']})")
        print(f"     REASONING: {result['reasoning']}")
        print()

    print("✓ Complete!")
