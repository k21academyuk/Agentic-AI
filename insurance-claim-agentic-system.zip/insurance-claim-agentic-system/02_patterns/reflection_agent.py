"""
Pattern 6: Reflection Agent - AI reviews and improves its own decisions
Uses Claude: YES

What this does:
  After a decision is made, a second Claude call acts as a senior
  auditor: it rates the decision, lists what is weak or missing, and
  returns a REVISED decision. The full system adopts the revised decision
  when the original is rated below 7/10.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS, ask_claude, parse_json, get_client, format_claim_data

REVISE_BELOW_RATING = 7   # adopt the revised decision if the rating is below this


def reflect_on_decision(claim: dict, decision: dict, client=None) -> dict:
    """
    Ask Claude to critique a decision and return an improved one.
    Returns {rating, strengths, improvements, revised_decision, revised_confidence, revised_reasoning}
    """
    client = client or get_client()

    prompt = f"""You are a senior claims auditor reviewing an AI decision.

CLAIM:
{format_claim_data(claim)}

DECISION TO REVIEW:
  Decision:   {decision.get('decision')}
  Confidence: {decision.get('confidence')}
  Reasoning:  {decision.get('reasoning')}

Critique the decision: is anything missing, inconsistent or unjustified?
Then give your improved decision.
Return ONLY JSON:
{{"rating": 1-10, "strengths": "...", "improvements": "...",
  "revised_decision": "APPROVED | REJECTED | MANUAL_REVIEW",
  "revised_confidence": 0.0-1.0, "revised_reasoning": "..."}}"""

    result = parse_json(ask_claude(client, prompt, max_tokens=600))
    if not result:
        return {"rating": None, "improvements": "Reflection reply was not valid JSON",
                "revised_decision": decision.get('decision'),
                "revised_confidence": decision.get('confidence'),
                "revised_reasoning": decision.get('reasoning')}
    result['revised_decision'] = str(result.get('revised_decision', '')).upper()
    return result


if __name__ == "__main__":
    print_section("🔍 Pattern 6: Reflection Agent",
                  "AI critiques a decision and returns an improved one")

    client = get_client()
    samples = [
        ("Well-reasoned decision", SAMPLE_CLAIMS[0], {
            "decision": "APPROVED", "confidence": 0.88,
            "reasoning": "Auto claim for $5,000, within the $100,000 limit, filed after 3 days. "
                         "No injuries, no fraud indicators, active policy."}),
        ("Weak / vague decision", SAMPLE_CLAIMS[1], {
            "decision": "APPROVED", "confidence": 0.60,
            "reasoning": "Claim looks okay."}),
    ]

    for label, claim, decision in samples:
        print(f"\n{'─' * 60}")
        print(f"Reviewing: {label}  ({claim['claim_id']}, ${claim['claim_amount']:,.0f})")
        print(f"  Original:  {decision['decision']} ({decision['confidence']:.0%}) - {decision['reasoning']}")

        r = reflect_on_decision(claim, decision, client)
        print("\n  AI self-reflection:")
        print(f"    Rating:       {r.get('rating')}/10")
        print(f"    Strengths:    {r.get('strengths', 'N/A')}")
        print(f"    Improvements: {r.get('improvements', 'N/A')}")
        print("\n  Improved final decision:")
        print(f"    Decision:     {r.get('revised_decision')}")
        print(f"    Confidence:   {r.get('revised_confidence')}")
        print(f"    Reasoning:    {r.get('revised_reasoning')}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
