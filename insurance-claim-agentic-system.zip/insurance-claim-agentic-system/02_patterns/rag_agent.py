"""
Pattern 3: RAG Agent - Knowledge Retrieval
Uses Claude: YES

What is RAG?
  RAG = Retrieval-Augmented Generation.
  Instead of relying only on Claude's general training, we first
  RETRIEVE the relevant policy rules, then pass them to Claude so it can
  GENERATE an answer grounded in those rules.

  In this lab the "knowledge base" is the POLICIES dictionary in
  policy_rules.py (simulated retrieval). In production you would use a
  vector store or Amazon Bedrock Knowledge Bases over real policy documents.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS, ask_claude, get_client, format_claim_data
from policy_rules import POLICIES, get_policy


def retrieve_policy(claim_type: str) -> dict:
    """Step 1 of RAG: RETRIEVE the policy rules for this claim type."""
    if claim_type not in POLICIES:
        print(f"  ⚠️  No policy found for '{claim_type}', using Auto policy.")
    return get_policy(claim_type)


def analyze_with_knowledge(claim: dict, client=None) -> str:
    """Step 2 of RAG: GENERATE an answer using the retrieved policy."""
    client = client or get_client()
    policy = retrieve_policy(claim['claim_type'])

    prompt = f"""You are an insurance policy analyst.

CLAIM:
{format_claim_data(claim)}

RETRIEVED POLICY RULES:
  Max coverage:   ${policy['max_coverage']:,.2f}
  Deductible:     ${policy['deductible']:,.2f}
  Filing window:  {policy['filing_window_days']} days
  Required docs:  {', '.join(policy['required_docs'])}
  Rules:          {policy['rules']}
  Turnaround:     {policy['turnaround']}

Using ONLY the policy rules above, answer in plain text (no markdown):
1. Is this claim within the coverage limit and filing window?
2. Which documents are required?
3. What is your recommendation, and which rule supports it?"""

    return ask_claude(client, prompt, max_tokens=500)


if __name__ == "__main__":
    print_section("📚 Pattern 3: RAG Agent",
                  "Retrieve policy knowledge, then generate a grounded answer")

    client = get_client()
    for claim in SAMPLE_CLAIMS[:4]:
        print(f"\n{'─' * 60}")
        print(f"Claim {claim['claim_id']} | {claim['claim_type']} | ${claim['claim_amount']:,.2f}")

        policy = retrieve_policy(claim['claim_type'])
        print(f"  📖 Retrieved policy: max ${policy['max_coverage']:,.2f}, "
              f"deductible ${policy['deductible']:,.2f}, "
              f"filing window {policy['filing_window_days']} days")

        print("  🤖 Asking Claude to analyze with this context...")
        print(f"\n{analyze_with_knowledge(claim, client).strip()}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
