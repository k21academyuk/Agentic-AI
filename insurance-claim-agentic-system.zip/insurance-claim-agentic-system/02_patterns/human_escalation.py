"""
Pattern 5: Human Escalation - Knowing when AI should step aside
Uses Claude: NO (rule-based on purpose)

What this does:
  Not every claim should be decided by AI alone. This pattern applies
  clear rules to decide when a human expert must review the decision.
  It uses the AI's own confidence and risk level as inputs.

  Key insight: good AI systems know their own limits.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS
from policy_rules import ESCALATION_CONFIDENCE, ESCALATION_AMOUNT, EXECUTIVE_AMOUNT


def should_escalate(claim: dict, ai_confidence: float, risk_level: str = "LOW",
                    repeat_claimant: bool = False) -> dict:
    """Decide whether this claim needs human review. Returns the decision and all reasons."""
    reasons = []
    amount = claim['claim_amount']

    if ai_confidence < ESCALATION_CONFIDENCE:
        reasons.append(f"Low AI confidence ({ai_confidence:.0%}), threshold is {ESCALATION_CONFIDENCE:.0%}")
    if amount > ESCALATION_AMOUNT:
        reasons.append(f"High value claim (${amount:,.2f} > ${ESCALATION_AMOUNT:,})")
    if claim['claim_type'] == 'Liability':
        reasons.append("Liability claims require legal review")
    if str(risk_level).upper() == "HIGH":
        reasons.append("AI rated fraud/risk level HIGH")
    if repeat_claimant:
        reasons.append("Claimant has filed multiple claims recently")
    if amount > EXECUTIVE_AMOUNT:
        reasons.append(f"Amount exceeds ${EXECUTIVE_AMOUNT:,}, executive approval required")

    escalate = len(reasons) > 0
    return {
        "escalate": escalate,
        "action": "👤 HUMAN REVIEW REQUIRED" if escalate else "🤖 AUTO-PROCESS",
        "reasons": reasons,
        "urgency": "HIGH" if amount > 100_000 else "NORMAL",
    }


if __name__ == "__main__":
    print_section("👤 Pattern 5: Human Escalation",
                  "Identifying which claims need human expert review")

    test_cases = [
        (SAMPLE_CLAIMS[0], 0.95, "LOW", "Simple auto claim, high confidence"),
        (SAMPLE_CLAIMS[0], 0.60, "LOW", "Simple auto claim, low confidence"),
        (SAMPLE_CLAIMS[1], 0.88, "MEDIUM", "Large property claim, high confidence"),
        (SAMPLE_CLAIMS[2], 0.90, "LOW", "Health claim, high confidence"),
        (SAMPLE_CLAIMS[3], 0.70, "HIGH", "Liability claim, medium confidence"),
    ]

    for claim, confidence, risk, label in test_cases:
        print(f"\n{'─' * 60}")
        print(f"Scenario: {label}")
        print(f"  Claim:      {claim['claim_id']} | {claim['claim_type']} | ${claim['claim_amount']:,.2f}")
        print(f"  Confidence: {confidence:.0%}   Risk: {risk}")

        result = should_escalate(claim, confidence, risk)
        print(f"  Decision:   {result['action']}")
        for r in result['reasons']:
            print(f"    • {r}")
        if result['escalate']:
            print(f"  Urgency:    {result['urgency']}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
