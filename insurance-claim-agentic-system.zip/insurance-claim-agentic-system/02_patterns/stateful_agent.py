"""
Pattern 8: Stateful Agent - Memory across multiple claims
Uses Claude: NO (memory store used by the other agents)

What this does:
  A stateless agent forgets everything after each claim.
  A stateful agent REMEMBERS what it has processed and uses that history
  on future claims. Example: if the same person files several claims,
  the memory flags it, and the full system escalates the next one.

  Locally the memory is saved to claim_memory.json, so it survives
  restarts. On AWS the same idea is implemented with Amazon S3.
"""

import json
import sys
from datetime import datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS
from policy_rules import REPEAT_CLAIM_THRESHOLD


class StatefulClaimAgent:
    """Remembers every claim it has processed, optionally saved to a JSON file."""

    def __init__(self, memory_file: Path = None):
        self.memory_file = memory_file
        self.memory = {}          # claim_id -> stored record
        if memory_file and Path(memory_file).exists():
            self.memory = json.loads(Path(memory_file).read_text())

    def _save(self):
        if self.memory_file:
            Path(self.memory_file).write_text(json.dumps(self.memory, indent=2))

    def process_claim(self, claim: dict, decision: str, confidence: float, quiet: bool = False):
        """Store a processed claim in memory."""
        self.memory[claim['claim_id']] = {
            "claim": claim, "decision": decision, "confidence": confidence,
            "processed": datetime.now().isoformat(timespec="seconds"),
        }
        self._save()
        if not quiet:
            print(f"  💾 Stored: {claim['claim_id']} → {decision} ({confidence:.0%} confidence)")

    def recall(self, claim_id: str) -> dict:
        """Retrieve a stored claim by ID."""
        return self.memory.get(claim_id)

    def get_claimant_history(self, name: str) -> list:
        """All stored claims filed by one person."""
        return [m for m in self.memory.values() if m['claim'].get('claimant_name') == name]

    def is_repeat_claimant(self, name: str) -> bool:
        """True if this person already has REPEAT_CLAIM_THRESHOLD or more claims in memory."""
        return len(self.get_claimant_history(name)) >= REPEAT_CLAIM_THRESHOLD

    def flag_repeat_claimants(self) -> list:
        """Claimants with REPEAT_CLAIM_THRESHOLD or more claims (a fraud signal)."""
        counts = {}
        for m in self.memory.values():
            name = m['claim'].get('claimant_name')
            counts[name] = counts.get(name, 0) + 1
        return [(n, c) for n, c in counts.items() if c >= REPEAT_CLAIM_THRESHOLD]

    def summary(self) -> dict:
        decisions = [m['decision'] for m in self.memory.values()]
        return {
            "total_processed": len(decisions),
            "approved": decisions.count("APPROVED"),
            "rejected": decisions.count("REJECTED"),
            "manual_review": decisions.count("MANUAL_REVIEW"),
            "unique_claimants": len({m['claim'].get('claimant_name') for m in self.memory.values()}),
        }


if __name__ == "__main__":
    print_section("💾 Pattern 8: Stateful Agent",
                  "Memory that persists across multiple claim decisions")

    agent = StatefulClaimAgent()   # in-memory only for this demo

    sample_decisions = [("APPROVED", 0.90), ("MANUAL_REVIEW", 0.72), ("APPROVED", 0.85),
                        ("MANUAL_REVIEW", 0.65), ("APPROVED", 0.88)]

    print("Processing claims and storing in memory...\n")
    for claim, (decision, confidence) in zip(SAMPLE_CLAIMS, sample_decisions):
        agent.process_claim(claim, decision, confidence)

    print(f"\n{'─' * 60}")
    print("Recalling CLM-001 from memory:")
    recalled = agent.recall("CLM-001")
    print(f"  Decision:    {recalled['decision']}")
    print(f"  Confidence:  {recalled['confidence']:.0%}")
    print(f"  Processed:   {recalled['processed']}")

    print(f"\n{'─' * 60}")
    print("Claimant history lookup - 'John Doe':")
    for entry in agent.get_claimant_history("John Doe"):
        c = entry['claim']
        print(f"  {c['claim_id']} | ${c['claim_amount']:,.2f} | {entry['decision']}")

    print(f"\n{'─' * 60}")
    print(f"Checking for repeat claimants ({REPEAT_CLAIM_THRESHOLD}+ claims):")
    for name, count in agent.flag_repeat_claimants() or [("None", 0)]:
        print(f"  ⚠️  {name}: {count} claims filed" if count else "  No repeat claimants found.")

    print(f"\n{'─' * 60}")
    print("Memory summary:")
    for key, val in agent.summary().items():
        print(f"  {key}: {val}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
