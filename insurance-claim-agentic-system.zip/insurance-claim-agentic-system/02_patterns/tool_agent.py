"""
Pattern 7: Tool Agent - Claude calls external systems
Uses Claude: YES (Claude tool use)

What this does:
  Real insurance systems call databases and services to get facts.
  Here we give Claude three TOOLS and let Claude decide which to call:
    • policy_lookup   -> Is this policy valid? What is the coverage?
    • fraud_check     -> Any suspicious patterns?
    • claims_history  -> How many claims has this person filed?

  Claude replies with a "tool_use" request, our Python code runs the tool,
  sends the result back, and Claude continues until it has an answer.
  The tools return simulated data; in production they would call real APIs.
"""

import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS, get_client, format_claim_data
from policy_rules import POLICIES


# ----------------------------------------------------------------------
# The tools (plain Python functions with simulated data)
# ----------------------------------------------------------------------
FAKE_POLICIES = {
    "POL-12345": {"claim_type": "Auto", "active": True, "years_active": 5},
    "POL-67890": {"claim_type": "Property", "active": True, "years_active": 2},
    "POL-11111": {"claim_type": "Health", "active": True, "years_active": 8},
    "POL-22222": {"claim_type": "Liability", "active": True, "years_active": 1},
}

FAKE_HISTORY = {
    "John Doe":       {"total_claims": 2, "last_date": "2026-06-15", "approved": 2, "rejected": 0},
    "Jane Smith":     {"total_claims": 1, "last_date": "2025-11-01", "approved": 1, "rejected": 0},
    "Bob Johnson":    {"total_claims": 4, "last_date": "2026-09-05", "approved": 3, "rejected": 1},
    "Alice Williams": {"total_claims": 0, "last_date": None, "approved": 0, "rejected": 0},
}


def policy_lookup(policy_number: str) -> dict:
    """Simulate looking up a policy in the policy database."""
    record = FAKE_POLICIES.get(policy_number)
    if not record:
        return {"valid": False, "active": False, "coverage": 0, "deductible": 0}
    policy = POLICIES[record["claim_type"]]
    return {"valid": True, "active": record["active"], "claim_type": record["claim_type"],
            "years_active": record["years_active"], "coverage": policy["max_coverage"],
            "deductible": policy["deductible"]}


def claims_history(claimant_name: str) -> dict:
    """Simulate checking a claimant's past claims."""
    return FAKE_HISTORY.get(claimant_name,
                            {"total_claims": 0, "last_date": None, "approved": 0, "rejected": 0})


def fraud_check(claim_amount: float, description: str, claimant_name: str) -> dict:
    """Simulate a fraud-scoring API. Scores are whole points to avoid rounding surprises."""
    points, flags = 10, []                       # base risk 10 points
    if claim_amount > 80_000:
        points += 20
        flags.append("Large claim amount")
    if any(w in description.lower() for w in ("urgent", "emergency", "cash")):
        points += 10
        flags.append("Urgency language in description")
    if claims_history(claimant_name)["total_claims"] >= 3:
        points += 20
        flags.append("3 or more previous claims")
    level = "HIGH" if points >= 50 else "MODERATE" if points >= 30 else "LOW"
    return {"risk_score": points / 100, "risk_level": level, "flags": flags,
            "recommendation": "INVESTIGATE" if level == "HIGH" else "PROCEED"}


TOOL_FUNCTIONS = {
    "policy_lookup": policy_lookup,
    "fraud_check": fraud_check,
    "claims_history": claims_history,
}

# Tool definitions that tell Claude what each tool does and what it needs
TOOLS = [
    {
        "name": "policy_lookup",
        "description": "Look up an insurance policy. Returns whether it is valid and active, its coverage limit and deductible.",
        "input_schema": {"type": "object",
                         "properties": {"policy_number": {"type": "string"}},
                         "required": ["policy_number"]},
    },
    {
        "name": "fraud_check",
        "description": "Score a claim for fraud risk. Returns risk_score (0-1), risk_level and any flags.",
        "input_schema": {"type": "object",
                         "properties": {"claim_amount": {"type": "number"},
                                        "description": {"type": "string"},
                                        "claimant_name": {"type": "string"}},
                         "required": ["claim_amount", "description", "claimant_name"]},
    },
    {
        "name": "claims_history",
        "description": "Get a claimant's previous claims: total, last date, approved and rejected counts.",
        "input_schema": {"type": "object",
                         "properties": {"claimant_name": {"type": "string"}},
                         "required": ["claimant_name"]},
    },
]


# ----------------------------------------------------------------------
# The tool-use loop
# ----------------------------------------------------------------------
def _block_to_dict(block) -> dict:
    if block.type == "tool_use":
        return {"type": "tool_use", "id": block.id, "name": block.name, "input": block.input}
    return {"type": "text", "text": block.text}


def run_tool_loop(client, prompt: str, max_turns: int = 6, max_tokens: int = 1024):
    """
    Send a prompt to Claude with the tools available.
    Runs every tool Claude asks for, until Claude gives a final answer.
    Returns (final_text, tool_log).
    """
    from config import Config
    messages = [{"role": "user", "content": prompt}]
    tool_log = []

    for _ in range(max_turns):
        response = client.messages.create(
            model=Config.CLAUDE_MODEL, max_tokens=max_tokens,
            tools=TOOLS, messages=messages)

        if response.stop_reason != "tool_use":
            text = "".join(b.text for b in response.content if b.type == "text")
            return text, tool_log

        messages.append({"role": "assistant",
                         "content": [_block_to_dict(b) for b in response.content]})
        results = []
        for block in response.content:
            if block.type != "tool_use":
                continue
            func = TOOL_FUNCTIONS.get(block.name)
            output = func(**block.input) if func else {"error": f"Unknown tool {block.name}"}
            tool_log.append({"tool": block.name, "input": block.input, "output": output})
            results.append({"type": "tool_result", "tool_use_id": block.id,
                            "content": json.dumps(output)})
        messages.append({"role": "user", "content": results})

    return "Stopped: too many tool calls without a final answer.", tool_log


def run_tool_agent(claim: dict, client=None):
    """Let Claude investigate a claim with the tools. Returns (assessment_text, tool_log)."""
    client = client or get_client()
    prompt = f"""You are an insurance claims investigator.
Use the available tools to check the policy, the fraud risk and the claimant's history,
then give a short assessment (3-4 sentences, plain text) of whether the claim looks legitimate.

{format_claim_data(claim)}"""
    return run_tool_loop(client, prompt)


if __name__ == "__main__":
    print_section("🔧 Pattern 7: Tool Agent",
                  "Claude decides which external systems to call")

    client = get_client()
    for claim in SAMPLE_CLAIMS[:4]:
        print(f"\n{'─' * 60}")
        print(f"Claim {claim['claim_id']} | {claim['claimant_name']} | ${claim['claim_amount']:,.2f}")

        assessment, log = run_tool_agent(claim, client)
        for call in log:
            print(f"  🔧 Claude called {call['tool']}({json.dumps(call['input'])})")
            print(f"     → {json.dumps(call['output'])}")
        print(f"\n  Assessment: {assessment.strip()}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
