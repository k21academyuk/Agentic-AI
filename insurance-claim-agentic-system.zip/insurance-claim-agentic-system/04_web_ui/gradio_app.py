"""Gradio Web UI - alternative interface for the same 8-pattern pipeline"""
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "01_local_demo"))

import gradio as gr
from config import Config
from full_system import InsuranceClaimSystem
from stateful_agent import StatefulClaimAgent

_system = None


def get_system():
    global _system
    if _system is None:
        _system = InsuranceClaimSystem(memory=StatefulClaimAgent(Config.MEMORY_FILE), verbose=False)
    return _system


def analyze_claim(claim_id, claim_type, amount, days, claimant, policy_number, description):
    claim = {
        "claim_id": claim_id, "claim_type": claim_type, "claim_amount": float(amount or 0),
        "claim_date": date.today().isoformat(), "days_since_incident": int(days or 0),
        "description": description, "policy_number": policy_number, "claimant_name": claimant,
    }
    r = get_system().process_claim(claim)
    summary = (
        f"### Decision: {r['final_decision']}\n"
        f"**Confidence:** {r['confidence']:.0%} · **Risk level:** {r['risk_level']} · "
        f"**Route:** {r['route']['route']} · "
        f"**Escalated:** {'YES' if r['escalation']['escalate'] else 'NO'}\n\n"
        f"**Reasoning:** {r['reasoning']}"
    )
    details = {
        "tool_calls": r["tool_calls"],
        "reflection": r["reflection"],
        "guardrails_failed": r["guardrails"]["failed_checks"],
        "escalation_reasons": r["escalation"]["reasons"],
        "processing_log": r["processing_log"],
    }
    return summary, details


demo = gr.Interface(
    fn=analyze_claim,
    inputs=[
        gr.Textbox(label="Claim ID", value="CLM-201"),
        gr.Dropdown(["Auto", "Property", "Health", "Liability"], label="Type", value="Property"),
        gr.Number(label="Amount ($)", value=12000),
        gr.Number(label="Days since incident", value=6),
        gr.Textbox(label="Claimant name", value="Jane Smith"),
        gr.Textbox(label="Policy number", value="POL-67890"),
        gr.Textbox(label="Description", lines=3,
                   value="Water damage from a burst pipe in the kitchen. Plumber's report attached."),
    ],
    outputs=[gr.Markdown(label="Result"), gr.JSON(label="Pipeline details")],
    title="🏢 Insurance Claim Analyzer",
    description=f"Runs the full 8-pattern pipeline with {Config.CLAUDE_MODEL}. Each claim takes about 20-40 seconds.",
    flagging_mode="never",
)

if __name__ == "__main__":
    demo.launch()
