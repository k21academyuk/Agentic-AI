"""Streamlit Web UI - runs the full 8-pattern pipeline on each claim"""
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "01_local_demo"))

import streamlit as st
from config import Config
from full_system import InsuranceClaimSystem
from stateful_agent import StatefulClaimAgent

st.set_page_config(page_title="Insurance Claims AI", page_icon="🏢", layout="wide")
st.title("🏢 Insurance Claim Processing System")
st.caption(f"Multi-agent pipeline · model {Config.CLAUDE_MODEL} · memory saved to claim_memory.json")


@st.cache_resource
def get_system():
    """One pipeline for the whole app, so claim memory is shared between requests."""
    return InsuranceClaimSystem(memory=StatefulClaimAgent(Config.MEMORY_FILE), verbose=False)


# Sidebar: claim details
st.sidebar.header("Claim Details")
claim_id = st.sidebar.text_input("Claim ID", "CLM-101")
claim_type = st.sidebar.selectbox("Type", ["Auto", "Property", "Health", "Liability"])
amount = st.sidebar.number_input("Amount ($)", min_value=1, max_value=2_000_000, value=3200, step=100)
days = st.sidebar.number_input("Days since incident", min_value=0, max_value=365, value=4)
claimant = st.sidebar.text_input("Claimant name", "John Doe")
policy_number = st.sidebar.text_input("Policy number", "POL-12345")
description = st.sidebar.text_area(
    "Description", "Rear-end collision at a traffic light. No injuries. Photos attached.")

if st.sidebar.button("🔍 Analyze Claim", type="primary"):
    if not Config.ANTHROPIC_API_KEY:
        st.error("ANTHROPIC_API_KEY is not set. Add it to the .env file and restart.")
        st.stop()

    claim = {
        "claim_id": claim_id, "claim_type": claim_type, "claim_amount": float(amount),
        "claim_date": date.today().isoformat(), "days_since_incident": int(days),
        "description": description, "policy_number": policy_number, "claimant_name": claimant,
    }

    with st.spinner("Running 8-pattern pipeline (about 20-40 seconds)..."):
        result = get_system().process_claim(claim)

    decision = result["final_decision"]
    colour = {"APPROVED": st.success, "REJECTED": st.error}.get(decision, st.warning)
    colour(f"**Decision: {decision}**  ·  {result['reasoning']}")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Confidence", f"{result['confidence']:.0%}")
    c2.metric("Risk level", result["risk_level"])
    c3.metric("Route", result["route"]["route"])
    c4.metric("Escalated", "YES" if result["escalation"]["escalate"] else "NO")

    with st.expander("1 · Plan (Planner)"):
        st.json(result["plan"])
    with st.expander("2-3 · Route and policy (Router, RAG)"):
        st.write(result["route"])
        st.json(result["policy"])
    with st.expander(f"7 · Tool calls ({len(result['tool_calls'])})"):
        st.json(result["tool_calls"])
    with st.expander("6 · Reflection"):
        st.write("Original decision:", result["original_decision"])
        st.json(result["reflection"])
    with st.expander("4-5 · Guardrails and escalation"):
        st.json({"guardrails": result["guardrails"], "escalation": result["escalation"]})
    with st.expander("Processing log"):
        st.table(result["processing_log"])
