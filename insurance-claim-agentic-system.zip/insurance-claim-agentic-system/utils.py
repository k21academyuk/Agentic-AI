"""
Utility functions for the Insurance Claim Agentic System
"""
import json
import re
from typing import Any, Optional

import config  # noqa: F401  (loads .env and prints the configuration check once)


# ----------------------------------------------------------------------
# Claude helpers (used by every pattern)
# ----------------------------------------------------------------------

def get_client():
    """Create the Anthropic client from the key in config.py / .env."""
    import anthropic
    from config import Config
    return anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)


def ask_claude(client, prompt: str, max_tokens: int = 1024,
               system: Optional[str] = None) -> str:
    """Send one prompt to Claude and return the text of the reply."""
    from config import Config
    kwargs = dict(
        model=Config.CLAUDE_MODEL,
        max_tokens=max_tokens,
        messages=[{"role": "user", "content": prompt}],
    )
    if system:
        kwargs["system"] = system
    response = client.messages.create(**kwargs)
    return "".join(b.text for b in response.content if b.type == "text")


def parse_json(text: str) -> Optional[dict]:
    """
    Pull the first JSON object out of Claude's reply.
    Handles ```json fences and extra words around the JSON.
    Returns None if no valid JSON is found.
    """
    if not text:
        return None
    fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.DOTALL)
    if fenced:
        text = fenced.group(1)
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        return None
    try:
        return json.loads(text[start:end + 1])
    except json.JSONDecodeError:
        return None


# ----------------------------------------------------------------------
# Claim helpers
# ----------------------------------------------------------------------

def format_claim_data(claim: dict) -> str:
    """Format claim data for prompts and display"""
    return (
        f"Claim ID:      {claim.get('claim_id', 'N/A')}\n"
        f"Type:          {claim.get('claim_type', 'N/A')}\n"
        f"Amount:        ${claim.get('claim_amount', 0):,.2f}\n"
        f"Date:          {claim.get('claim_date', 'N/A')}\n"
        f"Days since incident: {claim.get('days_since_incident', 'N/A')}\n"
        f"Policy number: {claim.get('policy_number', 'N/A')}\n"
        f"Claimant:      {claim.get('claimant_name', 'N/A')}\n"
        f"Description:   {claim.get('description', 'N/A')}"
    )


def validate_claim_data(claim: dict) -> tuple:
    """
    Validate claim data completeness.
    Returns (is_valid, message)
    """
    required_fields = ['claim_id', 'claim_type', 'claim_amount', 'claim_date']
    for field in required_fields:
        if field not in claim or claim[field] in (None, ""):
            return False, f"Missing required field: {field}"
    if claim['claim_amount'] <= 0:
        return False, "Claim amount must be positive"
    return True, "Valid"


def print_section(title: str, content: str = ""):
    """Print a formatted section header"""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)
    if content:
        print(content)
    print()


def print_result(label: str, value: Any):
    """Print a result in a formatted way"""
    print(f"  {label}: {value}")


# ----------------------------------------------------------------------
# Sample claim data
# ----------------------------------------------------------------------
SAMPLE_CLAIMS = [
    {
        "claim_id": "CLM-001",
        "claim_type": "Auto",
        "claim_amount": 5000,
        "claim_date": "2026-09-15",
        "days_since_incident": 3,
        "description": "Minor fender bender in parking lot. No injuries.",
        "policy_number": "POL-12345",
        "claimant_name": "John Doe",
    },
    {
        "claim_id": "CLM-002",
        "claim_type": "Property",
        "claim_amount": 75000,
        "claim_date": "2026-09-20",
        "days_since_incident": 5,
        "description": "Severe storm damage to roof and windows. Emergency repairs needed.",
        "policy_number": "POL-67890",
        "claimant_name": "Jane Smith",
    },
    {
        "claim_id": "CLM-003",
        "claim_type": "Health",
        "claim_amount": 2500,
        "claim_date": "2026-09-22",
        "days_since_incident": 10,
        "description": "Routine medical procedure. Pre-authorized.",
        "policy_number": "POL-11111",
        "claimant_name": "Bob Johnson",
    },
    {
        "claim_id": "CLM-004",
        "claim_type": "Liability",
        "claim_amount": 150000,
        "claim_date": "2026-09-25",
        "days_since_incident": 2,
        "description": "Customer injured on business premises. Legal claim filed.",
        "policy_number": "POL-22222",
        "claimant_name": "Alice Williams",
    },
    {
        "claim_id": "CLM-005",
        "claim_type": "Auto",
        "claim_amount": 3200,
        "claim_date": "2026-10-01",
        "days_since_incident": 4,
        "description": "Rear-end collision at a traffic light. No injuries. Photos attached.",
        "policy_number": "POL-12345",
        "claimant_name": "John Doe",
    },
]


if __name__ == "__main__":
    for claim in SAMPLE_CLAIMS:
        print_section(claim["claim_id"], format_claim_data(claim))
        print("Valid:", validate_claim_data(claim))
