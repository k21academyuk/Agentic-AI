# Insurance Claim Agentic System

A multi-agent insurance claim processing system built with Anthropic's Claude API.
It shows 8 agentic design patterns on their own and connected into one pipeline,
with a Streamlit or Gradio web UI and offline tests.

Companion to the K21Academy hands-on lab
"Agentic AI on AWS: Build a Multi-Agent Insurance Claims System with Anthropic Claude".

## Requirements
- Python 3.10 or higher (3.11 or 3.12 recommended)
- An Anthropic API key

## Quick start
```bash
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env              # Windows: copy .env.example .env
# put your key in .env: ANTHROPIC_API_KEY=sk-ant-...
python 01_local_demo/basic_agent.py
```

## What is in the project

| Folder / file | What it does | Calls Claude |
| --- | --- | --- |
| `01_local_demo/basic_agent.py` | One agent analyses one claim | Yes |
| `01_local_demo/multi_agent.py` | Triage, risk, compliance and decision agents collaborate | Yes |
| `01_local_demo/full_system.py` | All 8 patterns connected into one pipeline | Yes |
| `02_patterns/planner_agent.py` | 1. Planner: step-by-step processing plan | Yes |
| `02_patterns/router_agent.py` | 2. Router: picks a processing lane (rule fallback) | Yes |
| `02_patterns/rag_agent.py` | 3. RAG: retrieves policy rules, then answers | Yes |
| `02_patterns/guardrail_agent.py` | 4. Guardrails: fixed compliance rules | No (by design) |
| `02_patterns/human_escalation.py` | 5. Human escalation rules | No (by design) |
| `02_patterns/reflection_agent.py` | 6. Reflection: critiques and revises a decision | Yes |
| `02_patterns/tool_agent.py` | 7. Tool use: Claude calls policy, fraud and history tools | Yes |
| `02_patterns/stateful_agent.py` | 8. Memory: remembers claims, flags repeat claimants | No (memory store) |
| `04_web_ui/` | Streamlit and Gradio apps that run the full pipeline | Yes |
| `05_testing/` | Offline tests with a fake Claude client (no API cost) | No |
| `policy_rules.py` | Every limit and threshold, in one place | - |
| `config.py`, `utils.py` | Settings and shared helpers | - |

## Run the web UI
```bash
streamlit run 04_web_ui/streamlit_app.py
# or
python 04_web_ui/gradio_app.py
```

## Run the tests
```bash
python 05_testing/test_all_patterns.py
python 05_testing/test_claim_delay.py
python 05_testing/test_rejection.py
# or all at once
pytest 05_testing -v
```

## Change the model
Set `CLAUDE_MODEL` in `.env`, for example `CLAUDE_MODEL=claude-sonnet-4-6`.
