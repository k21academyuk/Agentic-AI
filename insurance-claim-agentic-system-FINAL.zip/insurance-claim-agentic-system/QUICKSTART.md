# 🚀 Quick Start Guide - Complete Beginner Edition

## Step-by-Step Tutorial (30 minutes)

### Prerequisites
- Python 3.8+ installed
- Anthropic API key (get free at https://console.anthropic.com)
- Basic command line knowledge

---

## Part 1: Setup (5 minutes)

### 1. Open Terminal/Command Prompt

**Windows:**
- Press `Win + R`, type `cmd`, press Enter

**Mac/Linux:**
- Press `Cmd + Space`, type `terminal`, press Enter

### 2. Navigate to the Project

```bash
cd path/to/insurance-claim-agentic-system
```

### 3. Create Virtual Environment

```bash
# Create virtual environment
python -m venv venv

# Activate it
# On Windows:
venv\Scripts\activate

# On Mac/Linux:
source venv/bin/activate
```

You should see `(venv)` in your terminal prompt.

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

Wait for all packages to install (2-3 minutes).

### 5. Configure API Key

```bash
# Copy the example environment file
cp .env.example .env

# Edit .env file and add your key
# On Windows: notepad .env
# On Mac: open -e .env
# On Linux: nano .env
```

In the `.env` file, replace:
```
ANTHROPIC_API_KEY=your_anthropic_api_key_here
```

with your actual key:
```
ANTHROPIC_API_KEY=sk-ant-api03-...
```

Save and close the file.

---

## Part 2: Your First Agent (10 minutes)

### Run the Basic Agent

```bash
python 01_local_demo/basic_agent.py
```

**What you'll see:**
- Agent analyzes an insurance claim
- Provides decision (APPROVED/REJECTED/MANUAL_REVIEW)
- Shows confidence level
- Explains reasoning

**Understanding the Output:**
```
🤖 BASIC AGENT DEMO
Step 1: Creating AI agent...
✓ Agent created successfully!

Step 2: Selecting claim to analyze...
✓ Selected: CLM-001 - Auto claim for $5,000.00

Step 3: Analyzing claim with AI agent...
✓ Analysis complete!

📊 ANALYSIS RESULTS
  Claim ID: CLM-001
  Decision: APPROVED
  Confidence: 85%
  Reasoning: Minor accident, no injuries, within policy limits
  Red Flags: None
```

**Try This:**
Edit `basic_agent.py` line 125:
```python
claim = SAMPLE_CLAIMS[0]  # Change to [1], [2], or [3]
```

Run again to see different claims analyzed!

---

## Part 3: Multiple Agents (10 minutes)

### Run the Multi-Agent System

```bash
python 01_local_demo/multi_agent.py
```

**What happens:**
1. **Triage Agent** - Assesses priority
2. **Risk Agent** - Analyzes risks
3. **Compliance Agent** - Checks regulations
4. **Decision Agent** - Makes final decision

**Understanding the Flow:**
```
🤖 MULTI-AGENT SYSTEM DEMO
  
  🤖 Running Triage Agent...
  → Assigns priority: HIGH
  
  🤖 Running Risk Agent...
  → Risk assessment: MODERATE
  
  🤖 Running Compliance Agent...
  → Compliance check: COMPLIANT
  
  🤖 Running Decision Agent...
  → Final decision: APPROVED
```

**Why Multiple Agents?**
- Each specializes in one aspect
- Reduces bias (no single point of failure)
- More thorough analysis
- Better decisions

---

## Part 4: Complete System (10 minutes)

### Run the Full System

```bash
python 01_local_demo/full_system.py
```

**What you'll see:**
All 8 ABR patterns working together:

1. **Planner** - Creates processing plan
2. **Router** - Chooses processing path
3. **RAG** - Retrieves policy knowledge
4. **Guardrails** - Checks compliance
5. **Escalation** - Flags for human review
6. **Reflection** - Self-assesses quality
7. **Tools** - Calls external systems
8. **Stateful** - Remembers context

**Sample Output:**
```
🔄 PROCESSING CLAIM CLM-001

  📝 PLANNER: Creating processing plan
  📝 ROUTER: Determining processing route
  📝 RAG: Retrieving policy knowledge
  📝 TOOLS: Calling external tools
  🤔 Making decision...
  🛡️ Guardrails: ✓ PASSED
  👤 ESCALATION: No human review needed
  🔍 Self-reflection completed

📊 RESULT SUMMARY
  Claim ID: CLM-001
  Route: STANDARD_PATHWAY
  Decision: APPROVED
  Confidence: 85%
  Escalated: NO
  Guardrails: ✓ PASSED
```

---

## Part 5: Understanding the Patterns

### Test Individual Patterns

```bash
# Test each pattern individually
python 02_patterns/planner_agent.py      # Goal planning
python 02_patterns/router_agent.py       # Intelligent routing
python 02_patterns/rag_agent.py          # Knowledge retrieval
python 02_patterns/guardrail_agent.py    # Compliance checks
python 02_patterns/human_escalation.py   # Human review
python 02_patterns/reflection_agent.py   # Self-assessment
python 02_patterns/tool_agent.py         # Tool integration
python 02_patterns/stateful_agent.py     # Memory management
```

Each script is short and demonstrates one concept.

---

## Part 6: Web Interface (Optional)

### Launch Streamlit UI

```bash
streamlit run 04_web_ui/streamlit_app.py
```

This opens a web browser with an interactive interface!

**Features:**
- Enter claim details in forms
- Click buttons to analyze
- See visual results
- No coding required

---

## Common Issues & Solutions

### Issue 1: "Module not found"
```bash
# Solution: Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

### Issue 2: "API key not found"
```bash
# Solution: Check .env file exists and has correct key
cat .env  # Should show ANTHROPIC_API_KEY=sk-ant-...
```

### Issue 3: "Permission denied"
```bash
# Solution: Make sure virtual environment is activated
# You should see (venv) in your prompt
```

### Issue 4: "Port already in use" (for Streamlit)
```bash
# Solution: Use different port
streamlit run 04_web_ui/streamlit_app.py --server.port 8502
```

---

## What You've Learned

✅ How to set up a Python AI project
✅ How to call Claude API
✅ How single agents work
✅ How multiple agents collaborate
✅ All 8 ABR (Agentic Best Practices) patterns
✅ How to build production-ready systems

---

## Next Steps

### For Learning:
1. Read through the code in `01_local_demo/`
2. Modify prompts and see how output changes
3. Add your own sample claims in `utils.py`
4. Experiment with different agent prompts

### For Building:
1. Customize for your business rules
2. Add real database connections
3. Integrate with your systems
4. Deploy to cloud (see `06_deployment/`)

### For Production:
1. Add error handling
2. Implement logging
3. Add authentication
4. Set up monitoring
5. Deploy with Docker

---

## Getting Help

### Resources:
- **Project README**: `README.md`
- **Code Guide**: `COMPLETE_CODE_GUIDE.md`
- **Troubleshooting**: Check error messages carefully
- **Examples**: All code has comments explaining each step

### Tips:
- Start simple, add complexity gradually
- Read error messages - they tell you what's wrong
- Test with sample data first
- Use print statements to debug
- Google error messages

---

## Congratulations! 🎉

You've built a complete AI agentic system!

You now understand:
- How AI agents make decisions
- How to structure agent systems
- Industry best practices (ABR patterns)
- How to build production-ready AI

**Ready to build your own AI system?**
- Customize the claims for your domain
- Add your business logic
- Deploy and scale!
