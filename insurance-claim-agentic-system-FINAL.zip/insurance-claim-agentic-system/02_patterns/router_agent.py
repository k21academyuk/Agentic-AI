"""
ABR Pattern 2: Router Agent - Intelligent routing

What this does:
  Looks at each claim and decides which processing "lane" it belongs in.
  Think of it like a highway with different lanes for different vehicles.
  Small claims go to FAST lane, huge claims go to EXECUTIVE lane.

Learning Goal:
  Understand how AI can make routing decisions based on claim properties.
"""

import anthropic
import sys
import json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Config
from utils import print_section, SAMPLE_CLAIMS


class ClaimRouter:
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)
        self.routes = {
            "FAST":      "Amount < $5,000  → Auto-approve, no review needed",
            "STANDARD":  "Amount $5k-$50k  → Regular review process",
            "COMPLEX":   "Amount $50k-$100k → Detailed investigation required",
            "EXECUTIVE": "Amount > $100,000 → Executive sign-off required"
        }

    def route(self, claim):
        """Ask Claude which route this claim should take."""
        prompt = f"""You are a claim routing specialist.

Claim details:
  - Type:   {claim['claim_type']}
  - Amount: ${claim['claim_amount']:,.2f}
  - Description: {claim['description']}

Available routes:
{json.dumps(self.routes, indent=2)}

Reply in EXACTLY this format (no markdown, no bold):
ROUTE: [route name]
REASONING: [one sentence explanation]"""

        response = self.client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=300,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content[0].text

    def parse_route(self, result_text):
        """Extract just the route name from Claude's response."""
        for line in result_text.split('\n'):
            if line.startswith('ROUTE:'):
                return line.split(':', 1)[1].strip()
        return "STANDARD"  # safe default if parsing fails


if __name__ == "__main__":
    print_section("🔀 Pattern 2: Router Agent",
                  "Routing claims to the correct processing lane")

    router = ClaimRouter()

    print("Available routes:")
    for name, desc in router.routes.items():
        print(f"  {name}: {desc}")

    print("\n" + "-" * 60)
    print("Routing sample claims...\n")

    for claim in SAMPLE_CLAIMS:
        print(f"Claim {claim['claim_id']}:")
        print(f"  Type: {claim['claim_type']}  |  Amount: ${claim['claim_amount']:,.2f}")

        result = router.route(claim)
        route_name = router.parse_route(result)

        print(f"  ➜  {result.strip()}")
        print()

    print("✓ Complete!")
