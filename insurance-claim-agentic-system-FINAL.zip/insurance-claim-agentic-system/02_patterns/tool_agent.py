"""
ABR Pattern 7: Tool Agent - Calling external systems

What this does:
  Real insurance systems don't work in isolation — they call
  external databases and services to get information.
  This pattern simulates those "tool calls":
    • Policy database  → Is this policy valid? What's the coverage?
    • Fraud detection  → Any suspicious patterns?
    • Claims history   → How many claims has this person filed?

  In production these would be real API calls to live systems.
  Here we simulate them with realistic fake data.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS


def tool_policy_lookup(policy_number: str) -> dict:
    """Simulate looking up a policy in the database."""
    # In production: db.query("SELECT * FROM policies WHERE id = ?", policy_number)
    fake_policies = {
        "POL-12345": {"valid": True,  "coverage": 100_000, "deductible": 500,  "active": True},
        "POL-67890": {"valid": True,  "coverage": 500_000, "deductible": 1000, "active": True},
        "POL-11111": {"valid": True,  "coverage": 150_000, "deductible": 250,  "active": True},
        "POL-22222": {"valid": True,  "coverage": 1_000_000, "deductible": 2500, "active": True},
    }
    return fake_policies.get(policy_number, {"valid": False, "coverage": 0, "active": False})


def tool_fraud_check(claim: dict) -> dict:
    """Simulate a fraud detection API call."""
    # Simple rules — production would use an ML model
    risk_score = 0.10  # base risk

    if claim['claim_amount'] > 80_000:
        risk_score += 0.20   # large amounts are higher risk

    if 'urgent' in claim['description'].lower():
        risk_score += 0.10   # urgency language can be a flag

    flags = []
    if risk_score > 0.30:
        flags.append("High claim amount relative to policy history")

    return {
        "risk_score": round(risk_score, 2),
        "risk_level": "HIGH" if risk_score > 0.5 else "MODERATE" if risk_score > 0.3 else "LOW",
        "flags": flags,
        "recommendation": "INVESTIGATE" if risk_score > 0.5 else "PROCEED"
    }


def tool_claims_history(claimant_name: str) -> dict:
    """Simulate checking a claimant's past claims history."""
    fake_history = {
        "John Doe":      {"total_claims": 2, "last_date": "2023-06-15", "approved": 2, "rejected": 0},
        "Jane Smith":    {"total_claims": 1, "last_date": "2022-11-01", "approved": 1, "rejected": 0},
        "Bob Johnson":   {"total_claims": 4, "last_date": "2024-01-05", "approved": 3, "rejected": 1},
        "Alice Williams":{"total_claims": 0, "last_date": None,         "approved": 0, "rejected": 0},
    }
    return fake_history.get(claimant_name, {"total_claims": 0, "last_date": None})


def run_all_tools(claim: dict) -> dict:
    """Run all tool calls and return combined results."""
    print(f"  🔧 Calling tool: policy_lookup...")
    policy   = tool_policy_lookup(claim['policy_number'])

    print(f"  🔧 Calling tool: fraud_check...")
    fraud    = tool_fraud_check(claim)

    print(f"  🔧 Calling tool: claims_history...")
    history  = tool_claims_history(claim['claimant_name'])

    return {
        "policy_lookup":  policy,
        "fraud_check":    fraud,
        "claims_history": history
    }


if __name__ == "__main__":
    print_section("🔧 Pattern 7: Tool Agent",
                  "Calling external systems to enrich claim data")

    for claim in SAMPLE_CLAIMS:
        print(f"\n{'─' * 60}")
        print(f"Claim {claim['claim_id']} | {claim['claimant_name']} | ${claim['claim_amount']:,.2f}")

        results = run_all_tools(claim)

        p = results['policy_lookup']
        f = results['fraud_check']
        h = results['claims_history']

        print(f"\n  Policy:  Valid={p['valid']}  Coverage=${p.get('coverage', 0):,.0f}  "
              f"Deductible=${p.get('deductible', 0):,.0f}")
        print(f"  Fraud:   Risk={f['risk_level']} ({f['risk_score']:.0%})  "
              f"Flags: {f['flags'] if f['flags'] else 'None'}")
        print(f"  History: {h['total_claims']} prior claims  "
              f"Last: {h.get('last_date', 'Never')}  "
              f"Approved: {h.get('approved', 0)}  Rejected: {h.get('rejected', 0)}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
