"""
ABR Pattern 6: Reflection Agent - AI reviews its own decisions

What this does:
  After making a decision, the AI reads its own output and asks:
  "Was that a good decision? What could be better?"
  This is called self-reflection — a technique that improves AI accuracy.
"""

import anthropic
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Config
from utils import print_section


def reflect_on_decision(decision_text: str) -> dict:
    """Ask Claude to review and rate a decision it (or another agent) made."""
    client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)

    prompt = f"""You are a senior claims auditor reviewing an AI decision.

DECISION TO REVIEW:
{decision_text}

Evaluate this decision and reply in EXACTLY this format (no markdown, no bold):
RATING: X/10
STRENGTHS: what was done well
IMPROVEMENTS: what could be better
REVISED_CONFIDENCE: your confidence in this decision (0-100)"""

    response = client.messages.create(
        model=Config.CLAUDE_MODEL,
        max_tokens=400,
        messages=[{"role": "user", "content": prompt}]
    )

    text = response.content[0].text
    result = {"raw": text}

    for line in text.split('\n'):
        if line.startswith('RATING:'):
            result['rating'] = line.split(':', 1)[1].strip()
        elif line.startswith('STRENGTHS:'):
            result['strengths'] = line.split(':', 1)[1].strip()
        elif line.startswith('IMPROVEMENTS:'):
            result['improvements'] = line.split(':', 1)[1].strip()
        elif line.startswith('REVISED_CONFIDENCE:'):
            result['revised_confidence'] = line.split(':', 1)[1].strip()

    return result


if __name__ == "__main__":
    print_section("🔍 Pattern 6: Reflection Agent",
                  "AI reviews and improves its own decisions")

    # Sample decisions to reflect on — one good, one weak
    sample_decisions = [
        {
            "label": "Well-reasoned decision",
            "text": """
DECISION: APPROVED
CONFIDENCE: 88%
REASONING: Standard auto claim for $5,000, within policy limits of $100,000.
           No fraud indicators. Policy is active. Documents complete.
           Claimant has clean 3-year history. Recommend approval.
"""
        },
        {
            "label": "Weak / vague decision",
            "text": """
DECISION: APPROVED
CONFIDENCE: 60%
REASONING: Claim looks okay.
"""
        }
    ]

    for sample in sample_decisions:
        print(f"\n{'─' * 60}")
        print(f"Reviewing: {sample['label']}")
        print(f"Original decision:{sample['text']}")

        reflection = reflect_on_decision(sample['text'])

        print("AI Self-Reflection:")
        print(f"  Rating:             {reflection.get('rating', 'N/A')}")
        print(f"  Strengths:          {reflection.get('strengths', 'N/A')}")
        print(f"  Improvements:       {reflection.get('improvements', 'N/A')}")
        print(f"  Revised Confidence: {reflection.get('revised_confidence', 'N/A')}%")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
