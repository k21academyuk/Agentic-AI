"""
ABR Pattern 8: Stateful Agent - Memory across multiple claims

What this does:
  A stateless agent forgets everything after each claim.
  A stateful agent REMEMBERS what it has seen and uses that
  context to make better decisions on future claims.

  Example: If the same person files 3 claims in one week,
  a stateful agent notices the pattern. A stateless one doesn't.
"""

import sys
from datetime import datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS


class StatefulClaimAgent:
    """An agent that remembers every claim it has processed."""

    def __init__(self):
        self.memory = {}          # claim_id → stored context
        self.history = []         # ordered list of all processed claim IDs
        self.claimant_index = {}  # claimant_name → list of claim_ids

    def process_claim(self, claim: dict, decision: str, confidence: float):
        """Store a processed claim in memory."""
        claim_id = claim['claim_id']

        # Save full context
        self.memory[claim_id] = {
            "claim":      claim,
            "decision":   decision,
            "confidence": confidence,
            "processed":  datetime.now().isoformat()
        }

        # Track order
        self.history.append(claim_id)

        # Index by claimant so we can look up their history
        name = claim['claimant_name']
        if name not in self.claimant_index:
            self.claimant_index[name] = []
        self.claimant_index[name].append(claim_id)

        print(f"  💾 Stored: {claim_id} → {decision} ({confidence:.0%} confidence)")

    def recall(self, claim_id: str) -> dict:
        """Retrieve a stored claim by ID."""
        return self.memory.get(claim_id)

    def get_claimant_history(self, name: str) -> list:
        """Get all claims filed by a specific person."""
        ids = self.claimant_index.get(name, [])
        return [self.memory[i] for i in ids if i in self.memory]

    def flag_repeat_claimants(self, threshold: int = 2) -> list:
        """Find claimants who have filed more than threshold claims — a fraud signal."""
        return [
            (name, len(ids))
            for name, ids in self.claimant_index.items()
            if len(ids) >= threshold
        ]

    def summary(self) -> dict:
        """Return overall statistics from memory."""
        decisions = [m['decision'] for m in self.memory.values()]
        return {
            "total_processed": len(self.memory),
            "approved":        decisions.count("APPROVED"),
            "rejected":        decisions.count("REJECTED"),
            "manual_review":   decisions.count("MANUAL_REVIEW"),
            "unique_claimants": len(self.claimant_index),
        }


if __name__ == "__main__":
    print_section("💾 Pattern 8: Stateful Agent",
                  "Memory that persists across multiple claim decisions")

    agent = StatefulClaimAgent()

    # Simulate processing all 4 claims with fake decisions
    fake_decisions = [
        ("APPROVED",       0.90),
        ("MANUAL_REVIEW",  0.72),
        ("APPROVED",       0.85),
        ("MANUAL_REVIEW",  0.65),
    ]

    print("Processing claims and storing in memory...\n")
    for claim, (decision, confidence) in zip(SAMPLE_CLAIMS, fake_decisions):
        agent.process_claim(claim, decision, confidence)

    # Show recall
    print(f"\n{'─' * 60}")
    print("Recalling CLM-001 from memory:")
    recalled = agent.recall("CLM-001")
    if recalled:
        print(f"  Decision:    {recalled['decision']}")
        print(f"  Confidence:  {recalled['confidence']:.0%}")
        print(f"  Processed:   {recalled['processed']}")

    # Show claimant history
    print(f"\n{'─' * 60}")
    print("Claimant history lookup — 'John Doe':")
    history = agent.get_claimant_history("John Doe")
    for entry in history:
        c = entry['claim']
        print(f"  {c['claim_id']} | ${c['claim_amount']:,.2f} | {entry['decision']}")

    # Show fraud signal detection
    print(f"\n{'─' * 60}")
    print("Checking for repeat claimants (2+ claims):")
    repeats = agent.flag_repeat_claimants(threshold=2)
    if repeats:
        for name, count in repeats:
            print(f"  ⚠️  {name}: {count} claims filed")
    else:
        print("  No repeat claimants found.")

    # Summary statistics
    print(f"\n{'─' * 60}")
    print("Memory summary:")
    stats = agent.summary()
    for key, val in stats.items():
        print(f"  {key}: {val}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
