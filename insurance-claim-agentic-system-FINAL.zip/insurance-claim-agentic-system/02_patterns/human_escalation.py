"""
ABR Pattern 5: Human Escalation - Knowing when AI should step aside

What this does:
  Not every claim should be decided by AI alone.
  This pattern identifies situations where a human expert
  must review the decision before it is finalised.

  Key insight: Good AI systems know their own limits.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS


def should_escalate(claim: dict, ai_confidence: float) -> dict:
    """
    Decide whether this claim needs human review.
    Returns escalation decision with all reasons listed.
    """
    reasons = []

    # Rule 1: AI is not confident enough
    if ai_confidence < 0.75:
        reasons.append(f"Low AI confidence ({ai_confidence:.0%}) — threshold is 75%")

    # Rule 2: High dollar value
    if claim['claim_amount'] > 50_000:
        reasons.append(f"High value claim (${claim['claim_amount']:,.2f} > $50,000 threshold)")

    # Rule 3: Liability claims are legally complex
    if claim['claim_type'] == 'Liability':
        reasons.append("Liability claims require legal review")

    # Rule 4: Very large amounts always need a human
    if claim['claim_amount'] > 500_000:
        reasons.append(f"Amount exceeds $500,000 — executive approval required")

    escalate = len(reasons) > 0

    return {
        "escalate": escalate,
        "action": "👤 HUMAN REVIEW REQUIRED" if escalate else "🤖 AUTO-PROCESS",
        "reasons": reasons,
        "urgency": "HIGH" if claim['claim_amount'] > 100_000 else "NORMAL"
    }


if __name__ == "__main__":
    print_section("👤 Pattern 5: Human Escalation",
                  "Identifying which claims need human expert review")

    # Test different scenarios
    test_cases = [
        (SAMPLE_CLAIMS[0], 0.95, "Simple auto claim, high confidence"),
        (SAMPLE_CLAIMS[0], 0.60, "Simple auto claim, low confidence"),
        (SAMPLE_CLAIMS[1], 0.88, "Large property claim, high confidence"),
        (SAMPLE_CLAIMS[2], 0.90, "Health claim, high confidence"),
        (SAMPLE_CLAIMS[3], 0.70, "Liability claim, medium confidence"),
    ]

    for claim, confidence, label in test_cases:
        print(f"\n{'─' * 60}")
        print(f"Scenario: {label}")
        print(f"  Claim:      {claim['claim_id']} | {claim['claim_type']} | ${claim['claim_amount']:,.2f}")
        print(f"  Confidence: {confidence:.0%}")

        result = should_escalate(claim, confidence)

        print(f"  Decision:   {result['action']}")
        if result['reasons']:
            print(f"  Reasons:")
            for r in result['reasons']:
                print(f"    • {r}")
        if result['escalate']:
            print(f"  Urgency:    {result['urgency']}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
