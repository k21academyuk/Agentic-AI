"""
ABR Pattern 3: RAG Agent - Knowledge Retrieval

What is RAG?
  RAG = Retrieval-Augmented Generation
  Instead of relying only on Claude's general training,
  we first RETRIEVE relevant policy information, then
  pass it to Claude so it can GENERATE a better answer.

  Real-world example: Before a doctor diagnoses you,
  they look up your medical history first. RAG does the
  same — look up relevant info, then make a decision.
"""

import anthropic
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Config
from utils import print_section, SAMPLE_CLAIMS


# This is our "knowledge base" — in a real system this would
# be a database or vector store with thousands of policy documents
POLICY_KNOWLEDGE_BASE = {
    "Auto": {
        "max_coverage": 100000,
        "deductible": 500,
        "rules": "Police report required for claims over $5,000. Photos mandatory.",
        "turnaround": "5-7 business days"
    },
    "Property": {
        "max_coverage": 500000,
        "deductible": 1000,
        "rules": "File within 60 days of incident. Contractor estimate required.",
        "turnaround": "10-14 business days"
    },
    "Health": {
        "max_coverage": 150000,
        "deductible": 250,
        "rules": "Pre-authorization required for procedures over $10,000. In-network preferred (80/20 split).",
        "turnaround": "3-5 business days"
    },
    "Liability": {
        "max_coverage": 1000000,
        "deductible": 2500,
        "rules": "Must report within 72 hours. Legal counsel required for claims over $50,000.",
        "turnaround": "21-30 business days"
    }
}


def retrieve_policy(claim_type: str) -> dict:
    """
    Step 1 of RAG: RETRIEVE relevant knowledge.
    Looks up the policy rules for this claim type.
    """
    policy = POLICY_KNOWLEDGE_BASE.get(claim_type)
    if not policy:
        print(f"  ⚠️  No policy found for '{claim_type}', using default.")
        return POLICY_KNOWLEDGE_BASE["Auto"]
    return policy


def analyze_with_knowledge(claim: dict) -> str:
    """
    Step 2 of RAG: GENERATE an answer using the retrieved knowledge.
    Passes both the claim AND the policy rules to Claude.
    """
    client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)

    # Step 1: Retrieve
    policy = retrieve_policy(claim['claim_type'])

    # Step 2: Generate — Claude now has the policy context
    prompt = f"""You are an insurance policy analyst.

CLAIM:
  ID:          {claim['claim_id']}
  Type:        {claim['claim_type']}
  Amount:      ${claim['claim_amount']:,.2f}
  Description: {claim['description']}

RETRIEVED POLICY RULES:
  Max Coverage: ${policy['max_coverage']:,.2f}
  Deductible:   ${policy['deductible']:,.2f}
  Rules:        {policy['rules']}
  Turnaround:   {policy['turnaround']}

Using the policy rules above, answer:
1. Is this claim within the coverage limit?
2. What documents are required?
3. What is your recommendation?

Reply in plain text, no markdown, no bold."""

    response = client.messages.create(
        model=Config.CLAUDE_MODEL,
        max_tokens=512,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.content[0].text


if __name__ == "__main__":
    print_section("📚 Pattern 3: RAG Agent",
                  "Retrieve policy knowledge, then generate a decision")

    for claim in SAMPLE_CLAIMS:
        print(f"\n{'─' * 60}")
        print(f"Claim {claim['claim_id']} | {claim['claim_type']} | ${claim['claim_amount']:,.2f}")

        # Show what was retrieved before sending to Claude
        policy = retrieve_policy(claim['claim_type'])
        print(f"  📖 Retrieved policy: max ${policy['max_coverage']:,.2f}, "
              f"deductible ${policy['deductible']:,.2f}")

        print(f"  🤖 Asking Claude to analyze with this context...")
        result = analyze_with_knowledge(claim)
        print(f"\n{result.strip()}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
