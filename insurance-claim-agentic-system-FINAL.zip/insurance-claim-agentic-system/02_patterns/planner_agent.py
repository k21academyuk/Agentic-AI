"""
ABR Pattern 1: Planner Agent - Goal-oriented task decomposition

What this does:
  Before processing a claim, the AI first creates a step-by-step PLAN.
  This is like a project manager breaking down a big task into smaller ones.
  The plan is then used to guide the rest of the processing.
"""

import anthropic
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Config
from utils import print_section, SAMPLE_CLAIMS


def create_processing_plan(claim: dict) -> dict:
    """Ask Claude to create a step-by-step plan for processing this claim."""
    client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)

    prompt = f"""You are a claims processing manager. Create a step-by-step plan to process this claim.

Claim details:
  ID:          {claim['claim_id']}
  Type:        {claim['claim_type']}
  Amount:      ${claim['claim_amount']:,.2f}
  Description: {claim['description']}

Create a plan with 4-5 steps. Return ONLY valid JSON in this exact format:
{{
  "complexity": "low",
  "estimated_days": 3,
  "plan": [
    {{"step": 1, "action": "Verify policy", "outcome": "Confirm coverage", "time": "1 hour"}},
    {{"step": 2, "action": "...", "outcome": "...", "time": "..."}}
  ]
}}"""

    response = client.messages.create(
        model=Config.CLAUDE_MODEL,
        max_tokens=1000,
        messages=[{"role": "user", "content": prompt}]
    )

    text = response.content[0].text

    # Extract JSON safely
    try:
        start = text.find('{')
        end = text.rfind('}') + 1
        return json.loads(text[start:end])
    except Exception:
        # Fallback plan if JSON parsing fails
        return {
            "complexity": "medium",
            "estimated_days": 5,
            "plan": [
                {"step": 1, "action": "Verify policy coverage", "outcome": "Coverage confirmed", "time": "1 hour"},
                {"step": 2, "action": "Collect documents",      "outcome": "Documents received", "time": "2 days"},
                {"step": 3, "action": "Assess claim",           "outcome": "Assessment complete", "time": "1 day"},
                {"step": 4, "action": "Make decision",          "outcome": "Decision issued",     "time": "1 hour"},
            ]
        }


if __name__ == "__main__":
    print_section("📋 Pattern 1: Planner Agent",
                  "Breaking claims into step-by-step processing plans")

    for claim in SAMPLE_CLAIMS[:2]:
        print(f"\n{'─' * 60}")
        print(f"Planning for: {claim['claim_id']} | {claim['claim_type']} | ${claim['claim_amount']:,.2f}")

        plan = create_processing_plan(claim)

        print(f"  Complexity:      {plan.get('complexity', 'N/A').upper()}")
        print(f"  Estimated days:  {plan.get('estimated_days', 'N/A')}")
        print(f"\n  Processing steps:")
        for step in plan.get('plan', []):
            print(f"    Step {step['step']}: {step['action']}")
            print(f"             → {step['outcome']}  ({step['time']})")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
