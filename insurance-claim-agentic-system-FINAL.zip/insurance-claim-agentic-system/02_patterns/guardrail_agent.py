"""
ABR Pattern 4: Guardrail Agent - Compliance & safety checks

What this does:
  Guardrails are safety rules that run BEFORE a decision is finalised.
  Even if the AI says "APPROVED", guardrails can override that if
  the claim breaks a policy rule (e.g. amount exceeds coverage limit).

  Think of it like a seatbelt — it doesn't stop you driving,
  but it protects you if something goes wrong.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import print_section, SAMPLE_CLAIMS, validate_claim_data


# Policy limits per claim type (in dollars)
COVERAGE_LIMITS = {
    "Auto":      100_000,
    "Property":  500_000,
    "Health":    150_000,
    "Liability": 1_000_000,
}


def check_guardrails(claim: dict, proposed_decision: str) -> dict:
    """
    Run all compliance checks on a claim.
    Returns a dict with pass/fail status and details of each check.
    """
    checks = {}

    # Check 1: Data completeness
    is_valid, msg = validate_claim_data(claim)
    checks['data_completeness'] = {
        "passed": is_valid,
        "detail": msg
    }

    # Check 2: Amount within policy limit
    limit = COVERAGE_LIMITS.get(claim['claim_type'], 100_000)
    within_limit = claim['claim_amount'] <= limit
    checks['within_coverage_limit'] = {
        "passed": within_limit,
        "detail": f"${claim['claim_amount']:,.2f} vs limit ${limit:,.2f}"
    }

    # Check 3: High-value approval needs manual review
    if proposed_decision == "APPROVED" and claim['claim_amount'] > 100_000:
        checks['high_value_review'] = {
            "passed": False,
            "detail": f"Claims over $100,000 need manual sign-off before approval"
        }
    else:
        checks['high_value_review'] = {
            "passed": True,
            "detail": "No high-value override needed"
        }

    # Check 4: Positive claim amount
    checks['positive_amount'] = {
        "passed": claim['claim_amount'] > 0,
        "detail": f"Amount ${claim['claim_amount']:,.2f}"
    }

    overall_passed = all(c['passed'] for c in checks.values())
    return {
        "overall_passed": overall_passed,
        "final_decision": proposed_decision if overall_passed else "MANUAL_REVIEW",
        "checks": checks
    }


if __name__ == "__main__":
    print_section("🛡️ Pattern 4: Guardrail Agent",
                  "Safety checks that protect against bad decisions")

    print("Coverage limits by type:")
    for ctype, limit in COVERAGE_LIMITS.items():
        print(f"  {ctype:<12} ${limit:>12,.0f}")

    # Test with different proposed decisions
    test_cases = [
        (SAMPLE_CLAIMS[0], "APPROVED"),   # $5k Auto    — should pass
        (SAMPLE_CLAIMS[1], "APPROVED"),   # $75k Property — should pass
        (SAMPLE_CLAIMS[3], "APPROVED"),   # $150k Liability — should fail (high-value)
    ]

    for claim, decision in test_cases:
        print(f"\n{'─' * 60}")
        print(f"Claim {claim['claim_id']} | {claim['claim_type']} | "
              f"${claim['claim_amount']:,.2f} | Proposed: {decision}")

        result = check_guardrails(claim, decision)

        status = "✅ ALL PASSED" if result['overall_passed'] else "❌ GUARDRAIL FAILED"
        print(f"  Result: {status}  →  Final decision: {result['final_decision']}")

        for check_name, check in result['checks'].items():
            icon = "  ✓" if check['passed'] else "  ✗"
            print(f"{icon} {check_name}: {check['detail']}")

    print(f"\n{'─' * 60}")
    print("✓ Complete!")
