# Insurance Claim Agentic System - Complete Tutorial

## 🎯 What You'll Build
An intelligent insurance claim processing system using AI agents that can:
- Automatically process insurance claims
- Route claims to appropriate handlers
- Check compliance and regulations
- Escalate complex cases to humans
- Learn and improve over time

## 📚 Prerequisites
- Python 3.8 or higher
- Basic Python knowledge
- Anthropic API key (for Claude)

## 🚀 Quick Start Guide

### Step 1: Setup Environment
```bash
# Clone or create your project directory
mkdir insurance-claim-agentic-system
cd insurance-claim-agentic-system

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Step 2: Configure API Keys
```bash
# Copy the example environment file
cp .env.example .env

# Edit .env and add your API key
# ANTHROPIC_API_KEY=your_key_here
```

### Step 3: Run Basic Demo
```bash
# Start with the simplest example
python 01_local_demo/basic_agent.py

# Then try multi-agent
python 01_local_demo/multi_agent.py

# Finally, run the full system
python 01_local_demo/full_system.py
```

### Step 4: Try Pattern Examples
```bash
# Test each ABR pattern individually
python 02_patterns/planner_agent.py
python 02_patterns/router_agent.py
# ... and so on
```

### Step 5: Launch Web UI
```bash
# Run the Streamlit interface
streamlit run 04_web_ui/streamlit_app.py

# Or try Gradio
python 04_web_ui/gradio_app.py
```

## 📖 Learning Path

### Beginner (Start Here!)
1. **01_local_demo/basic_agent.py** - Understand single agent
2. **01_local_demo/multi_agent.py** - Learn agent collaboration
3. **04_web_ui/streamlit_app.py** - See visual interface

### Intermediate
4. **02_patterns/** - Study each ABR pattern
5. **05_testing/** - Learn testing strategies
6. **01_local_demo/full_system.py** - Combine everything

### Advanced
7. **03_cloud_integration/** - Deploy to cloud
8. **06_deployment/** - Production deployment

## 🏗️ Project Structure

```
insurance-claim-agentic-system/
│
├── 01_local_demo/          # Start here - no cloud needed
│   ├── basic_agent.py      # Single agent (15 min)
│   ├── multi_agent.py      # Multiple agents (30 min)
│   └── full_system.py      # Complete system (1 hour)
│
├── 02_patterns/            # All 8 ABR patterns
│   ├── planner_agent.py    # ABR-1: Goal planning
│   ├── router_agent.py     # ABR-2: Intelligent routing
│   ├── rag_agent.py        # ABR-3: RAG knowledge
│   ├── guardrail_agent.py  # ABR-4: Compliance
│   ├── human_escalation.py # ABR-5: Human-in-loop
│   ├── reflection_agent.py # ABR-6: Self-check
│   ├── tool_agent.py       # ABR-7: Tool usage
│   └── stateful_agent.py   # ABR-8: Memory
│
├── 03_cloud_integration/   # Cloud deployments
├── 04_web_ui/              # Interactive demos
├── 05_testing/             # Test scenarios
└── 06_deployment/          # Production deployment
```

## 🎓 What You'll Learn

### ABR Pattern 1: Planner Agent
- How to break down complex tasks
- Goal-oriented thinking
- Multi-step planning

### ABR Pattern 2: Router Agent
- Intelligent decision making
- Claim classification
- Dynamic routing

### ABR Pattern 3: RAG Agent
- Knowledge retrieval
- Document search
- Context-aware responses

### ABR Pattern 4: Guardrail Agent
- Compliance checking
- Regulation enforcement
- Safety measures

### ABR Pattern 5: Human Escalation
- Human-in-the-loop design
- Confidence thresholds
- Escalation protocols

### ABR Pattern 6: Reflection Agent
- Self-assessment
- Quality control
- Error correction

### ABR Pattern 7: Tool Agent
- External tool integration
- API calls
- Database queries

### ABR Pattern 8: Stateful Agent
- Memory management
- Conversation history
- Context preservation

## 🔧 Common Issues & Solutions

### Issue: API Key Not Found
```bash
# Make sure .env file exists and has:
ANTHROPIC_API_KEY=sk-ant-...
```

### Issue: Module Not Found
```bash
# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

### Issue: Port Already in Use
```bash
# For Streamlit, use different port
streamlit run 04_web_ui/streamlit_app.py --server.port 8502
```

## 📞 Support

- Check the `/docs` folder for detailed documentation
- Review example outputs in `/examples`
- Common issues in TROUBLESHOOTING.md

## 🎯 Next Steps

After completing the tutorials:
1. Customize agents for your use case
2. Add your own business rules
3. Integrate with your systems
4. Deploy to production

## 📝 License

MIT License - Feel free to use and modify!

---

**Ready to start? Run:** `python 01_local_demo/basic_agent.py`
