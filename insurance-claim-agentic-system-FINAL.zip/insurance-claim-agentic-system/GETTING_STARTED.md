# 🚀 Getting Started - Your Complete Guide

## Welcome! 👋

You're about to build a real AI-powered insurance claim processing system. This guide will take you from zero to running your first AI agent in 30 minutes.

---

## ⚡ Super Quick Start (5 Minutes)

If you're comfortable with Python and just want to run something:

```bash
cd insurance-claim-agentic-system
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install anthropic python-dotenv
echo "ANTHROPIC_API_KEY=your_key_here" > .env
python 01_local_demo/basic_agent.py
```

Done! You just ran your first AI agent.

---

## 📚 Detailed Setup (For Beginners)

### Step 1: Check Prerequisites (2 minutes)

Open your terminal and check if you have Python:

```bash
python --version
```

You should see something like `Python 3.8.10` or higher.

**Don't have Python?**
- **Windows**: Download from https://python.org
- **Mac**: `brew install python3` or download from python.org
- **Linux**: Usually pre-installed, or `sudo apt install python3`

---

### Step 2: Extract the Project (1 minute)

1. Download the `insurance-claim-system.zip` file
2. Extract it to a folder you can find easily
3. Open terminal/command prompt
4. Navigate to the folder:

```bash
cd path/to/insurance-claim-agentic-system
```

**Finding the path:**
- **Windows**: Shift + Right-click folder → "Copy as path"
- **Mac**: Right-click → Hold Option → "Copy ... as Pathname"
- **Linux**: Right-click → "Copy Path"

---

### Step 3: Create Virtual Environment (3 minutes)

A virtual environment keeps this project's packages separate from your system.

```bash
# Create virtual environment
python -m venv venv

# Activate it
# On Windows:
venv\Scripts\activate

# On Mac/Linux:
source venv/bin/activate
```

**Success indicator:** Your terminal prompt should now start with `(venv)`

**Troubleshooting:**
- If `python` doesn't work, try `python3`
- If activation fails on Windows, try: `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser`

---

### Step 4: Install Packages (5 minutes)

```bash
pip install -r requirements.txt
```

This installs all necessary packages. You'll see a lot of text scroll by - this is normal!

**What gets installed:**
- `anthropic` - To talk to Claude AI
- `streamlit` - For web interface
- `pandas` - For data handling
- And several others...

**Troubleshooting:**
- If you get errors, try: `pip install --upgrade pip` first
- On Mac with M1/M2: Make sure you're using Python 3.9+

---

### Step 5: Get Your API Key (5 minutes)

1. Go to https://console.anthropic.com
2. Sign up or log in
3. Go to "API Keys" section
4. Click "Create Key"
5. Copy the key (starts with `sk-ant-...`)

**IMPORTANT:** Keep this key secret! Never share it or commit to git.

---

### Step 6: Configure API Key (2 minutes)

```bash
# Copy the example file
cp .env.example .env

# Edit the .env file
# On Windows:
notepad .env

# On Mac:
open -e .env

# On Linux:
nano .env
```

Change this line:
```
ANTHROPIC_API_KEY=your_anthropic_api_key_here
```

To your actual key:
```
ANTHROPIC_API_KEY=sk-ant-api03-xxxxx...
```

Save and close the file.

---

### Step 7: Run Your First Agent! (2 minutes)

```bash
python 01_local_demo/basic_agent.py
```

**What you should see:**
```
🤖 BASIC AGENT DEMO
Step 1: Creating AI agent...
✓ Agent created successfully!

Step 2: Selecting claim to analyze...
✓ Selected: CLM-001 - Auto claim for $5,000.00

Step 3: Analyzing claim with AI agent...
✓ Analysis complete!

📊 ANALYSIS RESULTS
  Claim ID: CLM-001
  Decision: APPROVED
  Confidence: 85%
  Reasoning: Standard auto claim within policy limits...
```

🎉 **Congratulations!** You just ran your first AI agent!

---

## 🎯 What Just Happened?

Let's break down what your first agent did:

1. **Read a claim** - Sample auto insurance claim for $5,000
2. **Sent to Claude AI** - Used the Anthropic API
3. **Got analysis** - Claude analyzed and made a decision
4. **Showed results** - Displayed decision with reasoning

---

## 🚶 Next Steps

Now that you have the basic agent working, here's your learning path:

### Option A: Interactive Learning (Recommended)
```bash
# 1. Try different claims (5 min)
# Edit basic_agent.py line 125:
# Change SAMPLE_CLAIMS[0] to [1], [2], or [3]
python 01_local_demo/basic_agent.py

# 2. See multiple agents working together (10 min)
python 01_local_demo/multi_agent.py

# 3. See the complete system (20 min)
python 01_local_demo/full_system.py
```

### Option B: Visual Learning
```bash
# Launch web interface
streamlit run 04_web_ui/streamlit_app.py

# Opens in browser automatically!
# If not, go to: http://localhost:8501
```

### Option C: Pattern-by-Pattern
```bash
# Learn each ABR pattern individually
python 02_patterns/planner_agent.py      # Pattern 1
python 02_patterns/router_agent.py       # Pattern 2
python 02_patterns/rag_agent.py          # Pattern 3
# ... and so on
```

---

## 📖 Understanding the Code

### Your First Agent (basic_agent.py)

Let's look at the key parts:

```python
# 1. Create the AI client
client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)

# 2. Write a prompt (instructions for Claude)
prompt = f"""You are an insurance analyst. 
Analyze this claim and decide: APPROVED, REJECTED, or MANUAL_REVIEW

Claim Details:
- Type: {claim['claim_type']}
- Amount: ${claim['claim_amount']}
- Description: {claim['description']}

Provide decision with reasoning."""

# 3. Send to Claude
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    messages=[{"role": "user", "content": prompt}]
)

# 4. Get the result
result = response.content[0].text
```

**That's it!** That's the core of how AI agents work:
1. You give instructions (prompt)
2. AI processes it
3. You get the response

---

## 🎨 Customization Ideas

### Easy Changes (No coding needed)

**1. Change the claims**

Edit `utils.py`, find `SAMPLE_CLAIMS`, add your own:

```python
{
    "claim_id": "CLM-999",
    "claim_type": "Your Type",
    "claim_amount": 10000,
    "description": "Your description here"
}
```

**2. Adjust confidence thresholds**

Edit any agent file, change numbers like:
```python
if confidence < 0.70:  # Change to 0.80 for stricter
```

**3. Modify prompts**

Find the `prompt = f"""..."""` sections and rewrite them in your own words.

---

## 🐛 Common Issues & Solutions

### Issue 1: "Module not found"
```bash
Solution:
pip install -r requirements.txt --force-reinstall
```

### Issue 2: "ANTHROPIC_API_KEY not found"
```bash
Solution:
1. Check .env file exists: ls -la .env
2. Check it contains your key: cat .env
3. Make sure virtual environment is activated: you should see (venv)
```

### Issue 3: "API rate limit"
```bash
Solution:
You've made too many requests. Wait a minute or two.
```

### Issue 4: "Permission denied" on scripts
```bash
Solution (Mac/Linux):
chmod +x 01_local_demo/*.py
```

### Issue 5: Python not found
```bash
Solution:
Try python3 instead of python:
python3 01_local_demo/basic_agent.py
```

---

## 💰 Cost Information

### API Costs (Approximate)

Using Claude Sonnet 4:
- **Input**: ~$3 per million tokens
- **Output**: ~$15 per million tokens

**What does this mean for you?**

One claim analysis:
- Input: ~500 tokens
- Output: ~200 tokens
- Cost: ~$0.004 (less than half a cent)

So you can:
- Process 10 claims: ~$0.04
- Process 100 claims: ~$0.40
- Process 1,000 claims: ~$4

**Free tier:** Anthropic usually provides some free credits for new accounts.

---

## 📚 Learning Resources

### In This Project

| Document | Purpose | Read When |
|----------|---------|-----------|
| `README.md` | Overview | Right after setup |
| `QUICKSTART.md` | Quick guide | Before first run |
| `ARCHITECTURE.md` | System design | When building seriously |
| `PROJECT_SUMMARY.md` | Complete reference | Anytime |

### External Resources

1. **Anthropic Documentation**
   - https://docs.anthropic.com
   - Complete API reference

2. **Prompt Engineering**
   - https://docs.anthropic.com/prompt-library
   - Learn to write better prompts

3. **Python Basics** (if needed)
   - https://docs.python.org/3/tutorial/
   - Python official tutorial

---

## 🎓 Learning Path by Experience Level

### Complete Beginner to AI
**Week 1:** Setup and basic demos
- Day 1: Setup and run basic_agent.py
- Day 2: Understand the code
- Day 3: Run multi_agent.py
- Day 4: Try web UI
- Day 5: Experiment with different claims

**Week 2:** Understand patterns
- One pattern per day
- Read, run, and understand
- Try modifying prompts

**Week 3:** Build something
- Customize for your needs
- Add your own claims
- Modify decision logic

### Some Python Experience
**Day 1:** Run all demos, understand flow
**Day 2:** Study all 8 patterns
**Day 3:** Customize and extend
**Day 4-5:** Build your version

### Experienced Developer
**Hour 1:** Run demos, read architecture
**Hour 2:** Review all patterns
**Hour 3+:** Customize and deploy

---

## 🚀 From Learning to Production

### Phase 1: Learning (Week 1)
- ✅ Run all demos
- ✅ Understand each pattern
- ✅ Try web interface

### Phase 2: Customization (Week 2)
- ✅ Add your claim types
- ✅ Modify decision rules
- ✅ Adjust confidence thresholds
- ✅ Add your business logic

### Phase 3: Integration (Week 3-4)
- ✅ Connect real database
- ✅ Add authentication
- ✅ Integrate with your systems
- ✅ Set up monitoring

### Phase 4: Deployment (Week 5-6)
- ✅ Choose cloud provider
- ✅ Set up infrastructure
- ✅ Deploy and test
- ✅ Go live!

---

## 🎯 Success Checklist

Check these off as you progress:

**Setup**
- [ ] Python installed
- [ ] Project extracted
- [ ] Virtual environment created
- [ ] Packages installed
- [ ] API key configured

**Running**
- [ ] basic_agent.py works
- [ ] multi_agent.py works
- [ ] full_system.py works
- [ ] Web UI accessible
- [ ] All patterns tested

**Understanding**
- [ ] Know how to call API
- [ ] Understand prompts
- [ ] Know all 8 patterns
- [ ] Can modify code
- [ ] Can add features

**Building**
- [ ] Added custom claims
- [ ] Modified decision logic
- [ ] Tested thoroughly
- [ ] Ready for deployment

---

## 🆘 Getting Help

### In Order of Preference:

1. **Read error messages** - They often tell you exactly what's wrong
2. **Check this document** - Common issues covered above
3. **Read the code comments** - Every file is well-documented
4. **Check documentation** - QUICKSTART.md, ARCHITECTURE.md, etc.
5. **Try print debugging** - Add `print()` statements to see what's happening

---

## 🎉 You're Ready!

You now have:
- ✅ Working AI agent system
- ✅ Complete understanding of setup
- ✅ Clear learning path
- ✅ Troubleshooting guide
- ✅ Resources for learning

**Now go build something amazing!** 🚀

---

## Quick Reference Commands

```bash
# Activate environment
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate     # Windows

# Run demos
python 01_local_demo/basic_agent.py
python 01_local_demo/multi_agent.py
python 01_local_demo/full_system.py

# Run patterns
python 02_patterns/planner_agent.py
# ... others similar

# Launch web UI
streamlit run 04_web_ui/streamlit_app.py

# Run tests
python 05_testing/test_all_patterns.py

# Deactivate environment (when done)
deactivate
```

---

**Questions? Stuck? Remember:**
- Error messages are your friend
- Documentation is comprehensive
- Code is well-commented
- You can do this! 💪
