"""
Azure OpenAI Integration for Insurance Claim System

This module provides integration with Azure OpenAI Service.
While this system is designed for Claude, this demonstrates
how to adapt the architecture for Azure OpenAI models.

Prerequisites:
- Azure account with OpenAI Service
- openai package installed: pip install openai
- Azure endpoint and API key
"""

import json
import sys
sys.path.append('..')
from config import Config
from utils import print_section, SAMPLE_CLAIMS

try:
    from openai import AzureOpenAI
except ImportError:
    print("⚠️  openai package not installed. Run: pip install openai")
    AzureOpenAI = None

class AzureClaimAnalyzer:
    """
    Analyze insurance claims using Azure OpenAI Service
    
    Note: This uses GPT models, not Claude. Included to show
    how to adapt the architecture for different providers.
    """
    
    def __init__(self):
        """Initialize Azure OpenAI client"""
        
        if not AzureOpenAI:
            raise ImportError("openai package required. Install with: pip install openai")
        
        if not Config.AZURE_OPENAI_API_KEY or not Config.AZURE_OPENAI_ENDPOINT:
            raise ValueError("Azure credentials not configured in .env file")
        
        self.client = AzureOpenAI(
            api_key=Config.AZURE_OPENAI_API_KEY,
            api_version="2024-02-15-preview",
            azure_endpoint=Config.AZURE_OPENAI_ENDPOINT
        )
        
        # Model deployment name (set in Azure)
        self.deployment_name = "gpt-4"
    
    def analyze_claim(self, claim: dict) -> dict:
        """
        Analyze insurance claim using Azure OpenAI
        
        Args:
            claim: Dictionary with claim details
            
        Returns:
            Analysis results
        """
        
        # Prepare prompt
        messages = [
            {
                "role": "system",
                "content": "You are an insurance claim analyst AI assistant."
            },
            {
                "role": "user",
                "content": f"""Analyze this insurance claim:

Claim Details:
- ID: {claim['claim_id']}
- Type: {claim['claim_type']}
- Amount: ${claim['claim_amount']:,.2f}
- Date: {claim['claim_date']}
- Description: {claim['description']}

Provide:
1. Decision (APPROVED/REJECTED/MANUAL_REVIEW)
2. Confidence (0-100%)
3. Reasoning
4. Risk factors"""
            }
        ]
        
        try:
            # Call Azure OpenAI
            response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=messages,
                temperature=0.7,
                max_tokens=1024
            )
            
            # Extract response
            content = response.choices[0].message.content
            
            return {
                'claim_id': claim['claim_id'],
                'analysis': content,
                'model': self.deployment_name,
                'provider': 'Azure OpenAI',
                'success': True
            }
            
        except Exception as e:
            return {
                'claim_id': claim['claim_id'],
                'error': str(e),
                'success': False
            }

def setup_azure_guide():
    """Guide for setting up Azure OpenAI Service"""
    
    print_section("🔧 Azure OpenAI Setup Guide")
    
    print("""
Prerequisites:
1. Azure Account
2. Azure OpenAI Service access (requires approval)
3. Deployed GPT model

Step 1: Create Azure OpenAI Resource
------------------------------------
1. Go to Azure Portal (portal.azure.com)
2. Create new resource → Azure OpenAI
3. Fill in details:
   - Subscription
   - Resource group
   - Region (check model availability)
   - Name
4. Wait for deployment

Step 2: Deploy a Model
----------------------
1. Go to your Azure OpenAI resource
2. Navigate to "Model deployments"
3. Click "Create new deployment"
4. Choose model (GPT-4, GPT-3.5-turbo)
5. Give it a deployment name (e.g., "gpt-4")
6. Click "Create"

Step 3: Get Credentials
-----------------------
1. Go to "Keys and Endpoint"
2. Copy:
   - Endpoint URL
   - API Key (Key 1 or Key 2)

Step 4: Configure .env File
---------------------------
Add these to your .env file:

AZURE_OPENAI_API_KEY=your_api_key_here
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/

Step 5: Install Package
-----------------------
pip install openai

Step 6: Test Connection
-----------------------
python 03_cloud_integration/azure_openai.py

Available Models:
----------------
- GPT-4 (most capable, higher cost)
- GPT-4-32k (larger context)
- GPT-3.5-Turbo (faster, cheaper)
- GPT-3.5-Turbo-16k (larger context)

Pricing (approximate, varies by region):
---------------------------------------
- GPT-4: $30/1M input, $60/1M output tokens
- GPT-3.5-Turbo: $0.50/1M input, $1.50/1M output tokens

Benefits of Azure OpenAI:
------------------------
✓ Enterprise-grade security
✓ Microsoft compliance certifications
✓ Integration with Azure services
✓ Private endpoints and VNets
✓ Custom domains
✓ Content filtering
✓ Regional deployment options

Note: Claude vs GPT
------------------
This system is designed for Claude (Anthropic). However, the
architecture is flexible and can work with any LLM provider.
This Azure integration shows how to adapt the system.

For production with Claude, use:
- Direct Anthropic API (03_cloud_integration/multi_cloud.py)
- AWS Bedrock (03_cloud_integration/aws_bedrock.py)
""")

def test_azure_connection():
    """Test Azure OpenAI connection"""
    
    print_section("🧪 Testing Azure OpenAI Connection")
    
    # Check configuration
    if not Config.AZURE_OPENAI_API_KEY:
        print("❌ Azure OpenAI API key not found!")
        print("\nConfigure in .env file:")
        print("  AZURE_OPENAI_API_KEY=your_key")
        print("  AZURE_OPENAI_ENDPOINT=your_endpoint")
        return False
    
    if not Config.AZURE_OPENAI_ENDPOINT:
        print("❌ Azure OpenAI endpoint not found!")
        return False
    
    try:
        print("Creating Azure OpenAI client...")
        analyzer = AzureClaimAnalyzer()
        print("✓ Client created successfully!")
        
        print(f"\nAnalyzing sample claim...")
        claim = SAMPLE_CLAIMS[0]
        
        result = analyzer.analyze_claim(claim)
        
        if result['success']:
            print("✓ Analysis successful!\n")
            print(f"Claim: {result['claim_id']}")
            print(f"Model: {result['model']}")
            print(f"Provider: {result['provider']}")
            print("\nAnalysis:")
            print("-" * 60)
            print(result['analysis'])
            print("-" * 60)
            return True
        else:
            print(f"❌ Analysis failed: {result['error']}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        print("\nCommon issues:")
        print("1. Check API key and endpoint in .env")
        print("2. Verify model is deployed in Azure")
        print("3. Ensure openai package is installed")
        return False

def azure_vs_others():
    """Compare Azure with other cloud providers"""
    
    print_section("📊 Cloud Provider Comparison")
    
    comparison = """
┌──────────────────┬──────────────────┬──────────────────┬──────────────────┐
│    Feature       │   Direct API     │   AWS Bedrock    │  Azure OpenAI    │
├──────────────────┼──────────────────┼──────────────────┼──────────────────┤
│ Setup            │ Easiest          │ Medium           │ Medium           │
│ Provider         │ Anthropic        │ AWS + Anthropic  │ Azure + OpenAI   │
│ Models           │ Claude           │ Claude           │ GPT-4, GPT-3.5   │
│ Security         │ Standard         │ AWS security     │ Azure security   │
│ Compliance       │ Limited          │ AWS compliance   │ MS compliance    │
│ Integration      │ Any              │ AWS services     │ Azure services   │
│ Price            │ $$ (direct)      │ $$ (+ AWS)       │ $$$ (higher)     │
│ Latency          │ Good             │ Good             │ Good             │
│ Support          │ Anthropic        │ AWS              │ Microsoft        │
│ Enterprise       │ Available        │ Built-in         │ Built-in         │
└──────────────────┴──────────────────┴──────────────────┴──────────────────┘

Choose Direct Anthropic API when:
---------------------------------
✓ Want to use Claude (best for insurance)
✓ Simple deployment
✓ Quick setup
✓ No cloud commitment needed

Choose AWS Bedrock when:
------------------------
✓ Want Claude + AWS ecosystem
✓ Already on AWS
✓ Need AWS integrations
✓ Enterprise compliance required

Choose Azure OpenAI when:
-------------------------
✓ Already on Azure
✓ Microsoft ecosystem
✓ GPT models acceptable
✓ Azure compliance needed
✓ Office 365 integration

Recommendation for Insurance Claims:
-----------------------------------
1st Choice: Direct Claude API or AWS Bedrock
   - Claude is superior for analysis and reasoning
   - Better at nuanced decision making
   - More reliable for compliance

2nd Choice: Azure OpenAI (GPT-4)
   - Still good, but not as strong as Claude
   - Use if Azure is required by organization
   - Consider hybrid approach
"""
    print(comparison)

def main():
    """Main function for Azure OpenAI integration demo"""
    
    print_section("☁️ Azure OpenAI Integration")
    
    print("Note: This system is optimized for Claude (Anthropic).")
    print("Azure OpenAI uses GPT models, which work differently.")
    print("\nOptions:")
    print("1. View Azure setup guide")
    print("2. Test Azure connection")
    print("3. Compare cloud providers")
    
    choice = input("\nEnter choice (1-3) or press Enter to skip: ").strip()
    
    if choice == '1':
        setup_azure_guide()
    elif choice == '2':
        test_azure_connection()
    elif choice == '3':
        azure_vs_others()
    else:
        print("\n💡 Recommendation: Use Claude (Direct API or AWS Bedrock)")
        print("   Claude is better suited for insurance claim analysis.")
        print("\n   If Azure is required, this integration is available.")

if __name__ == "__main__":
    main()
