"""
Multi-Cloud Integration for Insurance Claim System

This module provides a unified interface to use Claude across
different cloud providers. Switch between providers easily based
on your infrastructure needs.

Supported Providers:
- Direct Anthropic API
- AWS Bedrock
- Azure OpenAI (GPT models)
"""

import sys
sys.path.append('..')
from config import Config
from utils import print_section, print_result, SAMPLE_CLAIMS
from typing import Optional, Dict, Literal

# Cloud provider types
CloudProvider = Literal['anthropic', 'aws_bedrock', 'azure']

class MultiCloudAnalyzer:
    """
    Unified interface for insurance claim analysis across cloud providers
    """
    
    def __init__(self, provider: CloudProvider = 'anthropic'):
        """
        Initialize analyzer with specified cloud provider
        
        Args:
            provider: 'anthropic', 'aws_bedrock', or 'azure'
        """
        self.provider = provider
        self.client = None
        
        # Initialize the appropriate client
        if provider == 'anthropic':
            self._init_anthropic()
        elif provider == 'aws_bedrock':
            self._init_aws_bedrock()
        elif provider == 'azure':
            self._init_azure()
        else:
            raise ValueError(f"Unsupported provider: {provider}")
    
    def _init_anthropic(self):
        """Initialize Direct Anthropic API client"""
        try:
            import anthropic
            self.client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)
            print(f"✓ Initialized Direct Anthropic API")
        except Exception as e:
            print(f"❌ Failed to initialize Anthropic: {e}")
            raise
    
    def _init_aws_bedrock(self):
        """Initialize AWS Bedrock client"""
        try:
            import boto3
            self.client = boto3.client(
                service_name='bedrock-runtime',
                region_name=Config.AWS_REGION,
                aws_access_key_id=Config.AWS_ACCESS_KEY_ID,
                aws_secret_access_key=Config.AWS_SECRET_ACCESS_KEY
            )
            print(f"✓ Initialized AWS Bedrock in {Config.AWS_REGION}")
        except Exception as e:
            print(f"❌ Failed to initialize AWS Bedrock: {e}")
            raise
    
    def _init_azure(self):
        """Initialize Azure OpenAI client"""
        try:
            from openai import AzureOpenAI
            self.client = AzureOpenAI(
                api_key=Config.AZURE_OPENAI_API_KEY,
                api_version="2024-02-15-preview",
                azure_endpoint=Config.AZURE_OPENAI_ENDPOINT
            )
            print(f"✓ Initialized Azure OpenAI")
        except Exception as e:
            print(f"❌ Failed to initialize Azure: {e}")
            raise
    
    def analyze_claim(self, claim: dict) -> dict:
        """
        Analyze claim using configured cloud provider
        
        Args:
            claim: Dictionary with claim details
            
        Returns:
            Analysis results
        """
        
        if self.provider == 'anthropic':
            return self._analyze_anthropic(claim)
        elif self.provider == 'aws_bedrock':
            return self._analyze_bedrock(claim)
        elif self.provider == 'azure':
            return self._analyze_azure(claim)
    
    def _analyze_anthropic(self, claim: dict) -> dict:
        """Analyze using Direct Anthropic API"""
        
        prompt = self._build_prompt(claim)
        
        response = self.client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}]
        )
        
        return {
            'claim_id': claim['claim_id'],
            'analysis': response.content[0].text,
            'provider': 'Anthropic Direct API',
            'model': Config.CLAUDE_MODEL,
            'success': True
        }
    
    def _analyze_bedrock(self, claim: dict) -> dict:
        """Analyze using AWS Bedrock"""
        
        import json
        
        prompt = self._build_prompt(claim)
        
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1024,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7
        })
        
        response = self.client.invoke_model(
            modelId='anthropic.claude-3-sonnet-20240229-v1:0',
            body=body
        )
        
        response_body = json.loads(response['body'].read())
        content = response_body['content'][0]['text']
        
        return {
            'claim_id': claim['claim_id'],
            'analysis': content,
            'provider': 'AWS Bedrock',
            'model': 'Claude 3 Sonnet',
            'success': True
        }
    
    def _analyze_azure(self, claim: dict) -> dict:
        """Analyze using Azure OpenAI"""
        
        prompt = self._build_prompt(claim)
        
        response = self.client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an insurance claim analyst."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1024
        )
        
        return {
            'claim_id': claim['claim_id'],
            'analysis': response.choices[0].message.content,
            'provider': 'Azure OpenAI',
            'model': 'GPT-4',
            'success': True
        }
    
    def _build_prompt(self, claim: dict) -> str:
        """Build analysis prompt (same across all providers)"""
        
        return f"""Analyze this insurance claim and provide a decision:

Claim Details:
- ID: {claim['claim_id']}
- Type: {claim['claim_type']}
- Amount: ${claim['claim_amount']:,.2f}
- Date: {claim['claim_date']}
- Description: {claim['description']}

Provide:
DECISION: [APPROVED/REJECTED/MANUAL_REVIEW]
CONFIDENCE: [0-100%]
REASONING: [Your reasoning]
RISK_FACTORS: [Any concerns]"""

def compare_providers_demo():
    """
    Demonstrate analyzing the same claim across all providers
    """
    
    print_section("📊 Multi-Cloud Provider Comparison")
    
    claim = SAMPLE_CLAIMS[0]
    print(f"Analyzing Claim: {claim['claim_id']} - ${claim['claim_amount']:,.2f}")
    print(f"Description: {claim['description']}\n")
    
    providers_to_test = []
    
    # Check which providers are configured
    if Config.ANTHROPIC_API_KEY:
        providers_to_test.append('anthropic')
    
    if Config.AWS_ACCESS_KEY_ID and Config.AWS_SECRET_ACCESS_KEY:
        providers_to_test.append('aws_bedrock')
    
    if Config.AZURE_OPENAI_API_KEY and Config.AZURE_OPENAI_ENDPOINT:
        providers_to_test.append('azure')
    
    if not providers_to_test:
        print("❌ No cloud providers configured!")
        print("\nConfigure at least one provider in .env:")
        print("- ANTHROPIC_API_KEY for Direct API")
        print("- AWS credentials for Bedrock")
        print("- Azure credentials for Azure OpenAI")
        return
    
    print(f"Testing {len(providers_to_test)} configured provider(s)...\n")
    
    results = {}
    
    for provider in providers_to_test:
        print(f"\n{'='*60}")
        print(f"Testing: {provider.upper()}")
        print('='*60)
        
        try:
            analyzer = MultiCloudAnalyzer(provider=provider)
            result = analyzer.analyze_claim(claim)
            
            print(f"\n✓ Success!")
            print(f"Provider: {result['provider']}")
            print(f"Model: {result['model']}")
            print("\nAnalysis:")
            print("-" * 60)
            print(result['analysis'][:500])  # First 500 chars
            if len(result['analysis']) > 500:
                print("... (truncated)")
            print("-" * 60)
            
            results[provider] = result
            
        except Exception as e:
            print(f"❌ Failed: {e}")
            results[provider] = {'error': str(e)}
    
    # Summary
    print("\n\n" + "="*60)
    print("  SUMMARY")
    print("="*60)
    print(f"\nProviders tested: {len(providers_to_test)}")
    print(f"Successful: {sum(1 for r in results.values() if 'error' not in r)}")
    print(f"Failed: {sum(1 for r in results.values() if 'error' in r)}")

def failover_demo():
    """
    Demonstrate automatic failover between providers
    """
    
    print_section("🔄 Failover Demo")
    
    print("""
In production, you can implement automatic failover:

1. Try primary provider (e.g., Direct Anthropic)
2. If fails, try secondary (e.g., AWS Bedrock)
3. If that fails, try tertiary (e.g., Azure)
4. Log all failures for monitoring

This ensures high availability and reliability.
""")
    
    # Failover order
    failover_order = [
        ('anthropic', 'Direct API - fastest, simplest'),
        ('aws_bedrock', 'AWS Bedrock - enterprise features'),
        ('azure', 'Azure OpenAI - Microsoft integration')
    ]
    
    claim = SAMPLE_CLAIMS[0]
    
    print(f"\nAttempting to analyze claim: {claim['claim_id']}")
    print(f"Failover order configured:\n")
    
    for i, (provider, description) in enumerate(failover_order, 1):
        print(f"{i}. {provider.upper()}: {description}")
    
    print("\n" + "-"*60)
    
    # Try each provider in order
    for provider, description in failover_order:
        print(f"\nAttempting {provider}...")
        
        try:
            analyzer = MultiCloudAnalyzer(provider=provider)
            result = analyzer.analyze_claim(claim)
            
            if result['success']:
                print(f"✓ Success with {provider}!")
                print(f"   Provider: {result['provider']}")
                print(f"   Model: {result['model']}")
                print(f"\n   ✓ Claim analyzed successfully")
                return result
        
        except Exception as e:
            print(f"✗ {provider} failed: {e}")
            print(f"   → Trying next provider...")
            continue
    
    print("\n❌ All providers failed!")
    return None

def cost_comparison():
    """Show cost comparison across providers"""
    
    print_section("💰 Cost Comparison")
    
    print("""
Approximate costs for processing 1,000 insurance claims:
(Assuming ~500 input tokens, ~200 output tokens per claim)

Provider          | Model           | Input Cost | Output Cost | Total
------------------|-----------------|------------|-------------|-------
Direct Anthropic  | Claude Sonnet 4 | $1.50      | $3.00       | $4.50
AWS Bedrock       | Claude Sonnet 3 | $1.50      | $3.00       | $4.50*
Azure OpenAI      | GPT-4          | $15.00     | $12.00      | $27.00
Azure OpenAI      | GPT-3.5-Turbo  | $0.25      | $0.30       | $0.55

* Plus AWS infrastructure costs

Notes:
- Direct Anthropic: Simplest billing, pay only for API calls
- AWS Bedrock: Same model costs + AWS infrastructure charges
- Azure: Higher base costs but better enterprise features
- Costs vary by region and volume discounts

Recommendation:
- For cost: Direct Anthropic or AWS Bedrock (use Claude)
- For features: AWS or Azure (enterprise features)
- For quality: Claude models outperform GPT for analysis

Monthly costs for different volumes:
- 1,000 claims/month: $5-30
- 10,000 claims/month: $50-300
- 100,000 claims/month: $500-3,000 (negotiate volume discounts)
""")

def main():
    """Main function for multi-cloud integration demo"""
    
    print_section("☁️ Multi-Cloud Integration System")
    
    print("""
This system supports multiple cloud providers:

1. Direct Anthropic API (Recommended for Claude)
   - Simplest setup
   - Direct access to latest Claude models
   - Best for most use cases

2. AWS Bedrock
   - Claude on AWS infrastructure
   - Enterprise AWS features
   - Best for AWS-centric organizations

3. Azure OpenAI
   - GPT models (not Claude)
   - Microsoft ecosystem integration
   - Best for Azure-centric organizations

What would you like to do?
""")
    
    print("1. Compare providers (analyze same claim across all)")
    print("2. Demonstrate failover")
    print("3. View cost comparison")
    print("4. Exit")
    
    choice = input("\nEnter choice (1-4): ").strip()
    
    if choice == '1':
        compare_providers_demo()
    elif choice == '2':
        failover_demo()
    elif choice == '3':
        cost_comparison()
    else:
        print("\nTo use multi-cloud:")
        print("1. Configure desired providers in .env")
        print("2. Import MultiCloudAnalyzer in your code")
        print("3. Switch providers as needed")
        print("\nExample:")
        print("  analyzer = MultiCloudAnalyzer(provider='anthropic')")
        print("  result = analyzer.analyze_claim(claim)")

if __name__ == "__main__":
    main()
