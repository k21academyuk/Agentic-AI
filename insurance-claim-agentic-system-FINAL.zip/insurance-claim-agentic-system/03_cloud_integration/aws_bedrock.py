"""
AWS Bedrock Integration for Insurance Claim System

This module provides integration with AWS Bedrock to use Claude models
hosted on AWS infrastructure.

Prerequisites:
- AWS Account with Bedrock access
- boto3 installed: pip install boto3
- AWS credentials configured
"""

import json
import sys
sys.path.append('..')
from config import Config
from utils import print_section, SAMPLE_CLAIMS

try:
    import boto3
    from botocore.exceptions import ClientError
except ImportError:
    print("⚠️  boto3 not installed. Run: pip install boto3")
    boto3 = None

class BedrockClaimAnalyzer:
    """
    Analyze insurance claims using Claude on AWS Bedrock
    """
    
    def __init__(self, region_name='us-east-1'):
        """
        Initialize Bedrock client
        
        Args:
            region_name: AWS region (default: us-east-1)
        """
        if not boto3:
            raise ImportError("boto3 is required. Install with: pip install boto3")
        
        self.region_name = region_name
        self.client = boto3.client(
            service_name='bedrock-runtime',
            region_name=region_name,
            aws_access_key_id=Config.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=Config.AWS_SECRET_ACCESS_KEY
        )
        
        # Claude model on Bedrock
        self.model_id = 'anthropic.claude-3-sonnet-20240229-v1:0'
    
    def analyze_claim(self, claim: dict) -> dict:
        """
        Analyze insurance claim using Bedrock
        
        Args:
            claim: Dictionary with claim details
            
        Returns:
            Analysis results
        """
        
        # Prepare prompt
        prompt = f"""You are an insurance claim analyst. Analyze this claim:

Claim Details:
- ID: {claim['claim_id']}
- Type: {claim['claim_type']}
- Amount: ${claim['claim_amount']:,.2f}
- Date: {claim['claim_date']}
- Description: {claim['description']}

Provide:
1. Decision (APPROVED/REJECTED/MANUAL_REVIEW)
2. Confidence (0-100%)
3. Reasoning
4. Risk factors

Format your response clearly."""

        # Prepare request body for Bedrock
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1024,
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.7,
            "top_p": 1
        })
        
        try:
            # Call Bedrock
            response = self.client.invoke_model(
                modelId=self.model_id,
                body=body
            )
            
            # Parse response
            response_body = json.loads(response['body'].read())
            
            # Extract content
            content = response_body['content'][0]['text']
            
            return {
                'claim_id': claim['claim_id'],
                'analysis': content,
                'model': self.model_id,
                'region': self.region_name,
                'success': True
            }
            
        except ClientError as e:
            error_msg = e.response['Error']['Message']
            return {
                'claim_id': claim['claim_id'],
                'error': error_msg,
                'success': False
            }
        except Exception as e:
            return {
                'claim_id': claim['claim_id'],
                'error': str(e),
                'success': False
            }

def setup_bedrock_access():
    """
    Guide for setting up AWS Bedrock access
    """
    print_section("🔧 AWS Bedrock Setup Guide")
    
    print("""
Prerequisites:
1. AWS Account with Bedrock access enabled
2. AWS credentials (Access Key ID and Secret)
3. Model access granted in AWS Console

Step 1: Enable Bedrock in AWS Console
---------------------------------------
1. Go to AWS Console → Bedrock
2. Request model access for Claude 3
3. Wait for approval (usually instant for Sonnet)

Step 2: Configure AWS Credentials
----------------------------------
Option A: Environment Variables
    export AWS_ACCESS_KEY_ID=your_access_key
    export AWS_SECRET_ACCESS_KEY=your_secret_key
    export AWS_REGION=us-east-1

Option B: AWS CLI
    aws configure
    # Enter your credentials when prompted

Option C: .env file (add to your .env)
    AWS_ACCESS_KEY_ID=your_access_key
    AWS_SECRET_ACCESS_KEY=your_secret_key
    AWS_REGION=us-east-1

Step 3: Install boto3
----------------------
    pip install boto3

Step 4: Test Connection
-----------------------
    python 03_cloud_integration/aws_bedrock.py

Available Claude Models on Bedrock:
-----------------------------------
- anthropic.claude-3-sonnet-20240229-v1:0  (Recommended)
- anthropic.claude-3-haiku-20240307-v1:0   (Faster, cheaper)
- anthropic.claude-3-opus-20240229-v1:0    (Most capable)

Pricing (approximate):
---------------------
- Claude 3 Sonnet: $3/M input tokens, $15/M output tokens
- Claude 3 Haiku: $0.25/M input tokens, $1.25/M output tokens
- Claude 3 Opus: $15/M input tokens, $75/M output tokens

Benefits of Bedrock:
-------------------
✓ AWS infrastructure and security
✓ No separate API key needed
✓ Integration with AWS services
✓ Enterprise compliance features
✓ Pay-as-you-go pricing
""")

def test_bedrock_connection():
    """Test AWS Bedrock connection"""
    
    print_section("🧪 Testing AWS Bedrock Connection")
    
    # Check if credentials are configured
    if not Config.AWS_ACCESS_KEY_ID or not Config.AWS_SECRET_ACCESS_KEY:
        print("❌ AWS credentials not found!")
        print("\nPlease configure credentials in .env file:")
        print("  AWS_ACCESS_KEY_ID=your_key")
        print("  AWS_SECRET_ACCESS_KEY=your_secret")
        print("  AWS_REGION=us-east-1")
        return False
    
    try:
        # Create analyzer
        print("Creating Bedrock client...")
        analyzer = BedrockClaimAnalyzer(region_name=Config.AWS_REGION)
        print("✓ Client created successfully!")
        
        # Test with sample claim
        print(f"\nAnalyzing sample claim with Bedrock...")
        claim = SAMPLE_CLAIMS[0]
        
        result = analyzer.analyze_claim(claim)
        
        if result['success']:
            print("✓ Analysis successful!\n")
            print(f"Claim: {result['claim_id']}")
            print(f"Model: {result['model']}")
            print(f"Region: {result['region']}")
            print("\nAnalysis:")
            print("-" * 60)
            print(result['analysis'])
            print("-" * 60)
            return True
        else:
            print(f"❌ Analysis failed: {result['error']}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def compare_direct_vs_bedrock():
    """
    Compare using Claude API directly vs through Bedrock
    """
    print_section("📊 Direct API vs AWS Bedrock Comparison")
    
    comparison = """
┌─────────────────────┬─────────────────────────┬─────────────────────────┐
│      Feature        │    Direct API           │     AWS Bedrock         │
├─────────────────────┼─────────────────────────┼─────────────────────────┤
│ Setup               │ Simple (API key only)   │ AWS account required    │
│ Authentication      │ Anthropic API key       │ AWS credentials         │
│ Infrastructure      │ Anthropic's             │ AWS (your account)      │
│ Pricing             │ Per API call            │ AWS pricing + compute   │
│ Integration         │ Direct to Anthropic     │ AWS ecosystem           │
│ Security            │ Standard                │ AWS security features   │
│ Compliance          │ Anthropic's             │ Your AWS compliance     │
│ Rate Limits         │ Anthropic's limits      │ AWS quotas              │
│ Monitoring          │ Limited                 │ CloudWatch integration  │
│ Custom VPC          │ No                      │ Yes                     │
└─────────────────────┴─────────────────────────┴─────────────────────────┘

When to use Direct API:
-----------------------
✓ Simple deployment
✓ Quick prototyping
✓ Small to medium scale
✓ Don't need AWS integration
✓ Prefer simplicity

When to use AWS Bedrock:
------------------------
✓ Already on AWS
✓ Need AWS integration (Lambda, S3, etc.)
✓ Enterprise compliance requirements
✓ Custom VPC needed
✓ Advanced monitoring with CloudWatch
✓ Large scale deployment
✓ Multi-region deployment

Cost Comparison (approximate):
------------------------------
Both use same Claude models, so base costs are similar.
Bedrock adds AWS infrastructure costs but provides more features.
"""
    print(comparison)

def main():
    """Main function to demonstrate AWS Bedrock integration"""
    
    print_section("☁️ AWS Bedrock Integration for Insurance Claims")
    
    print("This module allows you to use Claude through AWS Bedrock.")
    print("\nOptions:")
    print("1. View setup guide")
    print("2. Test Bedrock connection")
    print("3. Compare Direct API vs Bedrock")
    
    choice = input("\nEnter choice (1-3) or press Enter to skip: ").strip()
    
    if choice == '1':
        setup_bedrock_access()
    elif choice == '2':
        test_bedrock_connection()
    elif choice == '3':
        compare_direct_vs_bedrock()
    else:
        print("\nTo use this module:")
        print("1. Configure AWS credentials in .env")
        print("2. Run: python 03_cloud_integration/aws_bedrock.py")
        print("\nFor detailed setup: Choose option 1")

if __name__ == "__main__":
    main()
