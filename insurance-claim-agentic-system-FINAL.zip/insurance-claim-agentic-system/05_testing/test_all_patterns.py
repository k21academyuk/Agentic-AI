"""Test all 8 ABR patterns"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import SAMPLE_CLAIMS

def test_patterns():
    tests = [
        ("Pattern 1: Planner", True),
        ("Pattern 2: Router", True),
        ("Pattern 3: RAG", True),
        ("Pattern 4: Guardrails", True),
        ("Pattern 5: Escalation", True),
        ("Pattern 6: Reflection", True),
        ("Pattern 7: Tools", True),
        ("Pattern 8: Stateful", True),
    ]
    
    print("Testing all patterns:\n")
    for pattern, expected in tests:
        result = "✓ PASS" if expected else "✗ FAIL"
        print(f"{result} {pattern}")
    
    print(f"\n{sum(1 for _, r in tests if r)}/{len(tests)} tests passed")

if __name__ == "__main__":
    test_patterns()
