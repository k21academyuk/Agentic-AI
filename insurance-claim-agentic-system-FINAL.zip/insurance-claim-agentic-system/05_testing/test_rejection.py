"""Test: Claim Rejections"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

def test_rejection_criteria():
    """Test rejection scenarios"""
    scenarios = [
        {"amount": 150000, "type": "Auto", "should_reject": True, "reason": "Exceeds limit"},
        {"amount": 5000, "type": "Auto", "should_reject": False, "reason": "Within limit"},
    ]
    
    for scenario in scenarios:
        limit = {"Auto": 100000}.get(scenario['type'], 100000)
        rejected = scenario['amount'] > limit
        
        assert rejected == scenario['should_reject'], f"Failed: {scenario}"
        print(f"✓ {scenario['reason']}: {'REJECTED' if rejected else 'APPROVED'}")

if __name__ == "__main__":
    test_rejection_criteria()
    print("\n✓ All tests passed!")
