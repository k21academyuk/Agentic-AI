"""Test: Claim Processing Delays"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils import SAMPLE_CLAIMS

def test_delay_scenario():
    """Test what happens with delayed claims"""
    claim = SAMPLE_CLAIMS[0].copy()
    claim['days_since_incident'] = 45  # Delayed by 45 days
    
    if claim['days_since_incident'] > 30:
        return {"status": "WARNING", "msg": "Claim filed late"}
    return {"status": "OK", "msg": "Filed on time"}

if __name__ == "__main__":
    result = test_delay_scenario()
    print(f"Test Result: {result['status']} - {result['msg']}")
    print("✓ Test passed!")
