"""Gradio Web UI Alternative"""
import gradio as gr
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

def analyze_claim(claim_id, claim_type, amount, description):
    return {
        "Decision": "APPROVED",
        "Confidence": "85%",
        "Route": "STANDARD",
        "Priority": "MEDIUM",
        "Reasoning": f"Analyzed {claim_type} claim for ${amount:,.2f}"
    }

demo = gr.Interface(
    fn=analyze_claim,
    inputs=[
        gr.Textbox(label="Claim ID", value="CLM-001"),
        gr.Dropdown(["Auto", "Property", "Health", "Liability"], label="Type"),
        gr.Number(label="Amount ($)", value=5000),
        gr.Textbox(label="Description", lines=3)
    ],
    outputs=gr.JSON(label="Analysis Result"),
    title="🏢 Insurance Claim Analyzer",
    description="AI-powered claim processing system"
)

if __name__ == "__main__":
    demo.launch()
