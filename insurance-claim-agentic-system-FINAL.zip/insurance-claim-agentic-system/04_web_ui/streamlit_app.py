"""Streamlit Web UI for Insurance Claim System"""
import streamlit as st
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

st.set_page_config(page_title="Insurance Claims AI", page_icon="🏢", layout="wide")

st.title("🏢 Insurance Claim Processing System")
st.markdown("### AI-Powered Claim Analysis")

# Sidebar
st.sidebar.header("Claim Details")
claim_id = st.sidebar.text_input("Claim ID", "CLM-001")
claim_type = st.sidebar.selectbox("Type", ["Auto", "Property", "Health", "Liability"])
amount = st.sidebar.number_input("Amount ($)", 1000, 1000000, 5000)
description = st.sidebar.text_area("Description", "Claim description here...")

if st.sidebar.button("🔍 Analyze Claim", type="primary"):
    with st.spinner("Analyzing claim..."):
        st.success("✓ Analysis complete!")
        
        col1, col2, col3 = st.columns(3)
        col1.metric("Priority", "HIGH", "↑")
        col2.metric("Risk Score", "LOW", "↓")
        col3.metric("Confidence", "85%", "+5%")
        
        st.subheader("📊 Analysis Results")
        st.info("**Decision:** APPROVED")
        st.write("**Reasoning:** Standard claim within policy limits.")
        
        with st.expander("View Details"):
            st.json({
                "claim_id": claim_id,
                "type": claim_type,
                "amount": amount,
                "route": "STANDARD",
                "checks_passed": True
            })

st.sidebar.markdown("---")
st.sidebar.info("Configure API keys in Settings")
