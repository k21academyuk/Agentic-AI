"""
Utility functions for the Insurance Claim Agentic System
"""
import json
import logging
from datetime import datetime
from typing import Dict, List, Any
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def setup_logger(name: str) -> logging.Logger:
    """Create a logger with the given name"""
    return logging.getLogger(name)

def save_json(data: Dict, filepath: Path):
    """Save data to JSON file"""
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2)

def load_json(filepath: Path) -> Dict:
    """Load data from JSON file"""
    with open(filepath, 'r') as f:
        return json.load(f)

def format_claim_data(claim: Dict) -> str:
    """Format claim data for display"""
    return f"""
Claim ID: {claim.get('claim_id', 'N/A')}
Type: {claim.get('claim_type', 'N/A')}
Amount: ${claim.get('claim_amount', 0):,.2f}
Date: {claim.get('claim_date', 'N/A')}
Status: {claim.get('status', 'Pending')}
Description: {claim.get('description', 'N/A')}
"""

def calculate_claim_priority(claim: Dict) -> str:
    """
    Calculate claim priority based on amount and type
    
    Priority levels:
    - URGENT: Amount > $50,000 or accident/injury
    - HIGH: Amount > $10,000
    - MEDIUM: Amount > $1,000
    - LOW: Amount <= $1,000
    """
    amount = claim.get('claim_amount', 0)
    claim_type = claim.get('claim_type', '').lower()
    
    # Urgent cases
    if amount > 50000 or claim_type in ['accident', 'injury', 'liability']:
        return "URGENT"
    
    # High priority
    if amount > 10000:
        return "HIGH"
    
    # Medium priority
    if amount > 1000:
        return "MEDIUM"
    
    # Low priority
    return "LOW"

def validate_claim_data(claim: Dict) -> tuple:
    """
    Validate claim data completeness
    
    Returns:
        (is_valid, error_message)
    """
    required_fields = ['claim_id', 'claim_type', 'claim_amount', 'claim_date']
    
    for field in required_fields:
        if field not in claim:
            return False, f"Missing required field: {field}"
    
    # Validate amount is positive
    if claim['claim_amount'] <= 0:
        return False, "Claim amount must be positive"
    
    return True, "Valid"

def generate_claim_id() -> str:
    """Generate a unique claim ID"""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    return f"CLM-{timestamp}"

def extract_key_info(text: str) -> Dict[str, Any]:
    """
    Extract key information from claim description text
    Uses simple keyword matching (can be enhanced with NLP)
    """
    text_lower = text.lower()
    
    info = {
        'involves_injury': any(word in text_lower for word in ['injury', 'hurt', 'injured', 'pain']),
        'involves_property': any(word in text_lower for word in ['property', 'damage', 'house', 'car', 'vehicle']),
        'involves_theft': any(word in text_lower for word in ['theft', 'stolen', 'robbery', 'burglary']),
        'involves_weather': any(word in text_lower for word in ['storm', 'flood', 'hurricane', 'tornado', 'hail']),
        'urgency_keywords': any(word in text_lower for word in ['urgent', 'emergency', 'immediate', 'critical'])
    }
    
    return info

class ClaimTimer:
    """Simple timer for tracking processing time"""
    
    def __init__(self):
        self.start_time = None
        self.end_time = None
    
    def start(self):
        """Start the timer"""
        self.start_time = datetime.now()
    
    def stop(self):
        """Stop the timer"""
        self.end_time = datetime.now()
    
    def elapsed(self) -> float:
        """Get elapsed time in seconds"""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return 0.0
    
    def elapsed_str(self) -> str:
        """Get elapsed time as formatted string"""
        elapsed = self.elapsed()
        return f"{elapsed:.2f} seconds"

def print_section(title: str, content: str = ""):
    """Print a formatted section header"""
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)
    if content:
        print(content)
    print()

def print_result(label: str, value: Any):
    """Print a result in a formatted way"""
    print(f"  {label}: {value}")

# Sample claim data for testing
SAMPLE_CLAIMS = [
    {
        "claim_id": "CLM-001",
        "claim_type": "Auto",
        "claim_amount": 5000,
        "claim_date": "2024-01-15",
        "description": "Minor fender bender in parking lot. No injuries.",
        "policy_number": "POL-12345",
        "claimant_name": "John Doe"
    },
    {
        "claim_id": "CLM-002",
        "claim_type": "Property",
        "claim_amount": 75000,
        "claim_date": "2024-01-20",
        "description": "Severe storm damage to roof and windows. Emergency repairs needed.",
        "policy_number": "POL-67890",
        "claimant_name": "Jane Smith"
    },
    {
        "claim_id": "CLM-003",
        "claim_type": "Health",
        "claim_amount": 2500,
        "claim_date": "2024-01-22",
        "description": "Routine medical procedure. Pre-authorized.",
        "policy_number": "POL-11111",
        "claimant_name": "Bob Johnson"
    },
    {
        "claim_id": "CLM-004",
        "claim_type": "Liability",
        "claim_amount": 150000,
        "claim_date": "2024-01-25",
        "description": "Customer injured on business premises. Legal claim filed.",
        "policy_number": "POL-22222",
        "claimant_name": "Alice Williams"
    }
]

if __name__ == "__main__":
    # Test utility functions
    print("Testing utility functions...")
    
    for claim in SAMPLE_CLAIMS:
        print("\n" + "="*60)
        print(format_claim_data(claim))
        print(f"Priority: {calculate_claim_priority(claim)}")
        is_valid, msg = validate_claim_data(claim)
        print(f"Valid: {is_valid} - {msg}")
        
        key_info = extract_key_info(claim['description'])
        print(f"Key Info: {key_info}")
