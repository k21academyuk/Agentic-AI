# Complete Code Files for Insurance Claim Agentic System

## This document contains all the remaining code files you need to create.
## Copy each section to the corresponding file path.

---

## File: 02_patterns/planner_agent.py

```python
"""
ABR Pattern 1: Planner Agent
Goal-oriented task decomposition and planning
"""

import anthropic
import json
import sys
sys.path.append('..')
from config import Config
from utils import print_section, SAMPLE_CLAIMS

def create_processing_plan(claim: dict) -> dict:
    """Create a step-by-step plan for claim processing"""
    
    client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)
    
    prompt = f"""You are a planning agent for insurance claims. 
    
Analyze this claim and create a detailed processing plan:

Claim Details:
- ID: {claim['claim_id']}
- Type: {claim['claim_type']}
- Amount: ${claim['claim_amount']:,.2f}
- Description: {claim['description']}

Create a plan with 4-6 steps. For each step include:
1. Step number
2. Action description
3. Expected outcome
4. Success criteria
5. Estimated time

Respond in JSON format:
{{
  "plan": [
    {{
      "step": 1,
      "action": "Verify claim information",
      "outcome": "Confirmed data accuracy",
      "criteria": "All required fields present",
      "time_estimate": "5 minutes"
    }}
  ],
  "total_time": "30 minutes",
  "complexity": "medium"
}}"""

    response = client.messages.create(
        model=Config.CLAUDE_MODEL,
        max_tokens=2000,
        messages=[{"role": "user", "content": prompt}]
    )
    
    # Parse response
    text = response.content[0].text
    start = text.find('{')
    end = text.rfind('}') + 1
    plan = json.loads(text[start:end])
    
    return plan

def main():
    print_section("📋 ABR Pattern 1: Planner Agent")
    
    claim = SAMPLE_CLAIMS[0]
    print(f"Creating plan for: {claim['claim_id']}")
    
    plan = create_processing_plan(claim)
    
    print(f"\nPlan Complexity: {plan.get('complexity', 'N/A')}")
    print(f"Estimated Time: {plan.get('total_time', 'N/A')}\n")
    
    print("Processing Steps:")
    for step in plan.get('plan', []):
        print(f"\nStep {step['step']}: {step['action']}")
        print(f"  Outcome: {step['outcome']}")
        print(f"  Criteria: {step['criteria']}")
        print(f"  Time: {step['time_estimate']}")
    
    print("\n✓ Pattern 1 Complete!")

if __name__ == "__main__":
    main()
```

---

## File: 02_patterns/router_agent.py

```python
"""
ABR Pattern 2: Router Agent
Intelligent routing based on claim characteristics
"""

import anthropic
import sys
sys.path.append('..')
from config import Config
from utils import print_section, SAMPLE_CLAIMS, calculate_claim_priority

class ClaimRouter:
    """Routes claims to appropriate processing pathways"""
    
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)
        
        self.routes = {
            "FAST_TRACK": "Simple claims under $5k - Auto-approve",
            "STANDARD": "Regular claims $5k-$50k - Standard review",
            "COMPLEX": "Complex claims $50k-$100k - Detailed analysis",
            "EXECUTIVE": "High-value claims >$100k - Executive review",
            "FRAUD": "Suspicious claims - Fraud investigation",
            "LEGAL": "Claims with legal issues - Legal review"
        }
    
    def route_claim(self, claim: dict) -> dict:
        """Determine the best route for a claim"""
        
        prompt = f"""You are a routing agent. Analyze this claim and determine the best processing route.

Claim:
- Type: {claim['claim_type']}
- Amount: ${claim['claim_amount']:,.2f}
- Priority: {calculate_claim_priority(claim)}
- Description: {claim['description']}

Available Routes:
{json.dumps(self.routes, indent=2)}

Respond with:
ROUTE: [chosen route]
CONFIDENCE: [0-100]%
REASONING: [why this route]
ESTIMATED_TIME: [processing time]"""

        response = self.client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=512,
            messages=[{"role": "user", "content": prompt}]
        )
        
        result_text = response.content[0].text
        result = {}
        
        for line in result_text.split('\n'):
            if 'ROUTE:' in line:
                result['route'] = line.split(':', 1)[1].strip()
            elif 'CONFIDENCE:' in line:
                result['confidence'] = line.split(':', 1)[1].strip()
            elif 'REASONING:' in line:
                result['reasoning'] = line.split(':', 1)[1].strip()
            elif 'ESTIMATED_TIME:' in line:
                result['time'] = line.split(':', 1)[1].strip()
        
        return result

def main():
    print_section("🔀 ABR Pattern 2: Router Agent")
    
    router = ClaimRouter()
    
    print("Available Routes:")
    for route, desc in router.routes.items():
        print(f"  {route}: {desc}")
    
    print("\n\nRouting Test Claims:\n")
    
    for claim in SAMPLE_CLAIMS:
        result = router.route_claim(claim)
        print(f"\nClaim {claim['claim_id']} (${claim['claim_amount']:,.2f})")
        print(f"  → Route: {result.get('route', 'N/A')}")
        print(f"  → Confidence: {result.get('confidence', 'N/A')}")
        print(f"  → Time: {result.get('time', 'N/A')}")
    
    print("\n✓ Pattern 2 Complete!")

if __name__ == "__main__":
    main()
```

---

## File: 02_patterns/rag_agent.py

```python
"""
ABR Pattern 3: RAG Agent
Retrieval-Augmented Generation for knowledge-based decisions
"""

import anthropic
import sys
sys.path.append('..')
from config import Config
from utils import print_section, SAMPLE_CLAIMS

class KnowledgeBase:
    """Simulated knowledge base for insurance policies"""
    
    def __init__(self):
        self.policies = {
            "Auto": """
            Auto Insurance Policy Guidelines:
            - Collision damage covered up to policy limits
            - Deductible applies to all claims
            - Rental car coverage for 30 days
            - Total loss if repair > 75% of vehicle value
            - Police report required for claims >$5,000
            - Maximum liability: $100,000 per incident
            """,
            
            "Property": """
            Property Insurance Policy Guidelines:
            - Dwelling coverage up to policy limits
            - Natural disasters covered (flood requires separate policy)
            - Temporary housing covered up to 20% of dwelling coverage
            - Personal property covered at replacement cost
            - Claims must be filed within 60 days
            - Maximum coverage: $500,000
            """,
            
            "Health": """
            Health Insurance Policy Guidelines:
            - Pre-authorization required for procedures >$10,000
            - In-network providers: 80/20 coverage
            - Out-of-network: 60/40 coverage
            - Annual deductible: $2,500 individual, $5,000 family
            - Out-of-pocket maximum: $8,000
            - Emergency care covered at in-network rates
            """,
            
            "Liability": """
            Liability Insurance Policy Guidelines:
            - Coverage for bodily injury and property damage
            - Legal defense costs covered
            - Maximum per occurrence: $1,000,000
            - Aggregate limit: $2,000,000
            - Incident must be reported within 72 hours
            - Cooperation required for defense
            """
        }
    
    def retrieve(self, claim_type: str, query: str = "") -> str:
        """Retrieve relevant policy information"""
        return self.policies.get(claim_type, "No policy found")

class RAGAgent:
    """Agent that uses knowledge retrieval for decisions"""
    
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)
        self.kb = KnowledgeBase()
    
    def analyze_with_knowledge(self, claim: dict) -> dict:
        """Analyze claim using retrieved knowledge"""
        
        # Retrieve relevant knowledge
        knowledge = self.kb.retrieve(claim['claim_type'])
        
        prompt = f"""You are an insurance analyst with access to policy knowledge.

CLAIM:
{json.dumps(claim, indent=2)}

RELEVANT POLICY KNOWLEDGE:
{knowledge}

Based on the policy guidelines, analyze:
1. Is this claim covered?
2. What is the maximum payout?
3. Are there any conditions or requirements?
4. What documentation is needed?

Provide clear answers to each question."""

        response = self.client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}]
        )
        
        return {
            "analysis": response.content[0].text,
            "knowledge_used": knowledge
        }

def main():
    print_section("📚 ABR Pattern 3: RAG Agent")
    
    agent = RAGAgent()
    
    claim = SAMPLE_CLAIMS[1]  # Property claim
    print(f"Analyzing: {claim['claim_id']} - {claim['claim_type']}")
    print(f"Amount: ${claim['claim_amount']:,.2f}\n")
    
    result = agent.analyze_with_knowledge(claim)
    
    print("Knowledge Retrieved:")
    print("-" * 60)
    print(result['knowledge_used'])
    
    print("\nAnalysis:")
    print("-" * 60)
    print(result['analysis'])
    
    print("\n✓ Pattern 3 Complete!")

if __name__ == "__main__":
    main()
```

---

## File: 02_patterns/guardrail_agent.py

```python
"""
ABR Pattern 4: Guardrail Agent
Compliance and safety checks
"""

import anthropic
import sys
sys.path.append('..')
from config import Config
from utils import print_section, SAMPLE_CLAIMS, validate_claim_data

class ComplianceGuardrails:
    """Ensures claims meet regulatory and business requirements"""
    
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)
        
        self.rules = {
            "data_validation": "All required fields must be present",
            "amount_limits": "Claims must be within policy limits",
            "time_limits": "Claims must be filed within policy timeframe",
            "documentation": "Required documents must be provided",
            "fraud_indicators": "No fraud indicators present",
            "regulatory": "Meets state insurance regulations"
        }
    
    def check_guardrails(self, claim: dict, decision: str) -> dict:
        """Run all compliance checks"""
        
        checks = {}
        
        # 1. Data validation
        is_valid, msg = validate_claim_data(claim)
        checks['data_validation'] = {
            "passed": is_valid,
            "message": msg
        }
        
        # 2. Amount limits
        amount = claim.get('claim_amount', 0)
        claim_type = claim.get('claim_type', '')
        
        limits = {
            "Auto": 100000,
            "Property": 500000,
            "Health": 150000,
            "Liability": 1000000
        }
        
        limit = limits.get(claim_type, 100000)
        checks['amount_limits'] = {
            "passed": amount <= limit,
            "message": f"Amount ${amount:,.2f} vs limit ${limit:,.2f}"
        }
        
        # 3. AI-based compliance check
        prompt = f"""You are a compliance officer. Check if this claim and decision meet regulations.

Claim Type: {claim_type}
Amount: ${amount:,.2f}
Decision: {decision}
Description: {claim.get('description', '')}

Check for:
- Regulatory compliance
- Policy adherence
- Fraud indicators
- Documentation requirements

Respond with:
COMPLIANT: [YES/NO]
ISSUES: [List any issues or "None"]
RECOMMENDATIONS: [Any recommendations]"""

        response = self.client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=512,
            messages=[{"role": "user", "content": prompt}]
        )
        
        ai_check = response.content[0].text
        checks['ai_compliance'] = {
            "passed": "COMPLIANT: YES" in ai_check,
            "details": ai_check
        }
        
        # Overall pass/fail
        all_passed = all(check['passed'] for check in checks.values() if isinstance(check, dict))
        
        return {
            "passed": all_passed,
            "checks": checks,
            "summary": "All guardrails passed" if all_passed else "Some guardrails failed"
        }

def main():
    print_section("🛡️ ABR Pattern 4: Guardrail Agent")
    
    guardrails = ComplianceGuardrails()
    
    print("Configured Guardrails:")
    for rule, description in guardrails.rules.items():
        print(f"  ✓ {rule}: {description}")
    
    print("\n\nTesting Claims:\n")
    
    for claim in SAMPLE_CLAIMS[:2]:
        print(f"\nClaim: {claim['claim_id']} - ${claim['claim_amount']:,.2f}")
        
        result = guardrails.check_guardrails(claim, "APPROVED")
        
        print(f"Overall: {'✓ PASSED' if result['passed'] else '✗ FAILED'}")
        
        for check_name, check_result in result['checks'].items():
            if isinstance(check_result, dict):
                status = "✓" if check_result['passed'] else "✗"
                print(f"  {status} {check_name}: {check_result.get('message', 'OK')}")
    
    print("\n✓ Pattern 4 Complete!")

if __name__ == "__main__":
    main()
```

---

I'll create a master document with all remaining files. Let me continue:
