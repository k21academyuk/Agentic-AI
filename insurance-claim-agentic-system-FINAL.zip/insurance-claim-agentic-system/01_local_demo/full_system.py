"""
Full System - Complete Insurance Claim Processing System

This brings together all 8 ABR patterns into a production-ready system.

Features:
- Planning and goal decomposition
- Intelligent routing
- Knowledge retrieval (RAG)
- Compliance guardrails
- Human escalation
- Self-reflection
- Tool integration
- Stateful conversations

Estimated time: 1 hour to understand
"""

import anthropic
import json
import re
from datetime import datetime
from typing import Dict, List, Optional
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Config
from utils import (
    print_section, print_result, SAMPLE_CLAIMS,
    calculate_claim_priority, validate_claim_data
)

class InsuranceClaimSystem:
    """Complete insurance claim processing system with all ABR patterns"""
    
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)
        self.conversation_history = []
        self.claim_memory = {}
        self.processing_log = []
        
    def log_step(self, step: str, details: str):
        """Log processing steps"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "step": step,
            "details": details
        }
        self.processing_log.append(entry)
        print(f"  📝 {step}: {details[:80]}...")
    
    def pattern_1_planner(self, claim: dict) -> Dict:
        """
        ABR Pattern 1: Goal Planning
        Breaks down claim processing into sub-tasks
        """
        self.log_step("PLANNER", "Creating processing plan")
        
        prompt = f"""You are a planning agent. Create a step-by-step plan to process this claim:

Claim: {claim['claim_id']} - {claim['claim_type']} for ${claim['claim_amount']:,.2f}
Description: {claim['description']}

Create a plan with 3-5 steps. For each step, specify:
1. Action to take
2. Expected outcome
3. Success criteria

Format as JSON with structure:
{{"plan": [{{"step": 1, "action": "...", "outcome": "...", "criteria": "..."}}]}}"""
        
        response = self.client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}]
        )
        
        # Parse plan
        try:
            plan_text = response.content[0].text
            # Extract JSON from response
            start = plan_text.find('{')
            end = plan_text.rfind('}') + 1
            plan = json.loads(plan_text[start:end])
            return plan
        except:
            return {"plan": [{"step": 1, "action": "Standard processing", "outcome": "Decision", "criteria": "Complete"}]}
    
    def pattern_2_router(self, claim: dict) -> str:
        """
        ABR Pattern 2: Intelligent Routing
        Routes claim to appropriate processing pathway
        """
        self.log_step("ROUTER", "Determining processing route")
        
        priority = calculate_claim_priority(claim)
        amount = claim['claim_amount']
        
        # Route based on complexity
        if priority == "URGENT" or amount > 50000:
            return "COMPLEX_PATHWAY"
        elif amount > 10000:
            return "STANDARD_PATHWAY"
        else:
            return "SIMPLE_PATHWAY"
    
    def pattern_3_rag(self, claim: dict) -> Dict:
        """
        ABR Pattern 3: Knowledge Retrieval (RAG)
        Retrieves relevant policy information
        """
        self.log_step("RAG", "Retrieving policy knowledge")
        
        # Simulated knowledge base
        knowledge = {
            "Auto": {
                "max_amount": 50000,
                "required_docs": ["police report", "photos", "estimate"],
                "approval_criteria": "Clear liability and within coverage"
            },
            "Property": {
                "max_amount": 500000,
                "required_docs": ["photos", "contractor estimate", "proof of ownership"],
                "approval_criteria": "Covered peril and reasonable cost"
            },
            "Health": {
                "max_amount": 100000,
                "required_docs": ["medical records", "bills", "pre-authorization"],
                "approval_criteria": "Medically necessary and in-network"
            },
            "Liability": {
                "max_amount": 1000000,
                "required_docs": ["incident report", "legal claim", "evidence"],
                "approval_criteria": "Liability established and within policy limits"
            }
        }
        
        claim_type = claim.get('claim_type', 'Auto')
        return knowledge.get(claim_type, knowledge['Auto'])
    
    def pattern_4_guardrails(self, claim: dict, decision: str) -> tuple:
        """
        ABR Pattern 4: Compliance Guardrails
        Ensures decision meets regulatory requirements
        """
        self.log_step("GUARDRAILS", "Checking compliance")
        
        # Check claim validity
        is_valid, msg = validate_claim_data(claim)
        if not is_valid:
            return False, f"Data validation failed: {msg}"
        
        # Check amount limits
        amount = claim['claim_amount']
        if amount > 1000000:
            return False, "Amount exceeds policy maximum"
        
        # Check decision consistency
        if decision == "APPROVED" and amount > 100000:
            # High-value approvals need additional review
            return False, "High-value approval requires manual review"
        
        return True, "All guardrails passed"
    
    def pattern_5_human_escalation(self, claim: dict, confidence: float) -> bool:
        """
        ABR Pattern 5: Human Escalation
        Determines if human review is needed
        """
        self.log_step("ESCALATION", "Checking escalation criteria")
        
        # Escalate if:
        # 1. Low confidence (< 70%)
        # 2. High value (> $50k)
        # 3. Complex type (Liability)
        
        if confidence < 0.70:
            return True
        
        if claim['claim_amount'] > 50000:
            return True
        
        if claim['claim_type'] == 'Liability':
            return True
        
        return False
    
    def pattern_6_reflection(self, decision: dict) -> Dict:
        """
        ABR Pattern 6: Self-Reflection
        Agent reflects on its decision quality
        """
        self.log_step("REFLECTION", "Self-evaluating decision")
        
        prompt = f"""Review this claim decision and assess its quality:

Decision: {decision.get('decision', 'N/A')}
Reasoning: {decision.get('reasoning', 'N/A')}
Confidence: {decision.get('confidence', 0)}%

Rate the decision quality (1-10) and suggest improvements.
Format: RATING: X/10
IMPROVEMENTS: [list improvements or "None needed"]"""
        
        response = self.client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=512,
            messages=[{"role": "user", "content": prompt}]
        )
        
        reflection = response.content[0].text
        return {"reflection": reflection}
    
    def pattern_7_tools(self, claim: dict) -> Dict:
        """
        ABR Pattern 7: Tool Integration
        Uses external tools (simulated)
        """
        self.log_step("TOOLS", "Calling external tools")
        
        # Simulate tool calls
        tools_used = {
            "policy_lookup": {
                "policy_valid": True,
                "coverage_amount": 100000,
                "deductible": 500
            },
            "fraud_check": {
                "risk_score": 0.15,  # Low risk
                "flags": []
            },
            "claims_history": {
                "previous_claims": 2,
                "last_claim_date": "2023-06-15"
            }
        }
        
        return tools_used
    
    def pattern_8_stateful(self, claim: dict, context: str) -> None:
        """
        ABR Pattern 8: Stateful Agent
        Maintains conversation context
        """
        self.log_step("STATEFUL", "Updating conversation memory")
        
        # Store in memory
        claim_id = claim['claim_id']
        self.claim_memory[claim_id] = {
            "claim": claim,
            "context": context,
            "timestamp": datetime.now().isoformat(),
            "history": self.conversation_history.copy()
        }

    def parse_decision(self, decision_text: str) -> Dict:
        """
        Robustly parse Claude's decision response.
        Handles markdown formatting like **APPROVED**, `82`**, ~85%, etc.
        """
        decision = {"raw": decision_text}

        for line in decision_text.split('\n'):
            if 'DECISION:' in line:
                raw = line.split(':', 1)[1].strip()
                # Strip markdown bold/italic/code characters
                decision['decision'] = re.sub(r'[`*_]', '', raw).strip()

            elif 'CONFIDENCE:' in line:
                conf_str = line.split(':', 1)[1].strip()
                # Strip markdown characters and % sign
                conf_str = re.sub(r'[`*_%]', '', conf_str).strip()
                # Extract first number found (handles "82", "82.5", "~82", etc.)
                match = re.search(r'\d+\.?\d*', conf_str)
                if match:
                    value = float(match.group())
                    # If someone wrote 0.82 instead of 82, keep it as-is
                    decision['confidence'] = value / 100 if value > 1 else value
                else:
                    decision['confidence'] = 0.80  # Safe default

            elif 'REASONING:' in line:
                raw = line.split(':', 1)[1].strip()
                decision['reasoning'] = re.sub(r'[`*_]', '', raw).strip()

        return decision

    def process_claim(self, claim: dict) -> Dict:
        """
        Main processing function using all 8 ABR patterns
        """
        print_section(f"🔄 PROCESSING CLAIM {claim['claim_id']}")
        
        # Pattern 1: Create processing plan
        plan = self.pattern_1_planner(claim)
        print(f"\n  📋 Plan created with {len(plan.get('plan', []))} steps")
        
        # Pattern 2: Route to appropriate pathway
        route = self.pattern_2_router(claim)
        print(f"  🔀 Routed to: {route}")
        
        # Pattern 3: Retrieve knowledge
        knowledge = self.pattern_3_rag(claim)
        print(f"  📚 Knowledge retrieved for {claim['claim_type']} claims")
        
        # Pattern 7: Use external tools
        tool_results = self.pattern_7_tools(claim)
        print(f"  🔧 Tools executed: {len(tool_results)} tools called")
        
        # Make decision
        print("\n  🤔 Making decision...")
        decision_prompt = f"""Analyze this claim and make a decision:

Claim: {json.dumps(claim, indent=2)}
Route: {route}
Knowledge: {json.dumps(knowledge, indent=2)}
Tool Results: {json.dumps(tool_results, indent=2)}

Provide your answer in EXACTLY this format (no markdown, no bold, no backticks):
DECISION: APPROVED
CONFIDENCE: 85
REASONING: Brief explanation here"""
        
        response = self.client.messages.create(
            model=Config.CLAUDE_MODEL,
            max_tokens=1024,
            messages=[{"role": "user", "content": decision_prompt}]
        )
        
        decision_text = response.content[0].text

        # Use robust parser
        decision = self.parse_decision(decision_text)
        
        # Pattern 4: Check guardrails
        passed, msg = self.pattern_4_guardrails(claim, decision.get('decision', ''))
        print(f"\n  🛡️  Guardrails: {'✓ PASSED' if passed else '✗ FAILED'} - {msg}")
        
        if not passed:
            decision['decision'] = 'MANUAL_REVIEW'
            decision['reasoning'] = f"Guardrail check failed: {msg}"
        
        # Pattern 5: Check escalation
        needs_escalation = self.pattern_5_human_escalation(claim, decision.get('confidence', 0))
        if needs_escalation:
            print(f"  👤 ESCALATION: Human review required")
            decision['escalated'] = True
        
        # Pattern 6: Reflect on decision
        reflection = self.pattern_6_reflection(decision)
        print(f"  🔍 Self-reflection completed")
        
        # Pattern 8: Update state
        self.pattern_8_stateful(claim, f"Processed via {route}")
        
        # Compile final result
        result = {
            "claim_id": claim['claim_id'],
            "route": route,
            "decision": decision,
            "reflection": reflection,
            "escalated": needs_escalation,
            "guardrails_passed": passed,
            "processing_log": self.processing_log.copy()
        }
        
        return result

def main():
    """Main demonstration of the full system"""
    
    print_section("🏢 COMPLETE INSURANCE CLAIM SYSTEM",
                  "All 8 ABR Patterns Working Together")
    
    print("System Features:")
    print("  ✓ Pattern 1: Goal Planning")
    print("  ✓ Pattern 2: Intelligent Routing")
    print("  ✓ Pattern 3: Knowledge Retrieval (RAG)")
    print("  ✓ Pattern 4: Compliance Guardrails")
    print("  ✓ Pattern 5: Human Escalation")
    print("  ✓ Pattern 6: Self-Reflection")
    print("  ✓ Pattern 7: Tool Integration")
    print("  ✓ Pattern 8: Stateful Memory")
    
    try:
        # Initialize system
        print("\n\nInitializing system...")
        system = InsuranceClaimSystem()
        print("✓ System ready!")
        
        # Process multiple claims
        print("\n\n" + "="*60)
        print("  PROCESSING CLAIMS")
        print("="*60)
        
        results = []
        for i, claim in enumerate(SAMPLE_CLAIMS[:2], 1):  # Process first 2 claims
            print(f"\n\n{'='*60}")
            print(f"  CLAIM {i} of 2")
            print('='*60)
            
            result = system.process_claim(claim)
            results.append(result)
            
            # Show result summary
            print_section("📊 RESULT SUMMARY")
            print_result("Claim ID", result['claim_id'])
            print_result("Route", result['route'])
            print_result("Decision", result['decision'].get('decision', 'N/A'))
            print_result("Confidence", f"{result['decision'].get('confidence', 0)*100:.0f}%")
            print_result("Escalated", "YES" if result['escalated'] else "NO")
            print_result("Guardrails", "✓ PASSED" if result['guardrails_passed'] else "✗ FAILED")
        
        # Final summary
        print("\n\n" + "="*60)
        print("  FINAL SUMMARY")
        print("="*60)
        print(f"\n  Total Claims Processed: {len(results)}")
        print(f"  Approved: {sum(1 for r in results if r['decision'].get('decision') == 'APPROVED')}")
        print(f"  Rejected: {sum(1 for r in results if r['decision'].get('decision') == 'REJECTED')}")
        print(f"  Manual Review: {sum(1 for r in results if r['decision'].get('decision') == 'MANUAL_REVIEW')}")
        print(f"  Escalated: {sum(1 for r in results if r['escalated'])}")
        
        print("\n\n" + "="*60)
        print("  CONGRATULATIONS!")
        print("="*60)
        print("\n  You've seen all 8 ABR patterns in action!")
        print("\n  Next Steps:")
        print("  1. Explore individual patterns in 02_patterns/")
        print("  2. Try the web UI in 04_web_ui/")
        print("  3. Run tests in 05_testing/")
        print("  4. Deploy to cloud using 06_deployment/")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
