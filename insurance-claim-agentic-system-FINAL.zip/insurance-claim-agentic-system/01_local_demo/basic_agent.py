"""
Basic Agent - Your First Insurance Claim Agent

This is the simplest example to understand how an AI agent works.
The agent can analyze a single insurance claim and provide a decision.

Learning Goals:
- Understand how to call Claude API
- See how to structure a prompt for claims
- Learn basic agent decision-making

Estimated time: 15 minutes
"""

import anthropic
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Config
from utils import print_section, print_result, SAMPLE_CLAIMS

def create_basic_agent():
    """Create a simple Claude client"""
    return anthropic.Anthropic(api_key=Config.ANTHROPIC_API_KEY)

def analyze_claim(client: anthropic.Anthropic, claim: dict) -> dict:
    """
    Analyze a single claim using Claude
    
    Args:
        client: Anthropic client
        claim: Dictionary containing claim information
        
    Returns:
        Dictionary with analysis results
    """
    
    # Create a clear prompt for the agent
    prompt = f"""You are an insurance claim analyst AI agent. Analyze this claim and provide a decision.

Claim Details:
- Claim ID: {claim['claim_id']}
- Type: {claim['claim_type']}
- Amount: ${claim['claim_amount']:,.2f}
- Date: {claim['claim_date']}
- Description: {claim['description']}
- Policy Number: {claim['policy_number']}
- Claimant: {claim['claimant_name']}

Your task:
1. Assess if this claim should be APPROVED, REJECTED, or needs MANUAL_REVIEW
2. Provide confidence level (0-100%)
3. Give reasoning for your decision
4. List any red flags or concerns

Respond in this format:
DECISION: [APPROVED/REJECTED/MANUAL_REVIEW]
CONFIDENCE: [0-100]%
REASONING: [Your reasoning here]
RED_FLAGS: [List any concerns, or "None"]
"""

    # Call Claude API
    response = client.messages.create(
        model=Config.CLAUDE_MODEL,
        max_tokens=Config.MAX_TOKENS,
        temperature=Config.TEMPERATURE,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )
    
    # Extract the response text
    result_text = response.content[0].text
    
    # Parse the response (simple parsing)
    result = {
        "raw_response": result_text,
        "claim_id": claim['claim_id'],
        "amount": claim['claim_amount']
    }
    
    # Extract decision
    for line in result_text.split('\n'):
        if line.startswith('DECISION:'):
            result['decision'] = line.split(':', 1)[1].strip()
        elif line.startswith('CONFIDENCE:'):
            result['confidence'] = line.split(':', 1)[1].strip()
        elif line.startswith('REASONING:'):
            result['reasoning'] = line.split(':', 1)[1].strip()
        elif line.startswith('RED_FLAGS:'):
            result['red_flags'] = line.split(':', 1)[1].strip()
    
    return result

def main():
    """Main function to run the basic agent"""
    
    print_section("🤖 BASIC AGENT DEMO", "Learning how a single agent works")
    
    try:
        # Step 1: Create the agent
        print("Step 1: Creating AI agent...")
        client = create_basic_agent()
        print("✓ Agent created successfully!")
        
        # Step 2: Select a claim to analyze
        print("\nStep 2: Selecting claim to analyze...")
        claim = SAMPLE_CLAIMS[0]  # Start with first sample claim
        print(f"✓ Selected: {claim['claim_id']} - {claim['claim_type']} claim for ${claim['claim_amount']:,.2f}")
        
        # Step 3: Analyze the claim
        print("\nStep 3: Analyzing claim with AI agent...")
        result = analyze_claim(client, claim)
        print("✓ Analysis complete!")
        
        # Step 4: Display results
        print_section("📊 ANALYSIS RESULTS")
        print_result("Claim ID", result.get('claim_id', 'N/A'))
        print_result("Decision", result.get('decision', 'N/A'))
        print_result("Confidence", result.get('confidence', 'N/A'))
        print_result("Reasoning", result.get('reasoning', 'N/A'))
        print_result("Red Flags", result.get('red_flags', 'N/A'))
        
        print("\n" + "="*60)
        print("Full AI Response:")
        print("-"*60)
        print(result.get('raw_response', ''))
        print("="*60)
        
        # Step 5: Try with different claims
        print("\n\n" + "="*60)
        print("  NEXT STEPS")
        print("="*60)
        print("\n1. Try analyzing other claims by changing SAMPLE_CLAIMS[0] to [1], [2], or [3]")
        print("2. Modify the prompt to ask different questions")
        print("3. Move to multi_agent.py to see multiple agents working together")
        print("\n✓ You've completed the basic agent tutorial!")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("\nTroubleshooting:")
        print("1. Check if ANTHROPIC_API_KEY is set in .env file")
        print("2. Verify you have internet connection")
        print("3. Ensure anthropic package is installed: pip install anthropic")

if __name__ == "__main__":
    main()
