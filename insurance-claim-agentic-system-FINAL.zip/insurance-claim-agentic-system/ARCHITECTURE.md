# System Architecture Documentation

## Overview

This document explains the architecture of the Insurance Claim Agentic System, designed to process insurance claims using AI agents following Agentic Best Practices (ABR) patterns.

---

## System Components

### 1. Core Layer (`/` root directory)

#### config.py
- **Purpose**: Centralized configuration management
- **Contains**:
  - API keys and credentials
  - Model settings (Claude version, temperature, max tokens)
  - File paths and directories
  - Application constants
- **Usage**: Import Config class wherever settings needed

#### utils.py
- **Purpose**: Shared utility functions
- **Contains**:
  - Logging setup
  - Data validation functions
  - Claim priority calculation
  - Sample claim data
  - Helper functions for formatting
- **Usage**: Import specific functions as needed

---

### 2. Demo Layer (`01_local_demo/`)

Purpose: Learn how agents work through progressively complex examples.

#### basic_agent.py (15 minutes)
```
User Input → Single Agent → Decision
```
- **What it does**: Analyzes one claim with one agent
- **Teaches**: Basic API calls, prompting, response parsing
- **Output**: Decision + confidence + reasoning

#### multi_agent.py (30 minutes)
```
User Input → [Triage, Risk, Compliance, Decision] → Final Decision
```
- **What it does**: Four specialized agents collaborate
- **Teaches**: Agent orchestration, specialization, synthesis
- **Output**: Multi-perspective analysis

#### full_system.py (1 hour)
```
User Input → 8 ABR Patterns → Comprehensive Decision
```
- **What it does**: All patterns working together
- **Teaches**: Production-ready system design
- **Output**: Complete processing workflow with logs

---

### 3. Pattern Layer (`02_patterns/`)

Each file demonstrates one ABR (Agentic Best Practice) pattern.

#### Pattern 1: Planner Agent (`planner_agent.py`)
```
Claim → Plan Generation → Step-by-Step Plan
```
- **Purpose**: Break complex tasks into steps
- **Algorithm**:
  1. Analyze claim complexity
  2. Generate processing steps
  3. Assign time estimates
  4. Define success criteria
- **Output**: JSON plan with steps

#### Pattern 2: Router Agent (`router_agent.py`)
```
Claim → Classification → Route Selection
```
- **Purpose**: Direct claims to appropriate processing pathway
- **Routes**:
  - FAST_TRACK: < $5k, auto-approve
  - STANDARD: $5k-$50k, regular review
  - COMPLEX: $50k-$100k, detailed analysis
  - EXECUTIVE: > $100k, executive review
- **Decision Factors**: Amount, type, complexity, priority

#### Pattern 3: RAG Agent (`rag_agent.py`)
```
Claim → Knowledge Retrieval → Context-Aware Analysis
```
- **Purpose**: Use policy knowledge for decisions
- **Process**:
  1. Retrieve relevant policy docs
  2. Match to claim type
  3. Apply policy rules
  4. Generate informed decision
- **Knowledge Base**: Simulated policy database

#### Pattern 4: Guardrail Agent (`guardrail_agent.py`)
```
Decision → Compliance Checks → Pass/Fail
```
- **Purpose**: Ensure regulatory compliance
- **Checks**:
  1. Data validation (all fields present)
  2. Amount limits (within policy max)
  3. Time limits (filed on time)
  4. Documentation (required docs present)
  5. Fraud indicators (risk flags)
  6. Regulatory compliance (state laws)
- **Output**: Pass/Fail with reasons

#### Pattern 5: Human Escalation (`human_escalation.py`)
```
Claim + Confidence → Escalation Decision
```
- **Purpose**: Know when human review is needed
- **Escalation Triggers**:
  - Confidence < 70%
  - Amount > $50,000
  - Complex type (Liability)
  - Fraud indicators present
  - Multiple previous claims
- **Output**: Escalate Yes/No with reasons

#### Pattern 6: Reflection Agent (`reflection_agent.py`)
```
Decision → Self-Assessment → Quality Rating
```
- **Purpose**: Agent evaluates its own decisions
- **Process**:
  1. Review decision made
  2. Assess reasoning quality
  3. Rate confidence
  4. Suggest improvements
- **Output**: Quality rating (1-10) + suggestions

#### Pattern 7: Tool Agent (`tool_agent.py`)
```
Claim → External Tools → Enriched Data
```
- **Purpose**: Integrate with external systems
- **Tools**:
  - policy_lookup: Verify coverage
  - fraud_check: Risk scoring
  - claims_history: Past behavior
  - payment_system: Process payments
- **Output**: Tool results for decision making

#### Pattern 8: Stateful Agent (`stateful_agent.py`)
```
Conversation → Memory Storage → Context Retention
```
- **Purpose**: Remember conversation context
- **Storage**:
  - Claim history
  - User preferences
  - Previous decisions
  - Processing logs
- **Benefits**: Consistent experience, faster processing

---

### 4. Cloud Integration Layer (`03_cloud_integration/`)

Purpose: Deploy agents to cloud platforms.

#### aws_bedrock.py
- AWS Bedrock integration
- Use AWS-hosted Claude models
- Leverage AWS infrastructure

#### azure_openai.py
- Azure OpenAI Service integration
- Enterprise security features
- Microsoft cloud ecosystem

#### multi_cloud.py
- Switch between cloud providers
- Failover capabilities
- Cost optimization

---

### 5. Web UI Layer (`04_web_ui/`)

Purpose: User-friendly interfaces for non-developers.

#### streamlit_app.py
```
Web Form → Agent Processing → Visual Results
```
- **Features**:
  - Form-based claim input
  - Real-time processing
  - Visual result display
  - Interactive controls

#### gradio_app.py
```
Alternative UI → Same Functionality
```
- **Features**:
  - Different UI framework
  - Simpler interface
  - Quick prototyping

---

### 6. Testing Layer (`05_testing/`)

Purpose: Validate system behavior.

#### test_claim_delay.py
- Tests late claim filing scenarios
- Validates time-based rules
- Ensures proper handling

#### test_rejection.py
- Tests rejection criteria
- Validates decision logic
- Ensures correct outcomes

#### test_all_patterns.py
- Comprehensive test suite
- Tests all 8 patterns
- Integration testing

---

### 7. Deployment Layer (`06_deployment/`)

Purpose: Production deployment configurations.

#### docker/
- Containerization configs
- Docker Compose setups
- Portable deployment

#### kubernetes/
- K8s deployment files
- Scaling configurations
- Service definitions

#### aws/
- AWS-specific configs
- CloudFormation templates
- Lambda functions

#### azure/
- Azure-specific configs
- ARM templates
- Functions apps

---

## Data Flow

### End-to-End Processing Flow

```
1. Claim Input
   ↓
2. Planning Agent
   - Creates processing plan
   - Identifies steps needed
   ↓
3. Router Agent
   - Classifies claim complexity
   - Selects processing pathway
   ↓
4. RAG Agent
   - Retrieves policy knowledge
   - Adds relevant context
   ↓
5. Tool Agent
   - Calls external systems
   - Gathers additional data
   ↓
6. Decision Making
   - Analyzes all information
   - Makes initial decision
   ↓
7. Reflection Agent
   - Self-assesses decision quality
   - Suggests improvements
   ↓
8. Guardrail Agent
   - Validates compliance
   - Checks regulations
   ↓
9. Escalation Check
   - Evaluates confidence
   - Determines if human needed
   ↓
10. Stateful Agent
    - Stores decision
    - Updates memory
    ↓
11. Final Output
    - Decision + reasoning
    - Confidence score
    - Next actions
```

---

## Design Principles

### 1. Modularity
- Each pattern is independent
- Can be used alone or combined
- Easy to test and maintain

### 2. Scalability
- Patterns can process multiple claims
- Horizontal scaling possible
- Cloud-ready architecture

### 3. Maintainability
- Clear separation of concerns
- Well-documented code
- Consistent structure

### 4. Extensibility
- Easy to add new patterns
- Plugin architecture for tools
- Customizable decision logic

### 5. Reliability
- Error handling at every layer
- Guardrails prevent mistakes
- Escalation for uncertain cases

---

## Integration Points

### External Systems

#### 1. Policy Management System
- **Purpose**: Retrieve policy details
- **Integration**: REST API
- **Pattern**: Tool Agent

#### 2. Fraud Detection System
- **Purpose**: Risk scoring
- **Integration**: API call
- **Pattern**: Tool Agent

#### 3. Payment Processing
- **Purpose**: Handle payouts
- **Integration**: Payment gateway
- **Pattern**: Tool Agent

#### 4. Document Storage
- **Purpose**: Store claim documents
- **Integration**: S3/Azure Blob
- **Pattern**: Tool Agent

#### 5. Customer Database
- **Purpose**: Customer history
- **Integration**: Database query
- **Pattern**: Stateful Agent

---

## Security Considerations

### 1. API Key Management
- Store in environment variables
- Never commit to version control
- Rotate regularly

### 2. Data Privacy
- PII encryption at rest
- Secure transmission (HTTPS)
- Access control and logging

### 3. Compliance
- HIPAA for health claims
- SOC 2 for general processing
- State insurance regulations

### 4. Audit Trail
- Log all decisions
- Track agent actions
- Maintain processing history

---

## Performance Optimization

### 1. Caching
- Cache policy lookups
- Store frequent queries
- Reduce API calls

### 2. Parallel Processing
- Run independent agents concurrently
- Batch similar claims
- Async operations

### 3. Resource Management
- Connection pooling
- Rate limiting
- Timeout handling

---

## Monitoring & Observability

### Metrics to Track

1. **Processing Time**
   - Per claim
   - Per pattern
   - End-to-end

2. **Decision Quality**
   - Accuracy rate
   - Escalation rate
   - Confidence distribution

3. **System Health**
   - API response times
   - Error rates
   - Resource utilization

4. **Business Metrics**
   - Claims processed per hour
   - Average processing cost
   - Customer satisfaction

---

## Future Enhancements

### Short Term
1. Real database integration
2. Production API endpoints
3. Enhanced error handling
4. More comprehensive testing

### Medium Term
1. Multi-language support
2. Advanced fraud detection
3. ML model integration
4. Real-time analytics

### Long Term
1. Fully autonomous processing
2. Predictive claim analysis
3. Continuous learning system
4. Global deployment

---

## Conclusion

This architecture provides:
- ✅ Modular, maintainable design
- ✅ Industry best practices (ABR patterns)
- ✅ Production-ready structure
- ✅ Scalable and extensible
- ✅ Educational and practical

Ready for both learning and real-world deployment!
