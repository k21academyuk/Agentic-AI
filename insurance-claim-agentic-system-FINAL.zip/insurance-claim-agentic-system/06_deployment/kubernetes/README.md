# Kubernetes Deployment Guide

## Prerequisites

- Kubernetes cluster (v1.24+)
- kubectl configured
- Docker image pushed to registry
- Persistent volume support

## Quick Deploy

```bash
# 1. Create namespace
kubectl create namespace insurance-claims

# 2. Create secrets (edit secrets.yaml first!)
kubectl apply -f secrets.yaml -n insurance-claims

# 3. Deploy application
kubectl apply -f deployment.yaml -n insurance-claims

# 4. Check status
kubectl get pods -n insurance-claims
kubectl get svc -n insurance-claims
```

## Configuration

### 1. Update secrets.yaml

Replace placeholder values:
```yaml
anthropic-api-key: "sk-ant-your-real-key"
database-url: "postgresql://user:pass@host:5432/db"
```

### 2. Update deployment.yaml

Change image reference:
```yaml
image: your-registry.com/insurance-claims:v1.0.0
```

## Components

### Deployment
- 3 replicas (configurable)
- Auto-scaling enabled (2-10 pods)
- Health checks configured
- Resource limits set

### Service
- LoadBalancer type (exposes to internet)
- Maps port 80 → 8501

### Persistent Volumes
- Data volume: 10Gi
- Logs volume: 5Gi

### HPA (Horizontal Pod Autoscaler)
- Scales based on CPU (70%) and memory (80%)
- Min: 2 pods, Max: 10 pods

## Access Application

```bash
# Get external IP
kubectl get svc insurance-claims-service -n insurance-claims

# Output will show EXTERNAL-IP
# Access at: http://EXTERNAL-IP
```

## Monitoring

```bash
# View pods
kubectl get pods -n insurance-claims

# View logs
kubectl logs -f deployment/insurance-claims -n insurance-claims

# Describe pod (for debugging)
kubectl describe pod POD_NAME -n insurance-claims

# View events
kubectl get events -n insurance-claims --sort-by='.lastTimestamp'
```

## Scaling

### Manual Scaling
```bash
# Scale to 5 replicas
kubectl scale deployment insurance-claims --replicas=5 -n insurance-claims
```

### Auto-Scaling
HPA automatically scales based on load (already configured).

## Updates

### Rolling Update
```bash
# Update image
kubectl set image deployment/insurance-claims \
  insurance-claims=your-registry.com/insurance-claims:v2.0.0 \
  -n insurance-claims

# Check rollout status
kubectl rollout status deployment/insurance-claims -n insurance-claims
```

### Rollback
```bash
# Rollback to previous version
kubectl rollout undo deployment/insurance-claims -n insurance-claims

# Rollback to specific revision
kubectl rollout undo deployment/insurance-claims --to-revision=2 -n insurance-claims
```

## Resource Management

### View Resource Usage
```bash
kubectl top pods -n insurance-claims
kubectl top nodes
```

### Adjust Resources
Edit deployment.yaml:
```yaml
resources:
  requests:
    memory: "1Gi"    # Increase as needed
    cpu: "500m"
  limits:
    memory: "2Gi"
    cpu: "1000m"
```

## Security

### Using External Secrets

Instead of storing secrets in Git, use:

**AWS Secrets Manager:**
```bash
# Install External Secrets Operator
helm install external-secrets external-secrets/external-secrets

# Create SecretStore
kubectl apply -f aws-secret-store.yaml
```

**Azure Key Vault:**
```bash
# Use Azure Key Vault provider
kubectl apply -f azure-keyvault-provider.yaml
```

### Network Policies
```bash
kubectl apply -f network-policy.yaml
```

## Production Checklist

- [ ] Secrets stored securely (not in Git)
- [ ] Resource limits configured
- [ ] Health checks enabled
- [ ] Auto-scaling configured
- [ ] Persistent volumes provisioned
- [ ] Monitoring setup (Prometheus/Grafana)
- [ ] Logging aggregation (ELK/Loki)
- [ ] Backup strategy implemented
- [ ] Disaster recovery tested
- [ ] Network policies applied
- [ ] RBAC configured
- [ ] Image scanning enabled
- [ ] SSL/TLS certificates configured

## Troubleshooting

### Pods Not Starting
```bash
# Check pod status
kubectl describe pod POD_NAME -n insurance-claims

# Common issues:
# - Image pull errors: Check registry credentials
# - CrashLoopBackOff: Check logs
# - Insufficient resources: Increase node capacity
```

### Service Not Accessible
```bash
# Check service
kubectl get svc -n insurance-claims

# Check endpoints
kubectl get endpoints -n insurance-claims

# Test from within cluster
kubectl run -it --rm debug --image=busybox --restart=Never -- sh
wget -qO- http://insurance-claims-service
```

### Database Connection Issues
```bash
# Check secrets
kubectl get secret insurance-claims-secrets -n insurance-claims -o yaml

# Test database connection
kubectl run -it --rm psql --image=postgres:15 --restart=Never -- \
  psql postgresql://user:pass@postgres-service:5432/claims
```

## Clean Up

```bash
# Delete everything
kubectl delete namespace insurance-claims

# Or delete individually
kubectl delete -f deployment.yaml -n insurance-claims
kubectl delete -f secrets.yaml -n insurance-claims
```

## Multi-Cloud Deployment

### AWS EKS
```bash
eksctl create cluster --name insurance-claims --region us-east-1
```

### Azure AKS
```bash
az aks create --resource-group myResourceGroup --name insurance-claims
```

### Google GKE
```bash
gcloud container clusters create insurance-claims --region us-central1
```

## Cost Optimization

1. **Right-size resources**: Monitor and adjust requests/limits
2. **Use spot instances**: For non-critical workloads
3. **Enable cluster autoscaler**: Scale nodes automatically
4. **Use pod disruption budgets**: Safe updates
5. **Implement caching**: Reduce API calls

## Monitoring Stack

### Prometheus + Grafana
```bash
# Install monitoring stack
kubectl apply -f monitoring/
```

### Logs
```bash
# Install Loki
kubectl apply -f loki/
```

See monitoring/ directory for configurations.
