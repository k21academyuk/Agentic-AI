# AWS Deployment Guide

## Deployment Options

1. **ECS Fargate** (Recommended) - Serverless containers
2. **ECS EC2** - Traditional EC2-based containers
3. **Lambda** - Serverless functions (for lightweight workloads)
4. **Elastic Beanstalk** - PaaS solution

This guide focuses on ECS Fargate deployment.

## Prerequisites

- AWS Account
- AWS CLI installed and configured
- Docker image built and pushed to ECR
- Anthropic API key

## Quick Deploy with CloudFormation

```bash
# 1. Build and push Docker image
aws ecr create-repository --repository-name insurance-claims
aws ecr get-login-password | docker login --username AWS --password-stdin $AWS_ACCOUNT.dkr.ecr.$AWS_REGION.amazonaws.com

docker build -t insurance-claims:latest .
docker tag insurance-claims:latest $AWS_ACCOUNT.dkr.ecr.$AWS_REGION.amazonaws.com/insurance-claims:latest
docker push $AWS_ACCOUNT.dkr.ecr.$AWS_REGION.amazonaws.com/insurance-claims:latest

# 2. Deploy CloudFormation stack
aws cloudformation create-stack \
  --stack-name insurance-claims-prod \
  --template-body file://cloudformation-template.yaml \
  --parameters \
    ParameterKey=AnthropicApiKey,ParameterValue=your-api-key \
    ParameterKey=EnvironmentName,ParameterValue=production \
  --capabilities CAPABILITY_IAM

# 3. Wait for deployment
aws cloudformation wait stack-create-complete \
  --stack-name insurance-claims-prod

# 4. Get load balancer URL
aws cloudformation describe-stacks \
  --stack-name insurance-claims-prod \
  --query 'Stacks[0].Outputs[?OutputKey==`LoadBalancerURL`].OutputValue' \
  --output text
```

## Manual Setup

### 1. Create ECR Repository

```bash
aws ecr create-repository --repository-name insurance-claims
```

### 2. Push Docker Image

```bash
# Get login command
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin \
  $AWS_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com

# Build and push
docker build -t insurance-claims .
docker tag insurance-claims:latest \
  $AWS_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/insurance-claims:latest
docker push $AWS_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/insurance-claims:latest
```

### 3. Create Secrets

```bash
aws secretsmanager create-secret \
  --name insurance-claims-api-keys \
  --secret-string '{"ANTHROPIC_API_KEY":"your-key-here"}'
```

### 4. Create ECS Cluster

```bash
aws ecs create-cluster --cluster-name insurance-claims-prod
```

### 5. Register Task Definition

```bash
aws ecs register-task-definition --cli-input-json file://task-definition.json
```

### 6. Create Service

```bash
aws ecs create-service \
  --cluster insurance-claims-prod \
  --service-name insurance-claims-service \
  --task-definition insurance-claims:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx],securityGroups=[sg-xxx],assignPublicIp=ENABLED}"
```

## Using AWS Bedrock

To use Claude via AWS Bedrock instead of direct API:

### 1. Enable Bedrock Model Access

```bash
# Go to AWS Console → Bedrock → Model access
# Request access to Claude 3 models
```

### 2. Update IAM Role

Add Bedrock permissions to ECS task role:
```json
{
  "Effect": "Allow",
  "Action": [
    "bedrock:InvokeModel"
  ],
  "Resource": "*"
}
```

### 3. Update Application Code

Use the Bedrock integration:
```python
from insurance_claim_system.cloud_integration import aws_bedrock
analyzer = aws_bedrock.BedrockClaimAnalyzer()
```

## Monitoring

### CloudWatch Logs

```bash
# View logs
aws logs tail /ecs/insurance-claims-prod --follow

# Filter logs
aws logs filter-log-events \
  --log-group-name /ecs/insurance-claims-prod \
  --filter-pattern "ERROR"
```

### CloudWatch Metrics

View in AWS Console:
- ECS → Clusters → insurance-claims-prod → Metrics
- CloudWatch → Dashboards

### X-Ray Tracing

Enable in task definition:
```json
{
  "portMappings": [...],
  "environment": [
    {
      "name": "AWS_XRAY_DAEMON_ADDRESS",
      "value": "xray-daemon:2000"
    }
  ]
}
```

## Scaling

### Manual Scaling

```bash
# Scale to 5 tasks
aws ecs update-service \
  --cluster insurance-claims-prod \
  --service insurance-claims-service \
  --desired-count 5
```

### Auto Scaling

Already configured in CloudFormation template.
Adjusts between 2-10 tasks based on CPU utilization.

## Updates

### Deploy New Version

```bash
# Build and push new image
docker build -t insurance-claims:v2 .
docker tag insurance-claims:v2 $ECR_REPO:v2
docker push $ECR_REPO:v2

# Update service
aws ecs update-service \
  --cluster insurance-claims-prod \
  --service insurance-claims-service \
  --force-new-deployment
```

### Blue/Green Deployment

Use AWS CodeDeploy for zero-downtime updates:
```bash
aws deploy create-deployment \
  --application-name insurance-claims \
  --deployment-group-name production \
  --deployment-config-name CodeDeployDefault.ECSAllAtOnce
```

## Cost Optimization

1. **Use Fargate Spot**: 70% cost savings
```bash
--capacity-provider-strategy capacityProvider=FARGATE_SPOT,weight=1
```

2. **Right-size resources**: Monitor and adjust CPU/memory

3. **Use CloudWatch alarms**: Scale down during off-hours

4. **Reserved capacity**: For predictable workloads

5. **S3 lifecycle policies**: Archive old logs

## Security Best Practices

1. **Use Secrets Manager**: Never hardcode credentials
2. **Enable VPC endpoints**: Private traffic to AWS services
3. **Implement least privilege**: Minimal IAM permissions
4. **Enable CloudTrail**: Audit all API calls
5. **Use WAF**: Protect load balancer
6. **Enable encryption**: At rest and in transit
7. **Regular patching**: Update base images

## Disaster Recovery

### Backup Strategy

```bash
# Backup ECS task definition
aws ecs describe-task-definition \
  --task-definition insurance-claims \
  --query 'taskDefinition' > task-def-backup.json

# Backup secrets
aws secretsmanager get-secret-value \
  --secret-id insurance-claims-api-keys \
  --query SecretString --output text > secrets-backup.txt
```

### Multi-Region Deployment

Deploy to multiple regions:
```bash
# Deploy to us-east-1
aws cloudformation create-stack --stack-name insurance-claims-prod --region us-east-1 ...

# Deploy to us-west-2
aws cloudformation create-stack --stack-name insurance-claims-prod --region us-west-2 ...

# Use Route 53 for failover
```

## Troubleshooting

### Service Won't Start

```bash
# Check service events
aws ecs describe-services \
  --cluster insurance-claims-prod \
  --services insurance-claims-service \
  --query 'services[0].events'

# Check task logs
aws logs tail /ecs/insurance-claims-prod --follow
```

### High Costs

```bash
# View costs
aws ce get-cost-and-usage \
  --time-period Start=2024-01-01,End=2024-02-01 \
  --granularity MONTHLY \
  --metrics BlendedCost \
  --filter file://cost-filter.json
```

### Performance Issues

```bash
# Check CloudWatch metrics
aws cloudwatch get-metric-statistics \
  --namespace AWS/ECS \
  --metric-name CPUUtilization \
  --dimensions Name=ServiceName,Value=insurance-claims-service \
  --start-time 2024-01-01T00:00:00Z \
  --end-time 2024-01-02T00:00:00Z \
  --period 3600 \
  --statistics Average
```

## Clean Up

```bash
# Delete CloudFormation stack (deletes all resources)
aws cloudformation delete-stack --stack-name insurance-claims-prod

# Or manually delete resources
aws ecs delete-service --cluster insurance-claims-prod --service insurance-claims-service --force
aws ecs delete-cluster --cluster insurance-claims-prod
aws ecr delete-repository --repository-name insurance-claims --force
aws secretsmanager delete-secret --secret-id insurance-claims-api-keys
```

## CI/CD Pipeline

### Using AWS CodePipeline

```bash
# Create pipeline
aws codepipeline create-pipeline --cli-input-json file://pipeline.json

# Pipeline stages:
# 1. Source (GitHub/CodeCommit)
# 2. Build (CodeBuild - builds Docker image)
# 3. Deploy (ECS deployment)
```

### Using GitHub Actions

See `.github/workflows/deploy-aws.yml` for example.

## Cost Estimates

**Monthly costs for different scales:**

- **Small (2 tasks)**: $30-50/month
  - Fargate: $30
  - Load Balancer: $20
  - Data transfer: minimal

- **Medium (5 tasks)**: $75-100/month
  - Fargate: $75
  - Load Balancer: $20
  - Bedrock API: variable

- **Large (10 tasks)**: $150-200/month
  - Fargate: $150
  - Load Balancer: $20
  - Bedrock API: variable
  - Additional services: $30

## Support

- AWS Documentation: https://docs.aws.amazon.com/ecs/
- AWS Support: Available in AWS Console
- Community: AWS re:Post forums
