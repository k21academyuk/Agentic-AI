# Docker Deployment Guide

## Quick Start

```bash
# 1. Navigate to project root
cd insurance-claim-agentic-system

# 2. Create .env file with your API keys
cp .env.example .env
# Edit .env and add your keys

# 3. Build and run with Docker Compose
cd 06_deployment/docker
docker-compose up -d

# 4. Access the application
# Web UI: http://localhost:8501
# Database: localhost:5432
```

## What Gets Deployed

- **insurance-claims-app**: Main application with Streamlit UI
- **postgres**: PostgreSQL database for claim storage
- **pgadmin** (optional): Database management interface

## Configuration

### Environment Variables

Required in `.env` file:
```
ANTHROPIC_API_KEY=your_key_here
AWS_ACCESS_KEY_ID=your_aws_key (optional)
AWS_SECRET_ACCESS_KEY=your_aws_secret (optional)
AWS_REGION=us-east-1 (optional)
```

### Ports

- `8501`: Streamlit web interface
- `5432`: PostgreSQL database
- `5050`: pgAdmin (if enabled)

## Commands

```bash
# Start services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down

# Rebuild after code changes
docker-compose build
docker-compose up -d

# Include pgAdmin for debugging
docker-compose --profile debug up -d

# Remove everything (including volumes)
docker-compose down -v
```

## Production Deployment

### 1. Build Production Image

```bash
docker build -t insurance-claims:latest -f 06_deployment/docker/Dockerfile .
```

### 2. Push to Registry

```bash
# Tag for your registry
docker tag insurance-claims:latest your-registry.com/insurance-claims:latest

# Push
docker push your-registry.com/insurance-claims:latest
```

### 3. Deploy

```bash
# Pull and run on production server
docker pull your-registry.com/insurance-claims:latest
docker-compose -f docker-compose.prod.yml up -d
```

## Security Best Practices

1. **Never commit .env files**
2. **Use secrets management** (AWS Secrets Manager, Azure Key Vault)
3. **Run as non-root user** (already configured)
4. **Use HTTPS** in production (configure reverse proxy)
5. **Limit network exposure**
6. **Regular updates** of base images

## Monitoring

```bash
# Check container health
docker-compose ps

# View resource usage
docker stats

# Application logs
docker-compose logs -f insurance-claims

# Database logs
docker-compose logs -f db
```

## Troubleshooting

### Container Won't Start

```bash
# Check logs
docker-compose logs insurance-claims

# Check if ports are available
netstat -an | grep 8501
```

### Database Connection Issues

```bash
# Test database connection
docker-compose exec db psql -U postgres -d claims

# Check database logs
docker-compose logs db
```

### API Key Issues

```bash
# Verify environment variables
docker-compose exec insurance-claims env | grep API_KEY

# Restart after .env changes
docker-compose restart
```

## Scaling

### Horizontal Scaling

```bash
# Scale to 3 app instances
docker-compose up -d --scale insurance-claims=3
```

For production scaling, use:
- Kubernetes (see ../kubernetes/)
- Docker Swarm
- AWS ECS
- Azure Container Instances

## Backup & Recovery

### Backup Database

```bash
docker-compose exec db pg_dump -U postgres claims > backup.sql
```

### Restore Database

```bash
cat backup.sql | docker-compose exec -T db psql -U postgres claims
```

## Updates

```bash
# Pull latest code
git pull

# Rebuild and restart
docker-compose build
docker-compose up -d
```

## Clean Up

```bash
# Stop and remove containers
docker-compose down

# Remove volumes (WARNING: deletes data)
docker-compose down -v

# Remove images
docker rmi insurance-claims:latest
```
