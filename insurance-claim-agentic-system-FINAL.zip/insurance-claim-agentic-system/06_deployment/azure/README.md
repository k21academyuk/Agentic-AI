# Azure Deployment Guide

## Deployment Options

1. **Azure Container Instances (ACI)** - Simplest serverless containers
2. **Azure Kubernetes Service (AKS)** - Full Kubernetes platform
3. **Azure App Service** - PaaS for web apps
4. **Azure Functions** - Serverless compute

This guide focuses on ACI for simplicity and AKS for production scale.

## Prerequisites

- Azure account
- Azure CLI installed
- Docker image built
- Anthropic API key

## Quick Deploy with ARM Template

```bash
# 1. Login to Azure
az login

# 2. Create resource group
az group create \
  --name insurance-claims-rg \
  --location eastus

# 3. Deploy ARM template
az deployment group create \
  --resource-group insurance-claims-rg \
  --template-file arm-template.json \
  --parameters appName=insurance-claims anthropicApiKey=your-api-key

# 4. Get application URL
az deployment group show \
  --resource-group insurance-claims-rg \
  --name arm-template \
  --query properties.outputs.containerURL.value
```

## Azure Container Instances (ACI)

### Push Image to ACR

```bash
# Create container registry
az acr create \
  --resource-group insurance-claims-rg \
  --name insuranceclaimsacr \
  --sku Basic

# Login to registry
az acr login --name insuranceclaimsacr

# Build and push
docker build -t insurance-claims:latest .
docker tag insurance-claims:latest insuranceclaimsacr.azurecr.io/insurance-claims:latest
docker push insuranceclaimsacr.azurecr.io/insurance-claims:latest
```

### Deploy to ACI

```bash
# Create container instance
az container create \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aci \
  --image insuranceclaimsacr.azurecr.io/insurance-claims:latest \
  --cpu 1 \
  --memory 1.5 \
  --registry-login-server insuranceclaimsacr.azurecr.io \
  --registry-username $(az acr credential show --name insuranceclaimsacr --query username -o tsv) \
  --registry-password $(az acr credential show --name insuranceclaimsacr --query passwords[0].value -o tsv) \
  --dns-name-label insurance-claims-app \
  --ports 8501 \
  --environment-variables \
    ANTHROPIC_API_KEY=your-api-key \
    LOG_LEVEL=INFO

# Get URL
az container show \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aci \
  --query ipAddress.fqdn \
  --output tsv
```

## Azure Kubernetes Service (AKS)

### Create AKS Cluster

```bash
# Create AKS cluster
az aks create \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aks \
  --node-count 3 \
  --enable-addons monitoring \
  --generate-ssh-keys

# Get credentials
az aks get-credentials \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aks

# Attach ACR to AKS
az aks update \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aks \
  --attach-acr insuranceclaimsacr
```

### Deploy to AKS

```bash
# Use Kubernetes manifests from ../kubernetes/
kubectl apply -f ../kubernetes/secrets.yaml
kubectl apply -f ../kubernetes/deployment.yaml

# Check deployment
kubectl get pods
kubectl get svc
```

## Azure Key Vault Integration

### Store Secrets

```bash
# Create Key Vault
az keyvault create \
  --name insurance-claims-kv \
  --resource-group insurance-claims-rg \
  --location eastus

# Add secrets
az keyvault secret set \
  --vault-name insurance-claims-kv \
  --name anthropic-api-key \
  --value your-api-key

# Grant access to ACI/AKS
az keyvault set-policy \
  --name insurance-claims-kv \
  --object-id $(az ad sp list --display-name insurance-claims --query [].id -o tsv) \
  --secret-permissions get list
```

### Use Secrets in ACI

```bash
# Reference Key Vault secret
az container create \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aci \
  --image insuranceclaimsacr.azurecr.io/insurance-claims:latest \
  --secrets \
    anthropic-api-key=$(az keyvault secret show --name anthropic-api-key --vault-name insurance-claims-kv --query value -o tsv)
```

## Monitoring

### Application Insights

```bash
# Create Application Insights
az monitor app-insights component create \
  --app insurance-claims-insights \
  --location eastus \
  --resource-group insurance-claims-rg

# Get instrumentation key
az monitor app-insights component show \
  --app insurance-claims-insights \
  --resource-group insurance-claims-rg \
  --query instrumentationKey
```

### View Logs

```bash
# Container logs
az container logs \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aci

# Follow logs
az container logs \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aci \
  --follow
```

### Metrics

```bash
# View metrics in Azure Portal
# Container Instances → Metrics
# Or use CLI:
az monitor metrics list \
  --resource /subscriptions/xxx/resourceGroups/insurance-claims-rg/providers/Microsoft.ContainerInstance/containerGroups/insurance-claims-aci
```

## Scaling

### ACI - Restart with More Resources

```bash
az container delete \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aci \
  --yes

az container create \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aci \
  --cpu 2 \
  --memory 3 \
  ...
```

### AKS - Scale Deployment

```bash
# Scale pods
kubectl scale deployment insurance-claims --replicas=5

# Scale nodes
az aks scale \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aks \
  --node-count 5
```

## Updates

### Update Container

```bash
# Build and push new image
docker build -t insurance-claims:v2 .
docker tag insurance-claims:v2 insuranceclaimsacr.azurecr.io/insurance-claims:v2
docker push insuranceclaimsacr.azurecr.io/insurance-claims:v2

# Update ACI
az container delete --resource-group insurance-claims-rg --name insurance-claims-aci --yes
az container create ... --image insuranceclaimsacr.azurecr.io/insurance-claims:v2

# Or for AKS
kubectl set image deployment/insurance-claims insurance-claims=insuranceclaimsacr.azurecr.io/insurance-claims:v2
```

## Cost Optimization

1. **Use correct SKUs**: Basic tier for dev, Standard for prod
2. **Auto-shutdown**: For dev environments
3. **Reserved instances**: Long-term commitments
4. **Spot instances**: Non-critical workloads
5. **Monitor usage**: Use Azure Cost Management

### Cost Estimates

**Azure Container Instances:**
- Small (1 vCPU, 1.5GB): $35/month
- Medium (2 vCPU, 3GB): $70/month
- Large (4 vCPU, 6GB): $140/month

**AKS (3-node cluster):**
- Basic (Standard_B2s): $60/month
- Standard (Standard_D2s_v3): $180/month
- Premium (Standard_D4s_v3): $360/month

## Security

### Network Security

```bash
# Create virtual network
az network vnet create \
  --resource-group insurance-claims-rg \
  --name insurance-claims-vnet \
  --subnet-name default

# Deploy ACI in VNet
az container create \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aci \
  --vnet insurance-claims-vnet \
  --subnet default \
  ...
```

### Managed Identity

```bash
# Create managed identity
az identity create \
  --resource-group insurance-claims-rg \
  --name insurance-claims-identity

# Assign to ACI
az container create \
  --resource-group insurance-claims-rg \
  --assign-identity $(az identity show --resource-group insurance-claims-rg --name insurance-claims-identity --query id -o tsv) \
  ...
```

## Disaster Recovery

### Backup

```bash
# Backup container image
az acr export \
  --name insuranceclaimsacr \
  --source insurance-claims:latest \
  --destination backup-insurance-claims:latest

# Backup Key Vault
az keyvault backup \
  --vault-name insurance-claims-kv \
  --file keyvault-backup.json
```

### Multi-Region

```bash
# Deploy to multiple regions
az group create --name insurance-claims-eastus-rg --location eastus
az group create --name insurance-claims-westus-rg --location westus

# Deploy to each region
# Use Azure Traffic Manager for routing
```

## CI/CD with Azure DevOps

### Create Pipeline

```yaml
# azure-pipelines.yml
trigger:
  - main

pool:
  vmImage: 'ubuntu-latest'

steps:
- task: Docker@2
  inputs:
    containerRegistry: 'insuranceclaimsacr'
    repository: 'insurance-claims'
    command: 'buildAndPush'
    Dockerfile: '**/Dockerfile'

- task: AzureCLI@2
  inputs:
    azureSubscription: 'your-subscription'
    scriptType: 'bash'
    scriptLocation: 'inlineScript'
    inlineScript: |
      az container restart \
        --resource-group insurance-claims-rg \
        --name insurance-claims-aci
```

## Troubleshooting

### Container Won't Start

```bash
# Check events
az container show \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aci \
  --query instanceView.events

# Check logs
az container logs \
  --resource-group insurance-claims-rg \
  --name insurance-claims-aci
```

### High Costs

```bash
# View costs
az consumption usage list \
  --start-date 2024-01-01 \
  --end-date 2024-02-01
```

### Performance Issues

```bash
# Check resource utilization
az monitor metrics list \
  --resource /subscriptions/xxx/.../insurance-claims-aci \
  --metric "CPU Usage"
```

## Clean Up

```bash
# Delete resource group (deletes all resources)
az group delete \
  --name insurance-claims-rg \
  --yes \
  --no-wait
```

## Best Practices

1. **Use managed identities**: Avoid storing credentials
2. **Enable diagnostics**: Log everything
3. **Use private endpoints**: Secure network traffic
4. **Tag resources**: For cost tracking
5. **Implement backup**: Regular backups
6. **Use Azure Policy**: Enforce standards
7. **Enable auto-scaling**: Handle load
8. **Monitor costs**: Set budgets and alerts

## Support

- Azure Documentation: https://docs.microsoft.com/azure/
- Azure Support: Available in Azure Portal
- Community: Microsoft Q&A forums
